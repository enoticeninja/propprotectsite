<?php
include_once 'bootstrap.php';
include_once 'db.php';
require_once('../decryption.php');
require_once __DIR__ . '/../user-functions.php';
$mcrypt = new MCrypt();
include 'db.php';
$TITLE = 'Forgot Password';
// require_once 'PHPMailer-master/PHPMailerAutoload.php';

if (isset($_POST["submit_email"])) {
	$_POST["email"] = $_POST["submit_email"];
	$response = callApiJson($_POST,API_SITE_PATH.'forgot_password.php');
	$message = $response['message'];
	if($response['status'] == true){
		$message = '';
		header('location: forgot-password.php?status=true&message=' . $message . '');
	}
	else{
		$message = 'Email not registered. Please sign up.';
		header('location: forgot-password.php?status=false&message=' . $message . '');		
	}
}
else{
	/* $message = 'Email not registered. Please sign up.';
	header('location: forgot-password.php?status=false&message=' . $message . '');	 */	
}
?>
<!DOCTYPE html>

<html>

<head>
	<?php include_once 'tpl/tplHead.php'; ?>
</head>

<body class="hold-transition login-page">
	<div class="login-box">

		<!-- /.login-logo -->
		<div class="card card-cascade wider">
			<div class="view view-cascade gradient-card-header blue-gradient">

				<!-- Title -->
				<h2 class="card-header-title mb-3">Retrieve Password</h2>

			</div>
			<div class="card-body register-card-body card-body-cascade text-center">
				<img src="dist/img/Logo_Final.png" alt="AdminLTE Logo" class="brand-image " style="width: 100px;height: 25%;margin-bottom: 0%;">
				<p style="text-align: center; color:Black;">Search You Can Trust</p>
				<p class="login-box-msg">You forgot your password? Here you can easily retrieve a new password.</p>

				<form action="" class="ui form" role="form" id='login-form' method="post">
					<div class="input-group mb-3">
						<input type="email" class="form-control" name="email" placeholder="Email" required autofocus>
						<div class="input-group-append">
							<div class="input-group-text">
								<span class="fas fa-envelope"></span>
							</div>
						</div>
					</div>
					<div class="col-12">
						<div class="row long-text-opacity">
							<?php if (@$_GET['status'] == 'false') {
								echo "<font color='red'>This email id is not registered with us.</font>";
							?>
							<?php }
							if (@$_GET['status'] == 'true') {
								echo "<font color='green' style='margin-left: 3%;'>Link has been sent to your email.</font>";
							?>
							<?php } ?>

						</div>

					</div>
					<div class="row">
						<div class="col-12">
							<p class="mb-3">
								<button class="btn btn-primary btn-block" type="submit" name="submit_email" id="forget_button">Request for password</button>
							</p>
						</div>
					</div>
				</form>
				<div class="row">
					<div class="row">
						<div class="col-12">
							<p class="mb-1">
								<a href="<?php echo ADMIN_SITE_PATH ?>register.php" class="btn btn-secondary btn-block float-right">Sign up</a>
							</p>
						</div>
						<div class="col-12">
							<p class="mb-1">
								<a href="<?php echo ADMIN_SITE_PATH ?>login.php" class="btn btn-deep-purple btn-block float-right">Login with Email/Username</a>
							</p>
						</div>
						<div class="col-12">
							<p class="mb-1">
								<a href="<?php echo ADMIN_SITE_PATH ?>login_mob.php" class="btn btn-primary btn-block float-right">Login with Mobile</a>
							</p>
						</div>
						<!-- /.col -->
					</div>

					<!-- /.col -->
				</div>

			</div>
			<!-- /.login-card-body -->
		</div>
	</div>
	<!-- /.login-box -->

	<!-- jQuery -->
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap 4 -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- AdminLTE App -->
	<script src="dist/js/adminlte.min.js"></script>

</body>

</html>