<?php
include_once 'bootstrap.php';
include_once 'common.php';
$TITLE = 'My Properties';
$has_subscription = checkSubscription();
if (isset($_GET['query'])) {
	$village = $_GET['query'];
	$sql = "SELECT * FROM village WHERE village LIKE '%$village%'";
	$query = mysqli_query($conn, $sql);
	$return = array();
	while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
		$return[$row['village_id']] = $row;
	}
	echo json_encode($return);
	exit();
}

$form_config = getPropertyFormFields();
$property_labels = getViewPropertyLabels();
//var_export($arr);
?>
<!DOCTYPE html>
<html>

<head>
	<?php include_once 'tpl/tplHead.php'; ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
	<style>
		.modal-lg,
		.modal-xl {
			max-width: 1100px;
		}

		.center {
			display: block;
			margin-left: auto;
			margin-right: auto;
		}

		.modal-dialog {
			overflow-y: initial !important
		}

		.modal-body {
			height: 580px;
			overflow-y: auto;
		}

		.alert {
			display: none;
		}

		.alert-success {
			color: #1cb722;
			background: #c6e4a3;
			border-color: #23923d;
		}

		.my-floating-button {
			position: fixed;
			bottom: 45px;
			right: 24px;
			z-index: 999999;
		}

		.twitter-typeahead {
			width: 100%;
		}

		.tt-menu {
			background: #d8d2d2;
			padding: 10px;
			width: 100%;
		}

		.tt-dataset {
			cursor: pointer;
		}

		.top-left-close {
			position: absolute;
			left: -25px;
			top: -25px;
		}

		.top-right-close {
			position: absolute;
			right: -25px;
			top: -25px;
		}
	</style>
	<div class="wrapper">

		<?php include_once 'tpl/tplHeader.php'; ?>
		<?php include_once 'tpl/tplSidebar.php'; ?>

		<div class="content-wrapper">
			<!-- Main content -->
			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<input type="hidden" id="user_id" name="id" value="<?php echo $user_id ?>">

							<div class="card">
								<!-- /.card-header -->

								<!-- /.card -->
							</div>
						</div>
					</div>
				</div>
			</section>

			<section>
				<?php if ($has_subscription) : ?>
					<div class="my-floating-button" style="position:fixed;bottom: 45px; right: 24px;">
						<a href="<?php echo ADMIN_SITE_PATH ?>add_my_property.php" class="btn-floating btn-lg green">
							<i class="fas fa-plus"></i>
						</a>
					</div>
					<div class="row p-3">
						<div class="col-md-10 m-auto">
							<a href="<?php echo ADMIN_SITE_PATH ?>add_my_property.php" class="btn btn-secondary btn-block waves-effect waves-light p-3"><i class="fas fa-plus mr-1"></i> ADD NEW PROPERTY</a>
						</div>
					</div>
				<?php else : ?>
					<div class="row p-3 mt-5">
						<div class="col-md-10 m-auto">
							<h5><b>You are currently not subscribed to any offering. Please visit Our Offerings to subscribe.</b></h5>
							<a href="<?php echo ADMIN_SITE_PATH ?>select-plan.php" class="btn btn-secondary btn-block waves-effect waves-light p-3" style="font-size:20px;"><i class="fas fa-shopping-cart mr-1" style="font-size:20px"></i> Buy Plan </a>
						</div>
					</div>
				<?php endif; ?>
				<!-- Nav tabs -->
				<ul class="nav nav-tabs md-tabs nav-justified default-color" role="tablist" style="background-color: #4A94CF;">
					<li class="nav-item waves-effect waves-light">
						<a class="nav-link active" data-toggle="tab" href="#panel555" role="tab" aria-selected="true">
							<i class="fas fa-building  pr-2"></i>My Properties</a>
					</li>
				</ul>
				<!-- Nav tabs -->

				<!-- Tab panels -->
				<div class="tab-content">
					<div class="tab-pane fade in active show" id="panel555" role="tabpanel">
						<div class="row" id="home">

						</div>
					</div>

				</div>
				<!-- Tab panels -->

			</section>
		</div>
		<!--Modal: Edit Property Form-->
		<div class="modal fade" id="modalPropertyEdit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog cascading-modal modal-avatar modal-xl " role="document">
				<!--Content-->
				<div class="modal-content">

					<!--Header-->
					<div class="modal-header">
						<div class="my-floating-button" style="position:absolute;top: 5px; left: 24px;width: 50px;height: 50px;">
							<a href="javascript:;" class="btn-floating btn-lg blue-gradient waves-effect waves-light" onclick="edit_data('add_property_form')">
								<i class="fas fa-save"></i>
							</a>
						</div>
						<img src="dist/img/prop-icon.png" alt="avatar" class="rounded-circle img-responsive">
						<a href="javascript:;" class="btn  btn-floating  btn-danger btn-small  waves-effect waves-light top-right-close" data-dismiss="modal" aria-label="Close">
							<i class="fas fa-times"></i>
						</a>
					</div>
					<!--Body-->
					<div class="modal-body text-center mb-1">

						<h5 class="mt-1 mb-2">Edit Property</h5>
						<form onsubmit="return false;" id='add_property_form'>
							<div class="row  ml-0 mr-0" id="form-container">

							</div>
						</form>

						<div class="text-center mt-4">
							<button class="btn blue-gradient btn-block btn-rounded z-depth-1a waves-effect waves-light" onclick="edit_data('add_property_form')">SAVE </button>
						</div>
					</div>

				</div>
				<!--/.Content-->
			</div>
		</div>
		<!--Modal: Edit Property Form-->

		<!--Modal: View Property Form-->
		<div class="modal fade" id="modalPropertyView" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-xl cascading-modal modal-avatar  " role="document">
				<!--Content-->
				<div class="modal-content">

					<!--Header-->
					<div class="modal-header">
						<img src="dist/img/prop-icon.png" alt="avatar" class="rounded-circle img-responsive">
						<a href="javascript:;" class="btn  btn-floating  btn-danger btn-small  waves-effect waves-light top-right-close" data-dismiss="modal" aria-label="Close">
							<i class="fas fa-times"></i>
						</a>
					</div>
					<!--Body-->
					<div class="modal-body text-center mb-1">

						<h5 class="mt-1 mb-2">Property</h5>
						<div class="container  ml-0 mr-0" id="view-container">

						</div>

						<div class="text-center mt-4">

						</div>
					</div>

				</div>
				<!--/.Content-->
			</div>
		</div>
		<!--Modal: View Property Form-->

		<script type="text/javascript">
			var property_data = {};
			var city_id;
			var taluka_id;
			var toolsAll = {};
			var tools = {};
			var form_config = JSON.parse('<?php echo json_encode($form_config) ?>');
			var property_labels = JSON.parse('<?php echo json_encode($property_labels) ?>');
			var formFields = form_config['fields'];
			var required = form_config['required'];
			$(document).ready(function() {
				//createForm(formFields)
			});

			function edit_popup(notice_id) {
				$('#form-container').html('');
				// alert("edit_popup");
				$('#edit_notice_id').val(notice_id);
				var formData = {};
				formData['id'] = notice_id;
				jsonData = JSON.stringify(formData);
				$.ajax({
					type: "POST",
					url: "<?php echo API_ROUTE_PATH ?>property_detail.php",
					data: jsonData,
					dataType: 'json',
					cache: false,
					success: function(response) {
						console.log(response);
						var view_data = response.response[0];
						var form_config_copy = $.extend(true, {}, form_config);
						form_config_copy['data'] = view_data;
						var formHtml = createForm(form_config_copy);
						$('#form-container').html(formHtml);
						initVillageTypeAhead();
						// $('#edit_image_link').attr('href',view_data.image);
						//$('#edit_image_preview').attr('src', view_data.image);
						//$('#edit_image_preview').append('<a href =' + view_data.image + '></a>')
						// document.getElementById("edit_title").innerHTML = "Public Notice";
						//   $("#edit_notice_title").val(view_data.title);
						property_data = view_data;
						$("#state").val(view_data.state);
						getCities('#state').then(function(value) {
							$("#city").val(view_data.city);
							getTalukas('#city').then(function(value) {
								$("#taluka").val(view_data.taluka);
								getVillages('#taluka').then(function(value) {
									console.log(view_data.village);
									$("#village").val(view_data.village);
								});
							});
						});
					}
				});

				//$('#editModalNotice').modal('show');
				//$("#editNoticeButton").unbind('click');
				$('#modalPropertyEdit').modal('show');
				$('#modalPropertyEdit').on('shown.bs.modal', function() {
					$("#modalPropertyEdit .modal-body").scrollTop(0);
				});
				$("#editNoticeButton").unbind('click');
				//  $('#editNoticeButton').on('click', function(e) {
				// $('#editModalNotice').modal('hide');
				// });
			}

			/* $('#add_property_form').on('submit', function() {
				edit_data(this);
			}); */

			function edit_data(formId) {
				var isOk = true;
				$.each(form_config['fields'], function(field, fieldConfig) {

					if (fieldConfig['required']) {
						console.log(field);
						if ($.trim($('#' + field + '').val()) == '') {
							isOk = false;
							showErrorOnElement(field, 'Required');
						} else {
							resetElementState(field, '');
						}
					}
				});

				if (isOk) {
					$('#modalPropertyEdit').modal('hide');
					// alert(that);
					var formData = new FormData(document.getElementById(formId));

					formData.append('owner_name', '');
					formData.append('property_number', '');
					formData.append('email', '');

					$.ajax({
						type: "POST",
						url: '<?php echo API_ROUTE_PATH ?>update_property.php',
						data: formData,
						dataType: 'json',
						contentType: false,
						processData: false,
						cache: false,
						success: function(response) {
							//console.log(response);
							//search_notice();
							if (response.status == "true") {
								//alert(response.message);
								//   $('#success_message').html(response.message);
								// // $(".alert").show();
								// $(".alert").fadeTo(2000, 500).slideUp(500, function(){

								//   $(".alert").slideUp(500);
								// });
								search_notice();
							} else {
								alert('Error to Update');
							}
						}
					});
				}

			}

			function createPropertyHtmlForTabs(data) {
				var editButton = '';
				if (data['date']) {
					var mySqlDate = new Date(data['date']);
					var jsDateToday = new Date();
					var diff = jsDateToday - mySqlDate;
					//if (diff < 86400000) {
					editButton = '<a href="#" class="col-md-2 btn  btn-floating  btn-info btn-small  waves-effect waves-light" style="color:white;" onclick ="edit_popup(' + data.property_id + ')"><i class="fas fa-edit"></i></a>';
					//}
				}
				var html = '' +
					'<div class="col-md-4" >' +
					'<div class="small-box bg-info" id="block" name="">' +
					'<div class="inner" style="background-color: white;color: black;">' +
					'<div class="form-group datastyle" style="margin-bottom: 0rem;">' +
					'<input type="hidden" id="id" name="id" value=:' + data.property_id + '>' +
					//'<label id="title" name="title" style="font-weight: 400;" ><b>Property Title: </b> '+dynamic_data[i].title+'</label></br>'+						 
					'<label style="font-weight: 400;margin-right:10px;"  ><b>City: </b>' + data.city + '</label></br>' +
					'<label style="font-weight: 400;" ><b>Taluka: </b>' + data.taluka + '</label></br>' +
					'<label style="font-weight: 400;" ><b>Village: </b>' + data.village + '</label></br>' +
					// '</div>'+
					// '<hr>'+
					// '<div class="form-group">'+
					//'<label style="font-weight: 400;" ><b>Survey Number: </b>' + data.survey_number + '</label></br>' +
					// '<label style="font-weight: 400;" id="publisher_name" name="publisher_name">Publisher Name: <b>'+dynamic_data[i].publisher_name+'</b></label></br>'+
					// '<label style="font-weight: 400;" id="Publisher_contact" name="Publisher_contact">Publisher Contact Number: <b>'+dynamic_data[i].publisher_contact+'</b></label></br>'+
					'</div>' +
					'</div>' +
					'<div class="small-box-footer" style="">' +
					'<a href="javascript:;" class="col-md-2 btn btn-secondary  btn-floating btn-small  waves-effect waves-light" style="color:white;"  onclick ="viewModal(' + data.property_id + ')"><i class="fas fa-eye"></i> </a>' +
					editButton

				'</div>' +
				'</div>' +
				'</div>';
				return html;
			}

			function search_notice() {
				var city_search = $('#city_search option:selected').text()
				var taluka_search = $('#taluka_search option:selected').text()
				var village_search = $('#village_search option:selected').text()
				// var publisher_name_search = $('#publisher_name_search').val();
				// var publisher_contact_search = $('#publisher_contact_search').val();
				var survey_no_search = $('#survey_no_search').val();
				var tp_no_search = $('#tp_no_search').val();
				var cts_no_search = $('#cts_no_search').val();
				var block_no_search = $('#block_no_search').val();
				var fp_no_search = $('#fp_no_search').val();
				var user_id = document.getElementById("user_id").value;
				$.ajax({
					type: "POST",
					url: '<?php echo API_ROUTE_PATH ?>admin_properties_api.php',
					data: {
						user_id: user_id,
						city_search: '',
						taluka_search: '',
						village_search: '',
						survey_no_search: '',
						tp_no_search: '',
						cts_no_search: '',
						block_no_search: '',
						fp_no_search: '',

					},
					dataType: 'json',
					cache: false,
					success: function(response) {
						var count = response.Totalcount;
						var dynamic_data = response.data;
						var home_count = 0;
						$('#home').empty();
						for (var i = 0; i < count; i++) {
							home_count++;
							$html = createPropertyHtmlForTabs(dynamic_data[i]);
							$('#home').append($html);
						}
						if (home_count < 1) {
							$('#home').append('<div  class="col-md-12" style="padding-left:45%;"><p>No Properties Found</p></div>');
						}
						// $('#exampleModalCenter').modal('hide');

					}
				});

			}

			function viewModal(id) {
				console.log(id);
				var formData = {};
				formData['id'] = id;
				jsonData = JSON.stringify(formData);
				$.ajax({
					type: "POST",
					url: "<?php echo API_ROUTE_PATH ?>property_detail.php",
					data: jsonData,
					dataType: 'json',
					/* dataType: 'jsonp',
					cors: true,
					contentType: 'application/json',
					secure: true,
					headers: {
						'Access-Control-Allow-Origin': '*',
					}, 
					cache: false,*/
					success: function(response) {
						console.log(response);
						var view_data = response.response[0];
						//$("#preivew_view").append('<a href ="' + view_data.image + '" target="_blank" ><img src="' + view_data.image + '" width="150px;" height="150px" class="center"><p style="margin-left:40%;">Property Image</p></a>');
						var html = ''
						$.each(view_data, function(key, value) {
							if ($.trim(value) != '') {
								var label = key;
								if (property_labels[key]) {
									label = property_labels[key];
									html += '<div class="row"><div class="col-5 h3">' + label + '</div><div class="col-1 h3 text-center">::</div><div class="col-5 h3 text-left">' + value + '</div></div>';

								}
							}

						});

						$('#view-container').html(html);
					}
				});
				$('#modalPropertyView').modal('show');
				$('#modalPropertyView').on('shown.bs.modal', function() {
					$("#modalPropertyView .modal-body").scrollTop(0);
				});
			}

			function getCities($this) {
				return new Promise(function(resolve, reject) {
					$.ajax({
						type: "POST",
						url: "<?php echo API_ROUTE_PATH ?>city.php",
						data: JSON.stringify({
							state_id: '1'
						}),
						dataType: 'json',
						cache: false,
						success: function(result) {
							//var city_decode = $.parseJSON(result);
							var city_decode = result;
							var city_list = city_decode.response;
							var city_len = city_list.length;
							$("#city").empty();
							$("#city").append('<option selected="true" name =""  disabled="disabled" value = "" >Please Select City</option>');
							for (var k = 0; k < city_len; k++) {
								if (property_data.city == city_list[k]['city']) {
									city_id = city_list[k]['city_id'];
								}
								$("#city").append("<option name ='" + city_list[k]['city_id'] + "'  value='" + city_list[k]['city'] + "'>" + city_list[k]['city'] + "</option>");
							}
							resolve(result);
						}
					});
				});
			}

			function getTalukas($this) {
				return new Promise(function(resolve, reject) {
					city_id = $($this).find('option:selected').attr("name");
					console.log($($this).val());
					$.ajax({
						type: "POST",
						url: "<?php echo API_ROUTE_PATH ?>taluka.php",
						data: JSON.stringify({
							city_id: city_id
						}),
						dataType: 'json',
						cache: false,
						success: function(result) {
							//var taluka_decode = $.parseJSON(result);
							var taluka_decode = result;
							var taluka_list = taluka_decode.response;
							var taluka_len = taluka_list.length;
							$("#taluka").empty();
							$("#taluka").append('<option selected="true" name ="" disabled="disabled" value = "" >Please Select Taluka</option>');
							for (var i = 0; i < taluka_len; i++) {
								if (property_data.taluka == taluka_list[i]['taluka']) {
									taluka_id = taluka_list[i]['taluka_id'];
								}
								$("#taluka").append("<option  name ='" + taluka_list[i]['taluka_id'] + "' value='" + taluka_list[i]['taluka'] + "'>" + taluka_list[i]['taluka'] + "</option>");
							}
							resolve(result);
						}
					});
				});
			}

			function getVillages($this) {
				return new Promise(function(resolve, reject) {
					city_id = $($this).find('option:selected').attr("name");
					$.ajax({
						type: "POST",
						url: "<?php echo API_ROUTE_PATH ?>village.php",
						data: JSON.stringify({
							taluka_id: taluka_id
						}),
						dataType: 'json',
						cache: false,
						success: function(result_data) {
							/* var village_decode = $.parseJSON(result_data);
							var village_list = village_decode.response;
							var village_len = village_list.length;
							$("#village").empty();
							$("#village").append('<option name ="" value = "" selected="true" disabled="disabled">Please Select Village</option>');
							for (var j = 0; j < village_len; j++) {
								$("#village").append("<option name ='" + village_list[j]['village'] + "' value='" + village_list[j]['village'] + "'>" + village_list[j]['village'] + "</option>");
							} */
							resolve(result_data);
						}
					});
				});
			}
			$(document).ready(function() {
				search_notice();

				$('body').on('change', '#state', function() {
					getCities(this);
				});

				/**taluka depend on city change */
				$('body').on('change', '#city', function() {
					city_id = $(this).val();
					getTalukas(this);
				});

				/** village change on taluka */
				$('body').on('change', '#taluka', function() {
					taluka_id = $(this).val();
					getVillages(this);
				});

			});
		</script>

		<script>
			$(document).ready(function() {
				initVillageTypeAhead()
			});

			function initVillageTypeAhead() {
				var countries = new Bloodhound({
					datumTokenizer: Bloodhound.tokenizers.obj.whitespace('village_name'),
					queryTokenizer: Bloodhound.tokenizers.whitespace,
					//prefetch: '<?php echo $site_path ?>countries2.json',
					//local:dattum,
					//cache: false //NEW!
					remote: {
						url: '<?php echo API_ROUTE_PATH ?>village-typeahead.php?query=%QUERY',
						wildcard: '%QUERY',
						rateLimitWait: 500,
						transform: function(response) {
							//console.log(response);
							//eval(response.jsFunction);
							//return response.rows;
							return response;
						},
						cache: false //NEW!
					},
					limit: 20
					//local:dattum,

				});
				countries.clearPrefetchCache();
				countries.initialize();
				$('#village').typeahead({
					minLength: 2,
					hint: true,
					highlight: true,

				}, {
					name: 'village',
					display: 'village',
					limit: 20,
					source: countries.ttAdapter(),
				});
			}
		</script>
		<?php include_once "tpl/tplFooter.php"; ?>
		<script src="custom_js/create_form.js" type="text/javascript"></script>
		<script src="dist/plugins/typeahead/typeahead.bundle.min.js" type="text/javascript"></script>
</body>

</html>