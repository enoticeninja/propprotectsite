<?php
header('location: my-properties.php');
exit();
include_once 'bootstrap.php';
include_once 'common.php';
$TITLE = 'Home';

?>
<html>

<head>
	<?php include_once 'tpl/tplHead.php'; ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
	<style>
		.center {
			display: block;
			margin-left: auto;
			margin-right: auto;
		}

		.modal-dialog {
			overflow-y: initial !important
		}

		.modal-body {
			height: 520px;
			overflow-y: auto;
		}

		.alert {
			display: none;
		}

		.alert-success {
			color: #1cb722;
			background: #c6e4a3;
			border-color: #23923d;
		}

		.nav-pills .nav-link:not(.active):hover {
			color: white;
		}
	</style>
	<div class="wrapper">

		<?php include_once 'tpl/tplHeader.php'; ?>
		<?php include_once 'tpl/tplSidebar.php'; ?>

		<div class="content-wrapper">
			<!-- Main content -->
			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<input type="hidden" id="user_id" name="id" value="<?php echo $user_id ?>">

							<div class="card">
								<!-- /.card-header -->
								<div class="row">
									<div class="col-12 col-sm-12">
										<div class="card card-primary card-tabs">
											<div class="alert alert-success alert-dismissable">
												<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
												<strong id="success_message"></strong>
											</div>
											<div class="card-header p-0 pt-1" style="background-color: #6c757d;">
												<ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
													<li class="nav-item">
														<a class="nav-link active" id="custom-tabs-one-home_flat-tab" data-toggle="pill" href="#custom-tabs-one-home_flat" role="tab" aria-controls="custom-tabs-one-home_flat" aria-selected="true">Home/Flat</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" id="custom-tabs-one-shop_office-tab" data-toggle="pill" href="#custom-tabs-one-shop_office" role="tab" aria-controls="custom-tabs-one-shop_office" aria-selected="false">Shop/Office</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" id="custom-tabs-one-plot_land-tab" data-toggle="pill" href="#custom-tabs-one-plot_land" role="tab" aria-controls="custom-tabs-one-plot_land" aria-selected="false">Plot/Land</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" id="custom-tabs-one-brh-tab" data-toggle="pill" href="#custom-tabs-one-brh" role="tab" aria-controls="custom-tabs-one-brh" aria-selected="false">Bungalow/RowHouse</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" id="custom-tabs-one-industry-tab" data-toggle="pill" href="#custom-tabs-one-industry" role="tab" aria-controls="custom-tabs-one-industry" aria-selected="false">Industry</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" id="custom-tabs-one-other-tab" data-toggle="pill" href="#custom-tabs-one-other" role="tab" aria-controls="custom-tabs-one-other" aria-selected="false">Other</a>
													</li>
													<!-- <li class="nav-item">
								<a class="nav-link" id="custom-tabs-one-industry-tab" href="http://www.nanostuffs.com/lawyer/admin/notice_add_page.php"><i class="fa fa-plus-circle "  style="font-size:30px;color:#007bff;" ></i></a>
							  </li> -->

												</ul>
											</div>
											<div class="card-body">
												<div class="tab-content" id="custom-tabs-one-tabContent">
													<div class="tab-pane fade show active" id="custom-tabs-one-home_flat" role="tabpanel" aria-labelledby="custom-tabs-one-home_flat-tab">
														<div class="row">
															<div class="col-md-11"></div>
															<div class="col-md-1"><a href="http://www.nanostuffs.com/lawyer/admin/notice_add_page.php"><i class="fa fa-plus-circle " style="font-size:30px;color:#007bff;float: right;"></i></a></div>
														</div>
														<div class="row" id="home" style="margin-top:1%;">
														</div>
													</div>
													<div class="tab-pane fade" id="custom-tabs-one-shop_office" role="tabpanel" aria-labelledby="custom-tabs-one-shop_office-tab">
														<div class="row">
															<div class="col-md-11"></div>
															<div class="col-md-1"><a href="http://www.nanostuffs.com/lawyer/admin/notice_add_page.php"><i class="fa fa-plus-circle " style="font-size:30px;color:#007bff;float: right;"></i></a></div>
														</div>
														<div class="row" id="shop" style="margin-top:1%;">
														</div>
													</div>
													<div class="tab-pane fade" id="custom-tabs-one-plot_land" role="tabpanel" aria-labelledby="custom-tabs-one-plot_land-tab">
														<div class="row">
															<div class="col-md-11"></div>
															<div class="col-md-1"><a href="http://www.nanostuffs.com/lawyer/admin/notice_add_page.php"><i class="fa fa-plus-circle " style="font-size:30px;color:#007bff;float: right;"></i></a></div>
														</div>
														<div class="row" id="plot" style="margin-top:1%;">
														</div>
													</div>
													<div class="tab-pane fade" id="custom-tabs-one-brh" role="tabpanel" aria-labelledby="custom-tabs-one-brh-tab">
														<div class="row">
															<div class="col-md-11"></div>
															<div class="col-md-1"><a href="http://www.nanostuffs.com/lawyer/admin/notice_add_page.php"><i class="fa fa-plus-circle " style="font-size:30px;color:#007bff;float: right;"></i></a></div>
														</div>
														<div class="row" id="banglo" style="margin-top:1%;">
														</div>
													</div>
													<div class="tab-pane fade" id="custom-tabs-one-industry" role="tabpanel" aria-labelledby="custom-tabs-one-industry-tab">
														<div class="row">
															<div class="col-md-11"></div>
															<div class="col-md-1"><a href="http://www.nanostuffs.com/lawyer/admin/notice_add_page.php"><i class="fa fa-plus-circle " style="font-size:30px;color:#007bff;float: right;"></i></a></div>
														</div>
														<div class="row" id="industry" style="margin-top:1%;">
														</div>
													</div>
													<div class="tab-pane fade" id="custom-tabs-one-other" role="tabpanel" aria-labelledby="custom-tabs-one-other-tab">
														<div class="row">
															<div class="col-md-11"></div>
															<div class="col-md-1"><a href="http://www.nanostuffs.com/lawyer/admin/notice_add_page.php"><i class="fa fa-plus-circle " style="font-size:30px;color:#007bff;float: right;"></i></a></div>
														</div>
														<div class="row" id="other" style="margin-top:1%;">
														</div>
													</div>
												</div>
											</div>
											<!-- /.card -->
										</div>
									</div>
								</div>
								<!-- /.card -->
							</div><!-- /.container-fluid -->
			</section>
		</div>

		<!-- start search modal -->
		<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLongTitle">Search</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>City : </label>
									<select class="custom-select city_search" name="city_search" id="city_search">
										<option selected="true" disabled="disabled" value="">Please Select City</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Taluka : </label>
									<select class="custom-select taluka_search" name="taluka_search" id="taluka_search">
										<option selected="true" disabled="disabled" value="">Please Select Taluka</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Village : </label>
									<select class="custom-select village_search" name="village_search" id="village_search">
										<option selected="true" disabled="disabled" value="">Please Select Village</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Publisher Name : </label>
									<input type="text" id="publisher_name_search" name="publisher_name_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Publisher Contact : </label>
									<input type="text" id="publisher_contact_search" name="publisher_contact_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Survey Number : </label>
									<input type="text" id="survey_no_search" name="survey_no_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>T.P. Scheme Number : </label>
									<input type="text" id="tp_no_search" name="tp_no_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>CTS Number : </label>
									<input type="text" id="cts_no_search" name="cts_no_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Block Number : </label>
									<input type="text" id="block_no_search" name="block_no_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Final Plot Number : </label>
									<input type="text" id="fp_no_search" name="fp_no_search" class="form-control">
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary" id="searchNotice_Button">Search</button>
					</div>
				</div>
			</div>
		</div>
		<!-- end search modal here -->
		<!-- View Home/Flat Notice -->
		<div class="modal" id="viewNoticeModal">
			<div class="modal-dialog">
				<div class="modal-content">
					<!-- Modal Header -->
					<div class="modal-header">
						<label id="view_modal_title" name="view_modal_title"></label></br>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>

					<!-- Modal body -->
					<div class="modal-body">
						<div class="row clearfix">
							<div class="col-md-12">
								<div class="card-body p-0">
									<table class="table table-striped">
										<tbody>
											<tr>
												<div id="preivew_view"></div>
											</tr>
											<tr>
												<td width="50%">Notice Type : </td>
												<td width="50%" id="view_notice_type"></td>
											</tr>
											<tr>
												<td width="50%">Published Date : </td>
												<td width="50%" id="view_published_date"></td>
											</tr>
											<tr>
												<td width="50%">State :</td>
												<td width="50%" id="view_state"></td>
											</tr>
											<tr>
												<td width="50%">District :</td>
												<td width="50%" id="view_district"></td>
											</tr>
											<tr>
												<td width="50%">Taluka :</td>
												<td width="50%" id="view_taluka"></td>
											</tr>
											<tr>
												<td width="50%">Village :</td>
												<td width="50%" id="view_village"></td>
											</tr>
											<tr>
												<td width="50%">Property Type : </td>
												<td width="50%" id="view_property_type"></td>
											</tr>
											<!-- <tr>
                  <td width="50%">Property Detail :</td>
                  <td width="50%" id = "view_property_details"></td>
                </tr> -->
											<tr>
												<td width="50%">Property Number : </td>
												<td width="50%" id="view_property_number"></td>
											</tr>
											<tr>
												<td width="50%">Publisher Name : </td>
												<td width="50%" id="view_publisher_name"></td>
											</tr>
											<tr>
												<td width="50%">Publisher Profile : </td>
												<td width="50%" id="view_publisher_profile"></td>
											</tr>
											<tr>
												<td width="50%">Publisher Contact Number :</td>
												<td width="50%" id="view_publisher_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">NewsPaper : </td>
												<td width="50%" id="view_newspaper"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Newspaper Edition : </td>
												<td width="50%" id="view_newspaper_edition"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Name of Owner/Developer : </td>
												<td width="50%" id="view_owner_name"></td>
											</tr>
											<tr>
												<td width="50%">Survey Number : </td>
												<td width="50%" id="view_survey_number"></td>
											</tr>
											<tr>
												<td width="50%">GLR Survey Number : </td>
												<td width="50%" id="view_glr_survey_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Hissa Number : </td>
												<td width="50%" id="view_hissa_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Location Name :</td>
												<td width="50%" id="view_area_name"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Society/Apartment/Complex Name : </td>
												<td width="50%" id="view_society_name"></td>
											</tr>

											<tr style="display:none">
												<td width="50%">Building Name :</td>
												<td width="50%" id="view_building_name"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Building Number :</td>
												<td width="50%" id="view_building_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Wing Number :</td>
												<td width="50%" id="view_wing_number"></td>
											</tr>

											<tr style="display:none">
												<td width="50%">Plot No. / Bhukhand No. / Land No. :</td>
												<td width="50%" id="view_plot_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Final Plot Number :</td>
												<td width="50%" id="view_fp_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Floor Number :</td>
												<td width="50%" id="view_floor_number"></td>
											</tr>

											<tr style="display:none">
												<td width="50%">Block Number : </td>
												<td width="50%" id="view_block_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">T.P. Scheme Number : </td>
												<td width="50%" id="view_tp_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">CTS Number :</td>
												<td width="50%" id="view_cts_number"></td>
											</tr>

											<tr style="display:none">
												<td width="50%">Zone Number :</td>
												<td width="50%" id="view_zone_number"></td>
											</tr>
											<!-- <tr>
                  <td width="50%">Home/Flat Name :</td>
                  <td width="50%" id ="view_home_flat_name"></td>
                </tr> -->
											<tr style="display:none">
												<td width="50%">Gat Number :</td>
												<td width="50%" id="view_gat_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Sector Number :</td>
												<td width="50%" id="view_sector_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Unit Number :</td>
												<td width="50%" id="view_unit_number"></td>
											</tr>
											<tr style="display:none">
												<td width="50%">Others :</td>
												<td width="50%" id="view_others"></td>
											</tr>
											<!-- <tr>
				 <tr style="display:none">
                  <td width="50%">Apartment Number :</td>
                  <td width="50%" id = "view_apartment_number"></td>
                </tr>
                 <tr style="display:none">
                  <td width="50%">Row House Number :</td>
                  <td width="50%" id = "view_row_house_number"></td>
                </tr>
                 <tr style="display:none">
                  <td width="50%">Flat Number :</td>
                  <td width="50%"  id = "view_flat_number"></td>
                </tr>
                
                 <tr style="display:none">
                  <td width="50%">Bungalow Number :</td>
                  <td width="50%" id = "view_bungalow_number"></td>
                </tr>
                 <tr style="display:none">
                  <td width="50%">Shop Number :</td>
                  <td width="50%" id = "view_home_number"></td>
                </tr>
                 <tr style="display:none">
                  <td width="50%">Office Number :</td>
                  <td width="50%" id = "view_office_number"></td>
                </tr>
                  <td width="50%">Street Number :</td>
                  <td width="50%" id="view_streetnumber"></td>
                </tr> -->
										</tbody>
									</table>
								</div>

							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						</div>

					</div>
				</div>
			</div>
		</div>
		<!-- /End.View Home/Flat Notice -->
		<!-- start Delete  Modal -->
		<div id="deleteModalNotice" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content" style="height:220px;">
					<div class="modal-header">
						<h3>Delete Notice</h3>
					</div>
					<div class="modal-body">
						<p>Are you sure you want to delete this notice ?</p>
					</div>
					<div class="modal-footer">
						<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
						<button class="btn btn-primary" id="deleteNoticeButton">Delete</button>
					</div>
				</div>
			</div>
		</div>
		<!-- End Delete Modal -->
		<!-- start FavModalNotice  Modal -->
		<div id="FavModalNotice" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content" style="height:220px;">
					<div class="modal-header">
						<h3>Notice</h3>
					</div>
					<div class="modal-body">
						<p>Are you sure you want to make this notice favourite ?</p>
					</div>
					<div class="modal-footer">
						<button class="btn" data-dismiss="modal" aria-hidden="true">No</button>
						<button class="btn btn-primary" id="favNoticeButton">Yes</button>
					</div>
				</div>
			</div>
		</div>
		<!-- End FavModalNotice Modal -->
		<!-- start unFavModalNotice  Modal -->
		<div id="unFavModalNotice" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content" style="height:220px;">
					<div class="modal-header">
						<h3>Notice</h3>
					</div>
					<div class="modal-body">
						<p>Are you sure you want to make this notice unfavourite ?</p>
					</div>
					<div class="modal-footer">
						<button class="btn" data-dismiss="modal" aria-hidden="true">No</button>
						<button class="btn btn-primary" id="unfavNoticeButton">Yes</button>
					</div>
				</div>
			</div>
		</div>
		<!-- End unFavModalNotice Modal -->
		<!-- /.Edit Home/Flat Notice -->

		<div class="modal" id="editModalNotice">
			<div class="modal-dialog">
				<div class="modal-content">
					<!-- Modal Header -->
					<div class="modal-header">
						<label id="edit_title" name="edit_title"></label></br>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>

					<!-- Modal body -->
					<div class="modal-body">
						<div class="row clearfix">
							<div class="col-md-12">
								<div class="card-body p-0">
									<form onsubmit="edit_data(this);  return false;" id='add_property_form' enctype="multipart/form-data">
										<input type="hidden" class="form-control" id="edit_notice_id" />
										<table class="table table-striped" style="margin-top: -5%;">
											<tbody>
												<tr>
													<img id="edit_image_preview" src="#" class="center" width="150px;" height="150px" />
													<label for="edit_file" style="margin-left: 33%;">Select Notice Image</label>
													<input type="file" id="edit_file" name="file" accept="image/*" style="visibility:hidden;">
												</tr>
												<!-- <tr>
                      <td width="50%">Notice Title <span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
                      <td width="50%" > <input type="text" class="form-control" id="edit_notice_title" name="edit_notice_title"  placeholder="Enter notice title " required></td>
                    </tr>-->
												<tr>
													<td width="50%">Notice Type<span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
													<td width="50%">
														<select class="custom-select" id="edit_notice_type" name="edit_notice_type" required>
															<option value="" selected="selected" disabled>Please select notice type</option>
															<option value="Legal">Legal</option>
															<option value="Bank">Bank</option>
															<option value="Government">Government</option>
															<option value="self Upload">self Upload</option>
														</select>
													</td>
												</tr>
												<tr>
													<td width="50%">Published Date<span aria-hidden="true" class="required" style="color: red;">*</span> :</td>
													<td width="50%"> <input type="date" class="form-control" id="edit_notice_date" name="edit_notice_date" placeholder="Enter published date " required></td>
												</tr>
												<tr>
													<td width="50%">State<span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
													<td width="50%">
														<select class="custom-select State" id="edit_state" name="edit_state" required>
															<option value="" selected="true" disabled="disabled">Please Select State</option>
															<option value="Maharashtra">Maharashtra</option>
														</select>
														</select>
													</td>
												</tr>
												<tr>
													<td width="50%">District<span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
													<td width="50%"><select class="custom-select city" name="edit_city" id="edit_city" required>
														</select>
													</td>
												</tr>
												<tr>
													<td width="50%">Taluka<span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
													<td width="50%">
														<select class="custom-select" id="edit_taluka" name="edit_taluka" required>
														</select>
													</td>
												</tr>
												<tr>
													<td width="50%">Village<span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
													<td width="50%">
														<select class="custom-select" id="edit_village" name="edit_village" required>
															<option value="" selected="true" disabled="disabled"></option>
														</select>
													</td>
												</tr>

												<tr>
													<td width="50%">Property Type<span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
													<td width="50%">
														<select class="custom-select" id="edit_property_type" name="edit_property_type" required>
															<option value="" selected="selected" disabled>Please select property type</option>
															<option value="Home/Flat">Home/Flat</option>
															<option value="Shop/Office">Shop/Office</option>
															<option value="Plot/Land">Plot/Land</option>
															<option value="Bungalow/RowHouse">Bungalow/RowHouse</option>
															<option value="Industry">Industry</option>
														</select>
													</td>
												</tr>
												<!-- <tr>
                      <td width="50%">Property Detail :</td>
                      <td width="50%"><input class="form-control" id="edit_property_details" name="edit_property_details" type="text"  /> </td>
                    </tr> -->
												<tr>
													<td width="50%">Property Number<span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
													<td width="50%"><input class="form-control" id="edit_propertynumber" name="edit_propertynumber" type="text" required /> </td>
												</tr>
												<tr>
													<td width="50%">Publisher Name<span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
													<td width="50%"><input class="form-control" id="edit_publisher_name" name="edit_publisher_name" type="text" required /> </td>
												</tr>
												<tr>
													<td width="50%">Publisher Profile <span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
													<td width="50%"><input class="form-control" id="edit_publisher_profile" name="edit_publisher_profile" type="text" required /> </td>
												</tr>
												<tr>
													<td width="50%">Publisher Contact<span aria-hidden="true" class="required" style="color: red;">*</span>:</td>
													<td width="50%"><input type="tel" pattern="[0-9]{10}" class="form-control" id="edit_publisher_contact" name="edit_publisher_contact" type="text" required /> </td>
												</tr>
												<tr>
													<td width="50%">News Paper : </td>
													<td width="50%"><input class="form-control" id="edit_newspaper" name="edit_newspaper" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">Newspaper Edition : </td>
													<td width="50%"><input class="form-control" id="edit_newspaper_edition" name="edit_newspaper_edition" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">Name of Owner/Developer : </td>
													<td width="50%"><input class="form-control" id="edit_owner_name" name="edit_owner_name" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">Survey Number : </td>
													<td width="50%"><input class="form-control" id="edit_survey_number" name="edit_survey_number" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">GLR Survey Number : </td>
													<td width="50%"><input class="form-control" id="edit_glr_survey_number" name="edit_glr_survey_number" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">Hissa Number : </td>
													<td width="50%"><input class="form-control" id="edit_hissa_number" name="edit_hissa_number" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">Location Name : </td>
													<td width="50%"><input class="form-control" id="edit_area_name" name="edit_area_name" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">Society/Apartment/Complex Name : </td>
													<td width="50%"><input class="form-control" id="edit_society_name" name="edit_society_name" type="text" /></td>
												</tr>

												<tr>
													<td width="50%">Building Name : </td>
													<td width="50%"><input class="form-control" id="edit_building_name" name="edit_building_name" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">Building Number : </td>
													<td width="50%"><input class="form-control" id="edit_building_number" name="edit_building_number" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">Wing Number : </td>
													<td width="50%"><input class="form-control" id="edit_wing_number" name="edit_wing_number" type="text" /> </td>
												</tr>

												<tr>
													<td width="50%">Floor Number : </td>
													<td width="50%"><input class="form-control" id="edit_floor_number" name="edit_floor_number" type="text" /> </td>
												</tr>

												<tr>
													<td width="50%">Plot No. / Bhukhand No. / Land No. : </td>
													<td width="50%"><input class="form-control" id="edit_plot_number" name="edit_plot_number" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">Final Plot Number : </td>
													<td width="50%"><input class="form-control" id="edit_fp_number" name="edit_fp_number" type="text" /> </td>
												</tr>

												<tr>
													<td width="50%">Block Number : </td>
													<td width="50%"><input class="form-control" id="edit_block_number" name="edit_block_number" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">T.P. Scheme Number : </td>
													<td width="50%"><input class="form-control" id="edit_tp_number" name="edit_tp_number" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">CTS Number :</td>
													<td width="50%"><input class="form-control" id="edit_cts_number" name="edit_cts_number" type="text" /> </td>
												</tr>
												<tr>
													<td width="50%">Zone Number : </td>
													<td width="50%"><input class="form-control" id="edit_zonenumber" name="edit_zonenumber" type="text" /> </td>
												</tr>
												<!-- <tr>
                      <td width="50%">Home/Flat Name :</td>
                      <td width="50%"><input class="form-control" id="edit_flat_name"name="edit_flat_name" type="text" /> </td>
                    </tr> -->

												<tr>
													<td width="50%">Gat Number : </td>
													<td width="50%"><input class="form-control" id="edit_gat_number" name="edit_gat_number" type="text" /> </td>
												</tr>

												<tr>
													<td width="50%">Sector Number : </td>
													<td width="50%"><input class="form-control" id="edit_sector_number" name="edit_sector_number" type="text" /> </td>
												</tr>

												<tr>
													<td width="50%">Unit Number: </td>
													<td width="50%"><input class="form-control" id="edit_unit_number" name="edit_unit_number" type="text" /> </td>
												</tr>

												<tr>
													<td width="50%">Others : </td>
													<td width="50%"><input class="form-control" id="edit_others" name="edit_thers" type="text" /> </td>
												</tr>
												<!--    <tr>
                      <td width="50%">Apartment Number : </td>
                      <td width="50%"><input class="form-control" id="edit_apartment_number" name="edit_apartment_number" type="text"/> </td>
                    </tr>
                  <tr>
                      <td width="50%">Row House Number: </td>
                      <td width="50%"><input class="form-control" id="edit_row_house_number" name="edit_row_house_number" type="text"/> </td>
                    </tr>
					<tr>
                      <td width="50%">Flat Number : </td>
                      <td width="50%"><input class="form-control" id="edit_flat_number" name="edit_flat_number" type="text"  /> </td>
                    </tr>
                    <tr>
                      <td width="50%">Bungalow Number : </td>
                      <td width="50%"><input class="form-control" id="edit_bungalow_number" name="edit_bungalow_number" type="text"/> </td>
                    </tr>
                    <tr>
                      <td width="50%">Shop Number : </td>
                      <td width="50%"><input class="form-control" id="edit_home_number" name="edit_home_number" type="text" /> </td>
                    </tr>
                    <tr>
                      <td width="50%">Office Number : </td>
                      <td width="50%"><input class="form-control" id="edit_office_number" name="edit_office_number" type="text"  /> </td>
                    </tr>
					 <tr>
                      <td width="50%">Street Number : </td>
                      <td width="50%"><input class="form-control" id="edit_streetnumber" name="edit_streetnumber" type="text" /> </td>
                    </tr> -->
											</tbody>
										</table>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
											<input class="btn btn-primary" value="Update" type="submit" id="editNoticeButton" />
											<!-- <button type="button" class="btn btn-primary" id ="editNoticeButton">Update</button> -->
										</div>
									</form>
								</div>

							</div>
						</div>


					</div>
				</div>
			</div>

		</div>
		<!-- /.End Edit Home/Flat Notice -->

		<script type="text/javascript">
			function edit_popup(notice_id) {
				// alert("edit_popup");
				$('#edit_notice_id').val(notice_id);
				var dtToday = new Date();
				var month = dtToday.getMonth() + 1; // getMonth() is zero-based
				var day = dtToday.getDate();
				var year = dtToday.getFullYear();
				if (month < 10)
					month = '0' + month.toString();
				if (day < 10)
					day = '0' + day.toString();

				var maxDate = year + '-' + month + '-' + day;
				$('#edit_notice_date').attr('max', maxDate);
				$.ajax({
					type: "get",
					url: "../admin_notice_view_api.php",
					data: {
						id: notice_id
					},
					cache: false,
					dataType: 'json',
					success: function(response) {
						var view_data = response.data;
						$('#edit_image_preview').attr('src', view_data.image);
						document.getElementById("edit_title").innerHTML = "Public Notice";
						// $("#edit_notice_title").val(view_data.title);
						$("#edit_notice_type").val(view_data.type_notice);

						$("#edit_notice_date").val(view_data.notice_date);
						$("#edit_state").val(view_data.state);
						$.ajax({
							type: "get",
							url: "../city.php",
							data: {
								state_id: '1'
							},
							cache: false,
							success: function(result) {
								var city_decode = $.parseJSON(result);
								var city_list = city_decode.response;
								var city_len = city_list.length;
								$("#edit_city").empty();
								$("#edit_city").append('<option selected=true name = "" disabled="disabled" value = "" >Please Select City</option>');
								for (var k = 0; k < city_len; k++) {
									if (city_list[k]['city'] == view_data.city) {
										$("#edit_city").append("<option selected=true  name = '" + city_list[k]['city'] + "'value='" + city_list[k]['city_id'] + "'>" + city_list[k]['city'] + "</option>");
										$.ajax({
											type: "get",
											url: "../taluka.php",
											data: {
												city_id: city_list[k]['city_id']
											},
											cache: false,
											success: function(result) {
												var taluka_decode = $.parseJSON(result);
												var taluka_list = taluka_decode.response;
												var taluka_len = taluka_list.length;
												$("#edit_taluka").empty();
												$("#edit_taluka").append('<option selected=true disabled="disabled" value = "" >Please Select Taluka</option>');
												for (var i = 0; i < taluka_len; i++) {
													if (taluka_list[i]['taluka'] == view_data.taluka) {
														$("#edit_taluka").append("<option selected=true name ='" + taluka_list[i]['taluka'] + "' value='" + taluka_list[i]['taluka_id'] + "'>" + taluka_list[i]['taluka'] + "</option>");
														$.ajax({
															type: "get",
															url: "../village.php",
															data: {
																taluka_id: taluka_list[i]['taluka_id']
															},
															cache: false,
															success: function(result_data) {
																var village_decode = $.parseJSON(result_data);
																var village_list = village_decode.response;
																var village_len = village_list.length;
																$("#edit_village").empty();
																$("#edit_village").append('<option selected=true value = "" disabled="disabled">Please Select Village</option>');
																for (var j = 0; j < village_len; j++) {
																	if (village_list[j]['village'] == view_data.village) {
																		$("#edit_village").append("<option selected=true name ='" + village_list[j]['village'] + "' value='" + village_list[j]['village_id'] + "'>" + village_list[j]['village'] + "</option>");
																	} else {
																		$("#edit_village").append("<option name ='" + village_list[j]['village'] + "' value='" + village_list[j]['village_id'] + "'>" + village_list[j]['village'] + "</option>");
																	}
																}
															}
														});
													} else {
														$("#edit_taluka").append("<option name ='" + taluka_list[i]['taluka'] + "' value='" + taluka_list[i]['taluka_id'] + "'>" + taluka_list[i]['taluka'] + "</option>");
													}
												}
											}
										});
									} else {
										$("#edit_city").append("<option name = '" + city_list[k]['city'] + "' value='" + city_list[k]['city_id'] + "'>" + city_list[k]['city'] + "</option>");
									}
								}
							}
						});

						$("#edit_property_type").val(view_data.property_type);
						// $("#edit_property_details").val(view_data.property_detail);
						$("#edit_propertynumber").val(view_data.propertynumber);
						$("#edit_publisher_name").val(view_data.publisher_name);
						$("#edit_publisher_profile").val(view_data.publisher_profile);
						$("#edit_publisher_contact").val(view_data.publisher_contact);
						$("#edit_owner_name").val(view_data.owner_name);
						$("#edit_newspaper").val(view_data.newspaper);
						$("#edit_newspaper_edition").val(view_data.newspaper_edition);
						$("#edit_survey_number").val(view_data.survey_number);
						$("#edit_glr_survey_number").val(view_data.glr_survey_number);
						$("#edit_block_number").val(view_data.block_number);
						$("#edit_tp_number").val(view_data.tp_number);
						$("#edit_cts_number").val(view_data.cts_number);
						$("#edit_fp_number").val(view_data.fp_number);
						$("#edit_zonenumber").val(view_data.zonenumber);
						$("#edit_area_name").val(view_data.area_name);
						$("#edit_hissa_number").val(view_data.hissa_number);
						$("#edit_society_name").val(view_data.society_name);
						// $("#edit_flat_name").val(view_data.flat_name);
						// $("#edit_home_number").val(view_data.home_number);
						// $("#edit_flat_number").val(view_data.flat_number);
						$("#edit_building_name").val(view_data.bulding_name);
						$("#edit_building_number").val(view_data.bulding_number);
						$("#edit_wing_number").val(view_data.wing_number);
						$("#edit_plot_number").val(view_data.plot_number);
						//$("#edit_office_number").val(view_data.office_number);
						$("#edit_gat_number").val(view_data.gat_number);
						// $("#edit_streetnumber").val(view_data.streetnumber);

						$("#edit_unit_number").val(view_data.unit_no);
						$("#edit_sector_number").val(view_data.sector_no);
						//$("#edit_apartment_number").val(view_data.apartment_no);
						$("#edit_floor_number").val(view_data.floor_no);
						// $("#edit_bungalow_number").val(view_data.bungalow_no);
						$("#edit_others").val(view_data.others);
						//$("#edit_row_house_number").val(view_data.row_house_no);

						var fileTag = document.getElementById("edit_file"),
							preview = document.getElementById("edit_image_preview");


						fileTag.addEventListener("change", function() {
							changeImage(this);
						});

						function changeImage(input) {
							var reader;

							if (input.files && input.files[0]) {
								reader = new FileReader();

								reader.onload = function(e) {
									preview.setAttribute('src', e.target.result);
								}

								reader.readAsDataURL(input.files[0]);
							}

						}
					}

				});

				$('#editModalNotice').modal('show');
				//  $("#editNoticeButton").unbind('click');
				//  $('#editNoticeButton').on('click', function(e) {
				//  alert("edit");
				// edit_data(notice_id);
				// $('#editModalNotice').modal('hide');
				// });
			}

			function edit_data(that) {
				// alert("edit data");
				$('#editModalNotice').modal('hide');
				var fd = new FormData(that);
				var notice_id = $('#edit_notice_id').val();
				var user_id = document.getElementById("user_id").value;
				// var title =document.getElementById("edit_notice_title").value;
				var type_notice = document.getElementById("edit_notice_type").value;
				var notice_date = document.getElementById("edit_notice_date").value;
				var property_type = document.getElementById("edit_property_type").value;
				// var property_detail = document.getElementById("edit_property_details").value;
				var newspaper = document.getElementById("edit_newspaper").value;
				var newspaper_edition = document.getElementById("edit_newspaper_edition").value;
				var state = document.getElementById("edit_state").value;
				var city = $('#edit_city').find('option:selected').attr("name");
				var taluka = $('#edit_taluka').find('option:selected').attr("name");
				var village = $('#edit_village').find('option:selected').attr("name");
				var area_name = document.getElementById("edit_area_name").value;
				var hissa_number = document.getElementById("edit_hissa_number").value;
				var block_number = document.getElementById("edit_block_number").value;
				var survey_number = document.getElementById("edit_survey_number").value;
				var glr_survey_number = document.getElementById("edit_glr_survey_number").value;
				var gat_number = document.getElementById("edit_gat_number").value;
				var cts_number = document.getElementById("edit_cts_number").value;
				var tp_number = document.getElementById("edit_tp_number").value;
				var fp_number = document.getElementById("edit_fp_number").value;
				var plot_number = document.getElementById("edit_plot_number").value;
				var zonenumber = document.getElementById("edit_zonenumber").value;
				var propertynumber = document.getElementById("edit_propertynumber").value;
				//var flat_number = document.getElementById("edit_flat_number").value;
				// var flat_name = document.getElementById("edit_flat_name").value;
				//var home_number =document.getElementById("edit_home_number").value;
				//var office_number = document.getElementById("edit_office_number").value;
				var bulding_number = document.getElementById("edit_building_number").value;
				var bulding_name = document.getElementById("edit_building_name").value;
				var wing_number = document.getElementById("edit_wing_number").value;
				// var streetnumber = document.getElementById("edit_streetnumber").value;
				var society_name = document.getElementById("edit_society_name").value;
				var publisher_name = document.getElementById("edit_publisher_name").value;
				var publisher_profile = document.getElementById("edit_publisher_profile").value;
				var publisher_contact = document.getElementById("edit_publisher_contact").value;
				var owner_name = document.getElementById("edit_owner_name").value;

				var unit_no = document.getElementById("edit_unit_number").value;
				var sector_no = document.getElementById("edit_sector_number").value;
				// var apartment_no = document.getElementById("edit_apartment_number").value;
				var floor_no = document.getElementById("edit_floor_number").value;
				// var bungalow_no = document.getElementById("edit_bungalow_number").value;
				var others = document.getElementById("edit_others").value;
				//var row_house_no = document.getElementById("edit_row_house_number").value;

				//fd.append('title',title);	
				fd.append('type_notice', type_notice);
				fd.append('notice_date', notice_date);
				fd.append('property_type', property_type);
				// fd.append('property_detail',property_detail);
				fd.append('newspaper', newspaper);
				fd.append('newspaper_edition', newspaper_edition);
				fd.append('state', state);
				fd.append('city', city);
				fd.append('taluka', taluka);
				fd.append('village', village);
				fd.append('area_name', area_name);
				fd.append('hissa_number', hissa_number);
				fd.append('block_number', block_number);
				fd.append('survey_number', survey_number);
				fd.append('glr_survey_number', glr_survey_number);
				fd.append('gat_number', gat_number);
				fd.append('plot_number', plot_number);
				fd.append('zonenumber', zonenumber);
				fd.append('cts_number', cts_number);
				fd.append('tp_number', tp_number);
				fd.append('fp_number', fp_number);
				fd.append('propertynumber', propertynumber);
				//fd.append('flat_number',flat_number);
				// fd.append('flat_name',flat_name);
				//fd.append('office_number',office_number);
				//	fd.append('home_number',home_number);
				fd.append('bulding_number', bulding_number);
				fd.append('bulding_name', bulding_name);
				fd.append('wing_number', wing_number);
				// fd.append('streetnumber',streetnumber);
				fd.append('society_name', society_name);
				fd.append('publisher_name', publisher_name);
				fd.append('publisher_profile', publisher_profile);
				fd.append('publisher_contact', publisher_contact);
				fd.append('owner_name', owner_name);
				fd.append('notice_id', notice_id);
				fd.append('user_id', user_id);

				fd.append('unit_no', unit_no);
				fd.append('sector_no', sector_no);
				//fd.append('apartment_no',apartment_no);
				fd.append('floor_no', floor_no);
				//fd.append('bungalow_no',bungalow_no);
				fd.append('others', others);
				//  fd.append('row_house_no',row_house_no);


				$.ajax({
					type: "POST",
					url: '../admin_update_notice.php',
					data: fd,
					dataType: 'json',
					contentType: false,
					processData: false,
					cache: false,
					success: function(response) {
						if (response.status == "true") {
							//  window.location.href = "http://www.nanostuffs.com/lawyer/admin/home.php";
							// window.location.href = "http://localhost/AdminLTE-3.0.5/home.php";
							//  $('#success_message').html(response.message);
							// $(".alert").show();
							// $(".alert").fadeTo(2000, 500).slideUp(500, function(){

							//   $(".alert").slideUp(500);
							// });
							alert(response.message);
							search_notice();
						} else {
							alert('Error to Update');
						}
					}
				});
				//window.location.href = "http://www.nanostuffs.com/lawyer/admin/home.php";
			}

			function delete_data(notice_id) {
				var fd = new FormData();
				var notice_id = notice_id;
				var user_id = document.getElementById("user_id").value;
				fd.append('notice_id', notice_id);
				fd.append('user_id', user_id);
				$('#deleteModalNotice').modal('show');
				$("#deleteNoticeButton").unbind('click');
				$('#deleteNoticeButton').on('click', function(e) {
					$('#deleteModalNotice').modal('hide');
					$.ajax({
						type: "POST",
						url: 'delete_notice.php',
						data: fd,
						dataType: 'json',
						contentType: false,
						processData: false,
						cache: false,
						success: function(response) {
							if (response.status == "true") {
								// $('#success_message').html(response.message);
								// // $(".alert").show();
								// $(".alert").fadeTo(2000, 500).slideUp(500, function(){

								//   $(".alert").slideUp(500);
								// });
								alert(response.message);
								search_notice();
							} else {
								alert('Error to Delete');
							}
						}
					});
				});

			}

			function favModal(notice_id, status) {
				var fd = new FormData();
				var notice_id = notice_id;
				var user_id = document.getElementById("user_id").value;
				fd.append('notice_id', notice_id);
				fd.append('user_id', user_id);
				fd.append('status', status);
				$('#FavModalNotice').modal('show');
				$("#favNoticeButton").unbind('click');
				$('#favNoticeButton').on('click', function(e) {

					$('#FavModalNotice').modal('hide');
					$.ajax({
						type: "POST",
						url: 'admin_fav_unfav_api.php',
						data: fd,
						dataType: 'json',
						contentType: false,
						processData: false,
						cache: false,
						success: function(response) {
							if (response.status == "true") {
								alert(response.message);
								// $('#success_message').html(response.message);
								// // $(".alert").show();
								// $(".alert").fadeTo(2000, 500).slideUp(500, function(){

								//   $(".alert").slideUp(500);
								// });
								search_notice();
							} else {
								alert('Error to status change');
							}
						}
					});
				});
			}

			function unfavModal(notice_id, status) {
				var fd = new FormData();
				var notice_id = notice_id;
				var user_id = document.getElementById("user_id").value;
				fd.append('notice_id', notice_id);
				fd.append('user_id', user_id);
				fd.append('status', false);
				$('#unFavModalNotice').modal('show');
				$("#unfavNoticeButton").unbind('click');
				$('#unfavNoticeButton').on('click', function(e) {

					$('#unFavModalNotice').modal('hide');
					$.ajax({
						type: "POST",
						url: 'admin_fav_unfav_api.php',
						data: fd,
						dataType: 'json',
						contentType: false,
						processData: false,
						cache: false,
						success: function(response) {
							if (response.status == "true") {
								alert(response.message);
								// $('#success_message').html(response.message);
								// $(".alert").fadeTo(2000, 500).slideUp(500, function(){

								//   $(".alert").slideUp(500);
								// });
								search_notice();
							} else {
								alert('Error to status change');
							}
						}
					});
				});
			}

			function searchFunction() {
				// alert("priyanka");


				/* taluka depend on city change */
				$(".city_search").change(function() {
					var city_id = $(this).val();
					$.ajax({
						type: "get",
						url: "../taluka.php",
						data: {
							city_id: city_id
						},
						cache: false,
						success: function(result) {
							var taluka_decode = $.parseJSON(result);
							var taluka_list = taluka_decode.response;
							var taluka_len = taluka_list.length;
							$("#taluka_search").empty();
							$("#taluka_search").append('<option selected="true" disabled="disabled" value = "" >Please Select Taluka</option>');
							for (var i = 0; i < taluka_len; i++) {
								$("#taluka_search").append("<option value='" + taluka_list[i]['taluka_id'] + "'>" + taluka_list[i]['taluka'] + "</option>");
							}
						}
					});
				});
				/* village change on taluka */
				$("#taluka_search").change(function() {
					var taluka_id = $(this).val();
					$.ajax({
						type: "get",
						url: "../village.php",
						data: {
							taluka_id: taluka_id
						},
						cache: false,
						success: function(result_data) {
							var village_decode = $.parseJSON(result_data);
							var village_list = village_decode.response;
							var village_len = village_list.length;
							$("#village_search").empty();
							$("#village_search").append('<option  value = "" selected="true" disabled="disabled">Please Select Village</option>');
							for (var j = 0; j < village_len; j++) {
								$("#village_search").append("<option value='" + village_list[j]['village_id'] + "'>" + village_list[j]['village'] + "</option>");
							}
						}
					});
				});
				$('#exampleModalCenter').modal('show');
				$("#searchNotice_Button").unbind('click');
				$('#searchNotice_Button').on('click', function(e) {
					search_notice();
					$('#exampleModalCenter').modal('hide');
				});

			}

			function search_notice() {
				var city_search = $('#city_search option:selected').text();
				var taluka_search = $('#taluka_search option:selected').text();
				var village_search = $('#village_search option:selected').text();
				var publisher_name_search = $('#publisher_name_search').val();
				var publisher_contact_search = $('#publisher_contact_search').val();
				var survey_no_search = $('#survey_no_search').val();
				var tp_no_search = $('#tp_no_search').val();
				var cts_no_search = $('#cts_no_search').val();
				var block_no_search = $('#block_no_search').val();
				var fp_no_search = $('#fp_no_search').val();
				var user_id = document.getElementById("user_id").value;
				$.ajax({
					type: "GET",
					url: '../admin_search.php',
					data: {
						user_id: user_id,
						city_search: city_search,
						taluka_search: taluka_search,
						village_search: village_search,
						publisher_name_search: publisher_name_search,
						publisher_contact_search: publisher_contact_search,
						survey_no_search: survey_no_search,
						tp_no_search: tp_no_search,
						cts_no_search: cts_no_search,
						block_no_search: block_no_search,
						fp_no_search: fp_no_search,

					},
					dataType: 'json',

					cache: false,
					success: function(response) {
						var count = response.Totalcount;
						var dynamic_data = response.data;
						var home_count = 0;
						var shop_count = 0;
						var plot_count = 0;
						var bungalow_count = 0;
						var industry_count = 0;
						var other_count = 0;

						$('#home').empty();
						$('#shop').empty();
						$('#plot').empty();
						$('#banglo').empty();
						$('#industry').empty();
						$('#other').empty();
						for (var i = 0; i < count; i++) {
							if (dynamic_data[i].property_type == 'Home/Flat') {
								home_count++;
								var home_element = '<div class="col-md-4" >' +
									'<div class="small-box bg-info" id="block" name="">' +
									'<div class="inner" style="background-color: white;color: black;">' +
									'<div class="form-group datastyle" style="margin-bottom: 0rem;">' +
									'<input type="hidden" id="id" name="id" value=' + dynamic_data[i].notice_id + '>' +
									// '<label id="title" name="title" style="font-weight: 400;" ><b>Notice Title: </b> '+dynamic_data[i].title+'</label></br>'+						 
									'<label style="font-weight: 400;margin-right:10px;" id="city" name="city" ><b>City/District: </b>' + dynamic_data[i].city + '</label>' +
									'<label style="font-weight: 400;" id="taluka" name="taluka" ><b>Taluka: </b>' + dynamic_data[i].taluka + '</label></br>' +
									'<label style="font-weight: 400;" id="village" name="village" ><b>Village: </b>' + dynamic_data[i].village + '</label></br>' +
									// '</div>'+
									// '<hr>'+
									// '<div class="form-group">'+
									'<label style="font-weight: 400;" id="survey_number" name="survey_number"><b>Survey Number: </b>' + dynamic_data[i].survey_number + '</label></br>' +
									// '<label style="font-weight: 400;" id="publisher_name" name="publisher_name"><b>Publisher Name: </b>'+dynamic_data[i].publisher_name+'</label></br>'+
									// '<label style="font-weight: 400;" id="Publisher_contact" name="Publisher_contact"><b>Publisher Contact Number: </b>'+dynamic_data[i].publisher_contact+'</label></br>'+
									'</div>' +
									'</div>' +
									'<div class="small-box-footer" style="background-color: #007bff;">';
								/*  if(dynamic_data[i].status == '1' || dynamic_data[i].status == 'true'){
								    home_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="unfavModal('+dynamic_data[i].notice_id+',0)"><i class="fa fa-star" aria-hidden="true" style="color:red;"></i></a>';
								  }else{
								    home_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="favModal('+dynamic_data[i].notice_id+',1)" disabled><i class="fa fa-star" aria-hidden="true""></i></a>';
								  }*/

								home_element += '<a href="#" class="col-md-1" style="color:white;"  onclick ="viewModal(' + dynamic_data[i].notice_id + ')"><i class="fas fa-eye"></i> </a>' +
									'<a href="#" class="col-md-1" style="color:white;" onclick ="edit_popup(' + dynamic_data[i].notice_id + ')"><i class="fas fa-edit"></i></a>' +
									'<a href="#" class="col-md-1"  style="color:white;" onclick ="delete_data(' + dynamic_data[i].notice_id + ')"><i class="fas fa-trash-alt"></i></a>' +
									'<label style="font-weight: 400;" class="col-md-12" id="date" name="date" >Published Date: ' + dynamic_data[i].notice_date + '</label></br>' +
									'</div>' +
									'</div>' +
									'</div>';
								$('#home').append(home_element);
							} else if (dynamic_data[i].property_type == 'Shop/Office') {
								shop_count++;
								var shop_element = '<div class="col-md-4" >' +
									'<div class="small-box bg-info" id="block" name="">' +
									'<div class="inner" style="background-color: white;color: black;">' +
									'<div class="form-group datastyle" style="margin-bottom: 0rem;">' +
									'<input type="hidden" id="id" name="id" value=:' + dynamic_data[i].notice_id + '>' +
									// '<label id="title" name="title" style="font-weight: 400;" ><b>Notice Title: </b>'+dynamic_data[i].title+'</label></br>'+						 
									'<label style="font-weight: 400;margin-right:10px;" id="city" name="city" ><b>City/District: </b>' + dynamic_data[i].city + '</label>' +
									'<label style="font-weight: 400;" id="taluka" name="taluka" ><b>Taluka: </b>' + dynamic_data[i].taluka + '</label></br>' +
									'<label style="font-weight: 400;" id="village" name="village" ><b>Village: </b>' + dynamic_data[i].village + '</label></br>' +
									// '</div>'+
									// '<hr>'+
									// '<div class="form-group">'+
									'<label style="font-weight: 400;" id="survey_number" name="survey_number"><b>Survey Number: </b>' + dynamic_data[i].survey_number + '</label></br>' +
									//'<label style="font-weight: 400;" id="publisher_name" name="publisher_name"><b>Publisher Name: </b>'+dynamic_data[i].publisher_name+'</label></br>'+
									//'<label style="font-weight: 400;" id="Publisher_contact" name="Publisher_contact"><b>Publisher Contact Number: </b>'+dynamic_data[i].publisher_contact+'</label></br>'+
									'</div>' +
									'</div>' +
									'<div class="small-box-footer" style="background-color: #007bff;">';
								/* if(dynamic_data[i].status == '1' || dynamic_data[i].status == 'true'){
								  shop_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="unfavModal('+dynamic_data[i].notice_id+',0)"><i class="fa fa-star" " aria-hidden="true" style="color:red;"></i></a>';
								}else{
								  shop_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="favModal('+dynamic_data[i].notice_id+',1)"disabled><i class="fa fa-star" aria-hidden="true""></i></a>';
								} */
								shop_element += '<a href="#" class="col-md-1" style="color:white;" onclick ="viewModal(' + dynamic_data[i].notice_id + ')"><i class="fas fa-eye"></i> </a>' +
									'<a href="#" class="col-md-1" style="color:white;"  onclick ="edit_popup(' + dynamic_data[i].notice_id + ')" ><i class="fas fa-edit"></i></a>' +
									'<a href="#" class="col-md-1"  style="color:white;" onclick ="delete_data(' + dynamic_data[i].notice_id + ')"><i class="fas fa-trash-alt"></i></a>' +
									'<label style="font-weight: 400;" class="col-md-12" id="date" name="date" >Published Date: ' + dynamic_data[i].notice_date + '</label></br>' +
									'</div>' +
									'</div>' +
									'</div>';
								$('#shop').append(shop_element);
							} else if (dynamic_data[i].property_type == 'Plot/Land') {
								plot_count++;
								var plot_element = '<div class="col-md-4" >' +
									'<div class="small-box bg-info" id="block" name="">' +
									'<div class="inner" style="background-color: white;color: black;">' +
									'<div class="form-group datastyle" style="margin-bottom: 0rem;">' +
									'<input type="hidden" id="id" name="id" value=:' + dynamic_data[i].notice_id + '>' +
									// '<label id="title" name="title" style="font-weight: 400;" ><b>Notice Title: </b>'+dynamic_data[i].title+'</label></br>'+						 
									'<label style="font-weight: 400;margin-right:10px;" id="city" name="city" ><b>City/District: </b>' + dynamic_data[i].city + '</label>' +
									'<label style="font-weight: 400;" id="taluka" name="taluka" ><b>Taluka: </b>' + dynamic_data[i].taluka + '</label></br>' +
									'<label style="font-weight: 400;" id="village" name="village" ><b>Village: </b>' + dynamic_data[i].village + '</label></br>' +
									// '</div>'+
									// '<hr>'+
									// '<div class="form-group">'+
									'<label style="font-weight: 400;" id="survey_number" name="survey_number"><b>Survey Number: </b>' + dynamic_data[i].survey_number + '</label></br>' +
									//'<label style="font-weight: 400;" id="publisher_name" name="publisher_name"><b>Publisher Name: </b>'+dynamic_data[i].publisher_name+'</label></br>'+
									//'<label style="font-weight: 400;" id="Publisher_contact" name="Publisher_contact"><b>Publisher Contact Number: </b>'+dynamic_data[i].publisher_contact+'</b></label></br>'+
									'</div>' +
									'</div>' +
									'<div class="small-box-footer" style="background-color: #007bff;">';
								/*  if(dynamic_data[i].status == '1' || dynamic_data[i].status == 'true'){
								   plot_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="unfavModal('+dynamic_data[i].notice_id+',0)"><i class="fa fa-star" aria-hidden="true" style="color:red;"></i></a>';
								 }else{
								   plot_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="favModal('+dynamic_data[i].notice_id+',1)" disabled><i class="fa fa-star" aria-hidden="true""></i></a>';
								 } */
								plot_element += '<a href="#" class="col-md-1" style="color:white;" onclick ="viewModal(' + dynamic_data[i].notice_id + ')"><i class="fas fa-eye"></i> </a>' +
									'<a href="#" class="col-md-1" style="color:white;"  onclick ="edit_popup(' + dynamic_data[i].notice_id + ')"><i class="fas fa-edit"></i></a>' +
									'<a href="#" class="col-md-1"  style="color:white;"onclick ="delete_data(' + dynamic_data[i].notice_id + ')"><i class="fas fa-trash-alt"></i></a>' +
									'<label style="font-weight: 400;" class="col-md-12" id="date" name="date" >Published Date: ' + dynamic_data[i].notice_date + '</label></br>' +
									'</div>' +
									'</div>' +
									'</div>';
								$('#plot').append(plot_element);
							} else if (dynamic_data[i].property_type == 'Bungalow/RowHouse') {
								bungalow_count++;
								var banglo_element = '<div class="col-md-4" >' +
									'<div class="small-box bg-info" id="block" name="">' +
									'<div class="inner" style="background-color: white;color: black;">' +
									'<div class="form-group datastyle" style="margin-bottom: 0rem;">' +
									'<input type="hidden" id="id" name="id" value=:' + dynamic_data[i].notice_id + '>' +
									//'<label id="title" name="title" style="font-weight: 400;" ><b>Notice Title: </b>'+dynamic_data[i].title+'</label></br>'+						 
									'<label style="font-weight: 400;margin-right:10px;" id="city" name="city" ><b>City/District: </b>' + dynamic_data[i].city + '</label>' +
									'<label style="font-weight: 400;" id="taluka" name="taluka" ><b>Taluka: </b>' + dynamic_data[i].taluka + '</label></br>' +
									'<label style="font-weight: 400;" id="village" name="village" ><b>Village: </b>' + dynamic_data[i].village + '</label></br>' +
									// '</div>'+
									// '<hr>'+
									// '<div class="form-group">'+
									'<label style="font-weight: 400;" id="survey_number" name="survey_number">Survey Number: <b>' + dynamic_data[i].survey_number + '</b></label></br>' +
									//'<label style="font-weight: 400;" id="publisher_name" name="publisher_name">Publisher Name: <b>'+dynamic_data[i].publisher_name+'</b></label></br>'+
									//'<label style="font-weight: 400;" id="Publisher_contact" name="Publisher_contact">Publisher Contact Number: <b>'+dynamic_data[i].publisher_contact+'</b></label></br>'+
									'</div>' +
									'</div>' +
									'<div class="small-box-footer" style="background-color: #007bff;">'
								/*  if(dynamic_data[i].status == '1' || dynamic_data[i].status == 'true'){
								   banglo_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="unfavModal('+dynamic_data[i].notice_id+',0)"><i class="fa fa-star" aria-hidden="true" style="color:red;"></i></a>';
								 }else{
								   banglo_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="favModal('+dynamic_data[i].notice_id+',1)" disabled><i class="fa fa-star" aria-hidden="true""></i></a>';
								 } */
								banglo_element += '<a href="#" class="col-md-1" style="color:white;" onclick ="viewModal(' + dynamic_data[i].notice_id + ')"><i class="fas fa-eye"></i> </a>' +
									'<a href="#" class="col-md-1" style="color:white;"  onclick ="edit_popup(' + dynamic_data[i].notice_id + ')" ><i class="fas fa-edit"></i></a>' +
									'<a href="#" class="col-md-1"  style="color:white;"onclick ="delete_data(' + dynamic_data[i].notice_id + ')"><i class="fas fa-trash-alt"></i></a>' +
									'<label style="font-weight: 400;" class="col-md-12" id="date" name="date" >Published Date: ' + dynamic_data[i].notice_date + '</label></br>' +
									'</div>' +
									'</div>' +
									'</div>';
								$('#banglo').append(banglo_element);
							} else if (dynamic_data[i].property_type == 'Industry') {
								industry_count++;
								var Industry_element = '<div class="col-md-4" >' +
									'<div class="small-box bg-info" id="block" name="">' +
									'<div class="inner" style="background-color: white;color: black;">' +
									'<div class="form-group datastyle" style="margin-bottom: 0rem;">' +
									'<input type="hidden" id="id" name="id" value=:' + dynamic_data[i].notice_id + '>' +
									//'<label id="title" name="title" style="font-weight: 400;" ><b>Notice Title: </b>'+dynamic_data[i].title+'</label></br>'+						 
									'<label style="font-weight: 400;margin-right:10px;" id="city" name="city" ><b>City/District: </b>' + dynamic_data[i].city + '</label>' +
									'<label style="font-weight: 400;" id="taluka" name="taluka" ><b>Taluka: </b>' + dynamic_data[i].taluka + '</label></br>' +
									'<label style="font-weight: 400;" id="village" name="village" ><b>Village: </b>' + dynamic_data[i].village + '</label></br>' +
									// '</div>'+
									// '<hr>'+
									// '<div class="form-group">'+
									'<label style="font-weight: 400;" id="survey_number" name="survey_number"><b>Survey Number: </b>' + dynamic_data[i].survey_number + '</label></br>' +
									//'<label style="font-weight: 400;" id="publisher_name" name="publisher_name"><b>Publisher Name: </b>'+dynamic_data[i].publisher_name+'</label></br>'+
									//'<label style="font-weight: 400;" id="Publisher_contact" name="Publisher_contact"><b>Publisher Contact Number: </b>'+dynamic_data[i].publisher_contact+'</label></br>'+
									'</div>' +
									'</div>' +
									'<div class="small-box-footer" style="background-color: #007bff;">';
								/* if(dynamic_data[i].status == '1' || dynamic_data[i].status == 'true'){
								  Industry_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="unfavModal('+dynamic_data[i].notice_id+',0)"><i class="fa fa-star" aria-hidden="true" style="color:red;"></i></a>';
								}else{
								  Industry_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="favModal('+dynamic_data[i].notice_id+',1)"disabled><i class="fa fa-star" aria-hidden="true""></i></a>';
								} */
								Industry_element += '<a href="#" class="col-md-1" style="color:white;"onclick ="viewModal(' + dynamic_data[i].notice_id + ')"><i class="fas fa-eye"></i> </a>' +
									'<a href="#" class="col-md-2" style="color:white;"  onclick ="edit_popup(' + dynamic_data[i].notice_id + ')" ><i class="fas fa-edit"></i></a>' +
									'<a href="#" class="col-md-2"  style="color:white;" onclick ="delete_data(' + dynamic_data[i].notice_id + ')"><i class="fas fa-trash-alt"></i></a>' +
									'<label style="font-weight: 400;" class="col-md-12" id="date" name="date" >Published Date: ' + dynamic_data[i].notice_date + '</label></br>' +
									'</div>' +
									'</div>' +
									'</div>';
								$('#industry').append(Industry_element);
							} else {
								other_count++;
								var other_element = '<div class="col-md-4" >' +
									'<div class="small-box bg-info" id="block" name="">' +
									'<div class="inner" style="background-color: white;color: black;">' +
									'<div class="form-group datastyle" style="margin-bottom: 0rem;">' +
									'<input type="hidden" id="id" name="id" value=:' + dynamic_data[i].notice_id + '>' +
									//'<label id="title" name="title" style="font-weight: 400;" ><b>Notice Title: </b>'+dynamic_data[i].title+'</label></br>'+						 
									'<label style="font-weight: 400;margin-right:10px;" id="city" name="city" ><b>City/District: </b>' + dynamic_data[i].city + '</label>' +
									'<label style="font-weight: 400;" id="taluka" name="taluka" ><b>Taluka: </b>' + dynamic_data[i].taluka + '</label></br>' +
									'<label style="font-weight: 400;" id="village" name="village" ><b>Village: </b>' + dynamic_data[i].village + '</label></br>' +
									// '</div>'+
									// '<hr>'+
									// '<div class="form-group">'+
									'<label style="font-weight: 400;" id="survey_number" name="survey_number"><b>Survey Number: </b>' + dynamic_data[i].survey_number + '</label></br>' +
									'<label style="font-weight: 400;" id="survey_number" name="survey_number"><b>Property Type: </b>' + dynamic_data[i].property_type + '</label></br>' +
									//'<label style="font-weight: 400;" id="publisher_name" name="publisher_name"><b>Publisher Name: </b>'+dynamic_data[i].publisher_name+'</label></br>'+
									//'<label style="font-weight: 400;" id="Publisher_contact" name="Publisher_contact"><b>Publisher Contact Number: </b>'+dynamic_data[i].publisher_contact+'</label></br>'+
									'</div>' +
									'</div>' +
									'<div class="small-box-footer" style="background-color: #007bff;">';
								/*  if(dynamic_data[i].status == '1' || dynamic_data[i].status == 'true'){
								   other_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="unfavModal('+dynamic_data[i].notice_id+',0)"><i class="fa fa-star" aria-hidden="true" style="color:red;"></i></a>';
								 }else{
								   other_element+=  '<a href="#" class="col-md-1" style="color:white;"  onclick ="favModal('+dynamic_data[i].notice_id+',1)" disabled><i class="fa fa-star" aria-hidden="true""></i></a>';
								 } */
								other_element += '<a href="#" class="col-md-1" style="color:white;"onclick ="viewModal(' + dynamic_data[i].notice_id + ')"><i class="fas fa-eye"></i> </a>' +
									'<a href="#" class="col-md-2" style="color:white;"  onclick ="edit_popup(' + dynamic_data[i].notice_id + ')" ><i class="fas fa-edit"></i></a>' +
									'<a href="#" class="col-md-2"  style="color:white;" onclick ="delete_data(' + dynamic_data[i].notice_id + ')"><i class="fas fa-trash-alt"></i></a>' +
									'<label style="font-weight: 400;" class="col-md-12" id="date" name="date" >Published Date: ' + dynamic_data[i].notice_date + '</label></br>' +
									'</div>' +
									'</div>' +
									'</div>';
								$('#other').append(other_element);
							}

						}
						if (home_count == 0) {
							$('#home').append('<div  class="col-md-12" style="padding-left:45%;"><p>No Notices Found</p></div>');
						}
						if (shop_count == 0) {
							$('#shop').append('<div  class="col-md-12" style="padding-left:45%;"><p>No Notices Found</p></div>');
						}
						if (plot_count == 0) {
							$('#plot').append('<div  class="col-md-12" style="padding-left:45%;"><p>No Notices Found</p></div>');
						}
						if (bungalow_count == 0) {
							$('#banglo').append('<div  class="col-md-12" style="padding-left:45%;"><p>No Notices Found</p></div>');
						}

						if (industry_count == 0) {
							$('#industry').append('<div  class="col-md-12" style="padding-left:45%;"><p>No Notices Found</p></div>');
						}
						if (other_count == 0) {
							$('#other').append('<div  class="col-md-12" style="padding-left:45%;"><p>No Notices Found</p></div>');
						}
						// $('#exampleModalCenter').modal('hide');

					}
				});

			}

			function viewModal(id) {
				$("#preivew_view").empty();
				$.ajax({
					type: "get",
					url: "../admin_notice_view_api.php",
					data: {
						id: id
					},
					cache: false,
					dataType: 'json',
					success: function(response) {
						var view_data = response.data;
						$("#preivew_view").append('<a href ="' + view_data.image + '" target="_blank"><img src="' + view_data.image + '" width="150px;" height="150px" class="center"><p style="margin-left:40%;">Notice Image</p></a>');
						$("#view_notice_type").html(view_data.type_notice);
						$("#view_published_date").html(view_data.notice_date);
						$("#view_state").html(view_data.state);
						$("#view_district").html(view_data.city);
						$("#view_taluka").html(view_data.taluka);
						$("#view_village").html(view_data.village);
						$("#view_property_type").html(view_data.property_type);
						$("#view_property_number").html(view_data.propertynumber);
						$("#view_publisher_name").html(view_data.publisher_name);
						$("#view_publisher_profile").html(view_data.publisher_profile);
						$("#view_publisher_number").html(view_data.publisher_contact);
						$("#view_survey_number").html(view_data.survey_number);
						$("#view_glr_survey_number").html(view_data.glr_survey_number);

						if (view_data.owner_name != "") {
							$("#view_owner_name_td").show();
							$("#view_owner_name").html(view_data.owner_name);
						}
						if (view_data.newspaper != "") {
							$("#view_newspaper_td").show();
							$("#view_newspaper").html(view_data.newspaper);
						}
						if (view_data.newspaper_edition != "") {
							$("#view_newspaper_edition_td").show();
							$("#view_newspaper_edition").html(view_data.newspaper_edition);
						}
						if (view_data.block_number != "") {
							$("#view_block_number_td").show();
							$("#view_block_number").html(view_data.block_number);
						}
						if (view_data.tp_number != "") {
							$("#view_tp_number_td").show();
							$("#view_tp_number").html(view_data.tp_number);
						}
						if (view_data.cts_number != "") {
							$("#view_cts_number_td").show();
							$("#view_cts_number").html(view_data.cts_number);
						}
						if (view_data.fp_number != "") {
							$("#view_fp_number_td").show();
							$("#view_fp_number").html(view_data.fp_number);
						}
						if (view_data.zonenumber != "") {
							$("#view_zone_number_td").show();
							$("#view_zone_number").html(view_data.zonenumber);
						}
						if (view_data.area_name != "") {
							$("#view_area_name_td").show();
							$("#view_area_name").html(view_data.area_name);
						}
						if (view_data.hissa_number != "") {
							$("#view_hissa_number_td").show();
							$("#view_hissa_number").html(view_data.hissa_number);
						}
						if (view_data.society_name != "") {
							$("#view_society_name_td").show();
							$("#view_society_name").html(view_data.society_name);
						}

						if (view_data.bulding_name != "") {
							$("#view_building_name_td").show();
							$("#view_building_name").html(view_data.bulding_name);
						}
						if (view_data.bulding_number != "") {
							$("#view_building_number_td").show();
							$("#view_building_number").html(view_data.bulding_number);
						}
						if (view_data.wing_number != "") {
							$("#view_wing_number_td").show();
							$("#view_wing_number").html(view_data.wing_number);
						}
						if (view_data.plot_number != "") {
							$("#view_plot_number_td").show();
							$("#view_plot_number").html(view_data.plot_number);
						}

						if (view_data.gat_number != "") {
							$("#view_gat_number_td").show();
							$("#view_gat_number").html(view_data.gat_number);
						}

						if (view_data.unit_no != "" && view_data.unit_no != null) {
							$("#view_unit_number_td").show();
							$("#view_unit_number").html(view_data.unit_no);
						}
						if (view_data.sector_no != "" && view_data.sector_no != null) {
							$("#view_sector_number_td").show();
							$("#view_sector_number").html(view_data.sector_no);
						}
						if (view_data.floor_no != "" && view_data.floor_no != null) {
							$("#view_floor_number_td").show();
							$("#view_floor_number").html(view_data.floor_no);
						}
						if (view_data.others != "" && view_data.others != null) {
							$("#view_others_td").show();
							$("#view_others").html(view_data.others);
						}
						/* 
			if(view_data.apartment_no != "" && view_data.apartment_no != null){
              $("#view_apartment_number_td").show();
              $("#view_apartment_number").html(view_data.apartment_no);
            }
			if(view_data.home_number != ""){
              $("#view_home_number_td").show();
              $("#view_home_number").html(view_data.home_number);
            }
			
            if(view_data.flat_number != ""){
              $("#view_flat_number_td").show();
              $("#view_flat_number").html(view_data.flat_number);
            }
            if(view_data.office_number != ""){
              $("#view_office_number_td").show();
              $("#view_office_number").html(view_data.office_number);
            }
            if(view_data.bungalow_no != ""  && view_data.bungalow_no != null){
              $("#view_bungalow_number_td").show();
              $("#view_bungalow_number").html(view_data.bungalow_no);
            }
            
            if(view_data.row_house_no != "" && view_data.row_house_no != null){
              $("#view_row_house_number_td").show();
              $("#view_row_house_number").html(view_data.row_house_no);
            }*/
					}
				});
				$('#viewNoticeModal').modal('show');
			}

			$(document).ready(function() {
				$.ajax({
					type: "get",
					url: "../city.php",
					data: {
						state_id: '1'
					},
					cache: false,
					success: function(result) {
						var city_decode = $.parseJSON(result);
						var city_list = city_decode.response;
						var city_len = city_list.length;
						$("#city_search").empty();
						$("#city_search").append('<option selected="true" disabled="disabled" value = "" >Please Select City</option>');
						for (var k = 0; k < city_len; k++) {
							$("#city_search").append("<option value='" + city_list[k]['city_id'] + "'>" + city_list[k]['city'] + "</option>");
						}
					}
				});
				search_notice();
				$("#edit_state").change(function() {
					$.ajax({
						type: "get",
						url: "../city.php",
						data: {
							state_id: '1'
						},
						cache: false,
						success: function(result) {
							var city_decode = $.parseJSON(result);
							var city_list = city_decode.response;
							var city_len = city_list.length;
							$("#edit_city").empty();
							$("#edit_city").append('<option selected="true" name =""  disabled="disabled" value = "" >Please Select City</option>');
							for (var k = 0; k < city_len; k++) {
								$("#edit_city").append("<option name ='" + city_list[k]['city'] + "'  value='" + city_list[k]['city'] + "'>" + city_list[k]['city'] + "</option>");
							}
						}
					});
				});
				/**taluka depend on city change */
				$(".edit_city").change(function() {
					var city_id = $(this).val();
					$.ajax({
						type: "get",
						url: "../taluka.php",
						data: {
							city_id: city_id
						},
						cache: false,
						success: function(result) {
							var taluka_decode = $.parseJSON(result);
							var taluka_list = taluka_decode.response;
							var taluka_len = taluka_list.length;
							$("#edit_taluka").empty();
							$("#edit_taluka").append('<option selected="true" name ="" disabled="disabled" value = "" >Please Select Taluka</option>');
							for (var i = 0; i < taluka_len; i++) {
								$("#edit_taluka").append("<option  name ='" + taluka_list[i]['taluka'] + "' value='" + taluka_list[i]['taluka_id'] + "'>" + taluka_list[i]['taluka'] + "</option>");
							}
						}
					});
				});
				/** village change on taluka */
				$("#edit_taluka").change(function() {
					var taluka_id = $(this).val();
					$.ajax({
						type: "get",
						url: "../village.php",
						data: {
							taluka_id: taluka_id
						},
						cache: false,
						success: function(result_data) {
							var village_decode = $.parseJSON(result_data);
							var village_list = village_decode.response;
							var village_len = village_list.length;
							$("#edit_village").empty();
							$("#edit_village").append('<option name ="" value = "" selected="true" disabled="disabled">Please Select Village</option>');
							for (var j = 0; j < village_len; j++) {
								$("#edit_village").append("<option name ='" + village_list[j]['village'] + "' value='" + village_list[j]['village_id'] + "'>" + village_list[j]['village'] + "</option>");
							}
						}
					});
				});
			});
		</script>
		<?php include_once "tpl/tplFooter.php"; ?>
</body>

</html>