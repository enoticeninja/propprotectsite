<?php
header('location: my-properties.php');
exit();
include 'db.php';


//include "header.php";	
?>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>eNoticeNinja</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
	<!-- Tempusdominus Bbootstrap 4 -->
	<link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
	<!-- iCheck -->
	<link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
	<!-- JQVMap -->
	<link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="dist/css/adminlte.min.css">
	<!-- overlayScrollbars -->
	<link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
	<!-- Daterange picker -->
	<link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
	<!-- summernote -->
	<link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
	<!-- Google Font: Source Sans Pro -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
	<style>
		.center {
			display: block;
			margin-left: auto;
			margin-right: auto;
		}

		.modal-dialog {
			overflow-y: initial !important
		}

		.modal-body {
			height: 520px;
			overflow-y: auto;
		}

		.alert {
			display: none;
		}

		.alert-success {
			color: #1cb722;
			background: #c6e4a3;
			border-color: #23923d;
		}

		.nav-pills .nav-link:not(.active):hover {
			color: white;
		}
	</style>
	<div class="wrapper">

		<!-- Navbar -->
		<nav class="main-header navbar navbar-expand navbar-white navbar-light">
			<!-- Left navbar links -->
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
				</li>
				<li class="nav-item">
					<a href="index.php" class="nav-link" role="button" role="button">
						<p style="font-weight: bold;margin-top: -10%;">Home</p>
					</a>
				</li>
			</ul>


			<!-- Right navbar links -->
			<ul class="navbar-nav ml-auto">

				<li class="nav-item ">
					<a href="#" onclick="filterFunction(); return false;" class="nav-link">
						<i class="fa fa-filter" aria-hidden="true"></i>
					</a>
				</li>
				<li class="nav-item">
					<a href="login.php" class="nav-link" role="button" role="button">
						<p style="font-weight: bold;margin-top: -5%;"><i class="fa fa-user" aria-hidden="true" style="margin-left: -6%;margin-right: 5%;"></i>Sign In</p>
					</a>
				</li>
			</ul>

		</nav>
		<!-- /.navbar -->

		<!-- Main Sidebar Container -->
		<aside class="main-sidebar sidebar-dark-primary elevation-4">
			<!-- Brand Logo -->
			<a href="http://www.enoticeninja.com" target="_blank">
				<img src="dist/img/innerlogo.png" alt="AdminLTE Logo" class="brand-image" style="opacity: .8; margin-left: 6px; margin-top: 2%;">
				<p style="text-align:center;color:#c1c6cf;; margin-bottom: 1px;">Search You Can Trust</p>
			</a>
			<hr style="border-color:#4b545c">
			<!-- Sidebar -->
			<div class="sidebar">
				<!-- Sidebar Menu -->
				<nav class="mt-2">
					<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
						<!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

						<nav class="mt-2">
							<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
								<!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
								<li class="nav-item has-treeview">
									<a href="admin_offering.php" class="nav-link ">
										<i class="nav-icon fas fa-list-alt"></i>
										<p>
											Our Offering
										</p>
									</a>
								</li>
								<!-- <li class="nav-item">
              <a href="index.php" class="nav-link active">
              <i class="nav-icon fas fa-table"></i>
                <p>
                Public Notices
                </p>
              </a>
                <ul style="list-style-type: unset;"><li class="nav-item has-treeview">
                  <a  href="#" onclick="searchFunction(); return false;" class="nav-link" >
                  <i class="nav-icon fa fa-search" aria-hidden="true"></i>
                <p>
                    Search Notices
                  </p>
                </a>
                </li></ul>
             
          </li>
           <li class="nav-item has-treeview">
             <a href="contact_us.php" class="nav-link">
              <i class="nav-icon fas fa-phone"></i>
              <p>
                Contact Us
              </p>
            </a>
           </li>
		      <li class="nav-item has-treeview">
             <a href="faq.php" class="nav-link ">
              <i class="nav-icon fas fa-question"></i>
              <p>
                FAQs
              </p>
            </a>
           </li>
           <li class="nav-item has-treeview">
             <a href="about_us.php" class="nav-link">
              <i class="nav-icon fas fa-info"></i>
              <p>
                About Us
              </p>
            </a>
           </li>
           <li class="nav-item has-treeview">
             <a href="help_feedback.php" class="nav-link">
              <i class="nav-icon fas fa-question"></i>
              <p>
                Help & Feedback
              </p>
            </a>
           </li>-->
							</ul>
						</nav>

						<!-- /.sidebar-menu -->
			</div>
			<!-- /.sidebar -->
		</aside>

		<div class="content-wrapper">
			<!-- Main content -->
			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<!-- /.card-header -->
								<div class="row" id="home" style="margin-top: 1%;">
									<!-- <div class="col-12 col-sm-12"> -->

									<!-- <div class="card card-primary card-tabs"> -->

									<!-- <div class="card-header p-0 pt-1" style="background-color: #6c757d;">
							<ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
							  <li class="nav-item">
								<a class="nav-link active" id="custom-tabs-one-home_flat-tab" data-toggle="pill" href="#custom-tabs-one-home_flat" role="tab" aria-controls="custom-tabs-one-home_flat" aria-selected="true">Home/Flat</a>
							  </li>
							  <li class="nav-item">
								<a class="nav-link" id="custom-tabs-one-shop_office-tab" data-toggle="pill" href="#custom-tabs-one-shop_office" role="tab" aria-controls="custom-tabs-one-shop_office" aria-selected="false">Shop/Office</a>
							  </li>
							  <li class="nav-item">
								<a class="nav-link" id="custom-tabs-one-plot_land-tab" data-toggle="pill" href="#custom-tabs-one-plot_land" role="tab" aria-controls="custom-tabs-one-plot_land" aria-selected="false">Plot/Land</a>
							  </li>
							  <li class="nav-item">
								<a class="nav-link" id="custom-tabs-one-brh-tab" data-toggle="pill" href="#custom-tabs-one-brh" role="tab" aria-controls="custom-tabs-one-brh" aria-selected="false">Bungalow/RowHouse</a>
							  </li>
							  <li class="nav-item">
								<a class="nav-link" id="custom-tabs-one-industry-tab" data-toggle="pill" href="#custom-tabs-one-industry" role="tab" aria-controls="custom-tabs-one-industry" aria-selected="false">Industry</a>
							  </li>
                 <li class="nav-item">
								<a class="nav-link" id="custom-tabs-one-industry-tab" href="http://www.nanostuffs.com/lawyer/admin/notice_add_page.php"><i class="fa fa-plus-circle "  style="font-size:30px;color:#007bff;" ></i></a>
							  </li> 
               
							</ul>
						  </div> -->
									<!-- <div class="card-body"> -->
									<!-- <div class="tab-content" id="custom-tabs-one-tabContent">
                  <div class="tab-pane fade show active" id="custom-tabs-one-home_flat" role="tabpanel" aria-labelledby="custom-tabs-one-home_flat-tab">
                   
                    <div class="row" id="home" >
                    </div>
                  </div>
                  <div class="tab-pane fade" id="custom-tabs-one-shop_office" role="tabpanel" aria-labelledby="custom-tabs-one-shop_office-tab">
                  
                    <div class="row" id="shop">
                    </div>
                  </div>
                  <div class="tab-pane fade" id="custom-tabs-one-plot_land" role="tabpanel" aria-labelledby="custom-tabs-one-plot_land-tab">
                 
                    <div class="row" id="plot">
                    </div>
                  </div>
                  <div class="tab-pane fade" id="custom-tabs-one-brh" role="tabpanel" aria-labelledby="custom-tabs-one-brh-tab">
                 
                    <div class="row" id="banglo" >
                    </div>
                  </div>
                  <div class="tab-pane fade" id="custom-tabs-one-industry" role="tabpanel" aria-labelledby="custom-tabs-one-industry-tab">
                
                    <div class="row" id="industry" >
                    </div>
                  </div>
                </div> -->
									<!-- </div> -->
									<!-- /.card -->
									<!-- </div> -->
								</div>
							</div>
							<!-- /.card -->
						</div><!-- /.container-fluid -->
			</section>
		</div>

		<!-- start search modal -->
		<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLongTitle">Search</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>City : </label>
									<select class="custom-select city_search" name="city_search" id="city_search">
										<option selected="true" disabled="disabled" value="">Please select city</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Taluka : </label>
									<select class="custom-select taluka_search" name="taluka_search" id="taluka_search">
										<option selected="true" disabled="disabled" value="">Please select taluka</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Village : </label>
									<select class="custom-select village_search" name="village_search" id="village_search">
										<option selected="true" disabled="disabled" value="">Please select village</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Property Type : </label>
									<select class="custom-select" id="property_type_search" name="property_type_search">
										<option value="" selected="selected" disabled>Please select property type</option>
										<option value="Home/Flat">Home/Flat</option>
										<option value="Shop/Office">Shop/Office</option>
										<option value="Plot/Land">Plot/Land</option>
										<option value="Bungalow/RowHouse">Bungalow/RowHouse</option>
										<option value="Industry">Industry</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Publisher Name : </label>
									<input type="text" id="publisher_name_search" name="publisher_name_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Publisher Contact : </label>
									<input type="text" id="publisher_contact_search" name="publisher_contact_search" class="form-control">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Survey Number : </label>
									<input type="text" id="survey_no_search" name="survey_no_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>T.P. Scheme Number : </label>
									<input type="text" id="tp_no_search" name="tp_no_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>CTS Number : </label>
									<input type="text" id="cts_no_search" name="cts_no_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Block Number : </label>
									<input type="text" id="block_no_search" name="block_no_search" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Final Plot Number : </label>
									<input type="text" id="fp_no_search" name="fp_no_search" class="form-control">
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary" id="searchNotice_Button">Search</button>
					</div>
				</div>
			</div>
		</div>
		<!-- end search modal here -->
		<!-- start Filter modal -->
		<div class="modal fade" id="filterModalCenter" tabindex="-1" role="dialog" aria-labelledby="filterModalCenterTitle" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body" style="height: 462px;">
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Sort By : </label>
									<select class="custom-select sorting" name="sorting" id="sorting">
										<option disabled="disabled" value="">Select date</option>
										<option value="asc">Date - Ascending</option>
										<option selected="true" value="desc">Date - Descending</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>City : </label>
									<select class="custom-select city_filter" name="city_filter" id="city_filter">
										<option selected="true" disabled="disabled" value="">Please select city</option>
									</select>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Taluka : </label>
									<select class="custom-select taluka_filter" name="taluka_filter" id="taluka_filter">
										<option selected="true" disabled="disabled" value="">Please select taluka</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Form Date : </label>
									<input type="date" class="form-control" id="form_date" name="form_date" placeholder="Enter form date ">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>To Date : </label>
									<input type="date" class="form-control" id="to_date" name="to_date" placeholder="Enter to date ">
								</div>
							</div>
						</div>

					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary" id="filterNotice_Button">Filter</button>
					</div>
				</div>
			</div>
		</div>
		<!-- end search modal here -->
		<!-- View Home/Flat Notice -->
		<div class="modal" id="viewNoticeModal">
			<div class="modal-dialog">
				<div class="modal-content">
					<!-- Modal Header -->
					<div class="modal-header">
						<label id="view_modal_title" name="view_modal_title">Public Notice</label></br>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>

					<!-- Modal body -->
					<div class="modal-body">
						<div class="row clearfix">
							<div class="col-md-12">
								<div class="card-body p-0">
									<table class="table table-striped">
										<tbody>
											<tr>
												<div id="preivew_view"></div>
											</tr>
											<tr>
												<td width="50%">Notice Type : </td>
												<td width="50%" id="view_notice_type"></td>
											</tr>
											<tr>
												<td width="50%">Published Date : </td>
												<td width="50%" id="view_published_date"></td>
											</tr>
											<tr>
												<td width="50%">State :</td>
												<td width="50%" id="view_state"></td>
											</tr>
											<tr>
												<td width="50%">District :</td>
												<td width="50%" id="view_district"></td>
											</tr>
											<tr>
												<td width="50%">Taluka :</td>
												<td width="50%" id="view_taluka"></td>
											</tr>
											<tr>
												<td width="50%">Village :</td>
												<td width="50%" id="view_village"></td>
											</tr>
											<tr>
												<td width="50%">Property Type : </td>
												<td width="50%" id="view_property_type"></td>
											</tr>
											<!-- <tr>
                  <td width="50%">Property Detail :</td>
                  <td width="50%" id = "view_property_details"></td>
                </tr> -->
											<tr>
												<td width="50%">Property Number : </td>
												<td width="50%" id="view_property_number"></td>
											</tr>
											<tr>
												<td width="50%">Publisher Name : </td>
												<td width="50%" id="view_publisher_name"></td>
											</tr>
											<tr>
												<td width="50%">Publisher Profile : </td>
												<td width="50%" id="view_publisher_profile"></td>
											</tr>
											<tr>
												<td width="50%">Publisher Contact Number :</td>
												<td width="50%" id="view_publisher_number"></td>
											</tr>
											<tr style="display:none" id="view_newspaper_td">
												<td width="50%">NewsPaper : </td>
												<td width="50%" id="view_newspaper"></td>
											</tr>
											<tr style="display:none" id="view_newspaper_edition_td">
												<td width="50%">Newspaper Edition : </td>
												<td width="50%" id="view_newspaper_edition"></td>
											</tr>
											<tr style="display:none" id="view_owner_name_td">
												<td width="50%">Name of Owner/Developer : </td>
												<td width="50%" id="view_owner_name"></td>
											</tr>
											<tr>
												<td width="50%">Survey Number : </td>
												<td width="50%" id="view_survey_number"></td>
											</tr>
											<tr style="display:none" id="view_hissa_number_td">
												<td width="50%">Hissa Number : </td>
												<td width="50%" id="view_hissa_number"></td>
											</tr>
											<tr style="display:none" id="view_area_name_td">
												<td width="50%">Location Name :</td>
												<td width="50%" id="view_area_name"></td>
											</tr>
											<tr style="display:none" id="view_society_name_td">
												<td width="50%">Society/Apartment/Complex Name : </td>
												<td width="50%" id="view_society_name"></td>
											</tr>
											<tr style="display:none" id="view_apartment_number_td">
												<td width="50%">Apartment Number :</td>
												<td width="50%" id="view_apartment_number"></td>
											</tr>
											<tr style="display:none" id="view_row_house_number_td">
												<td width="50%">Row House Number :</td>
												<td width="50%" id="view_row_house_number"></td>
											</tr>
											<tr style="display:none" id="view_building_name_td">
												<td width="50%">Building Name :</td>
												<td width="50%" id="view_building_name"></td>
											</tr>
											<tr style="display:none" id="view_building_number_td">
												<td width="50%">Building Number :</td>
												<td width="50%" id="view_building_number"></td>
											</tr>
											<tr style="display:none" id="view_wing_number_td">
												<td width="50%">Wing Number :</td>
												<td width="50%" id="view_wing_number"></td>
											</tr>
											<tr style="display:none" id="view_flat_number_td">
												<td width="50%">Flat Number :</td>
												<td width="50%" id="view_flat_number"></td>
											</tr>
											<tr style="display:none" id="view_floor_number_td">
												<td width="50%">Floor Number :</td>
												<td width="50%" id="view_floor_number"></td>
											</tr>
											<tr style="display:none" id="view_bungalow_number_td">
												<td width="50%">Bungalow Number :</td>
												<td width="50%" id="view_bungalow_number"></td>
											</tr>
											<tr style="display:none" id="view_plot_number_td">
												<td width="50%">Plot No. / Bhukhand No. / Land No. :</td>
												<td width="50%" id="view_plot_number"></td>
											</tr>
											<tr style="display:none" id="view_fp_number_td">
												<td width="50%">Final Plot Number :</td>
												<td width="50%" id="view_fp_number"></td>
											</tr>
											<tr style="display:none" id="view_home_number_td">
												<td width="50%">Shop Number :</td>
												<td width="50%" id="view_home_number"></td>
											</tr>
											<tr style="display:none" id="view_office_number_td">
												<td width="50%">Office Number :</td>
												<td width="50%" id="view_office_number"></td>
											</tr>
											<tr style="display:none" id="view_block_number_td">
												<td width="50%">Block Number : </td>
												<td width="50%" id="view_block_number"></td>
											</tr>
											<tr style="display:none" id="view_tp_number_td">
												<td width="50%">T.P. Scheme Number : </td>
												<td width="50%" id="view_tp_number"></td>
											</tr>
											<tr style="display:none" id="view_cts_number_td">
												<td width="50%">CTS Number :</td>
												<td width="50%" id="view_cts_number"></td>
											</tr>

											<tr style="display:none" id="view_zone_number_td">
												<td width="50%">Zone Number :</td>
												<td width="50%" id="view_zone_number"></td>
											</tr>
											<!-- <tr>
                  <td width="50%">Home/Flat Name :</td>
                  <td width="50%" id ="view_home_flat_name"></td>
                </tr> -->
											<tr style="display:none" id="view_gat_number_td">
												<td width="50%">Gat Number :</td>
												<td width="50%" id="view_gat_number"></td>
											</tr>
											<tr style="display:none" id="view_sector_number_td">
												<td width="50%">Sector Number :</td>
												<td width="50%" id="view_sector_number"></td>
											</tr>
											<tr style="display:none" id="view_unit_number_td">
												<td width="50%">Unit Number :</td>
												<td width="50%" id="view_unit_number"></td>
											</tr>
											<tr style="display:none" id="view_others_td">
												<td width="50%">Others :</td>
												<td width="50%" id="view_others"></td>
											</tr>
											<!-- <tr>
                  <td width="50%">Street Number :</td>
                  <td width="50%" id="view_streetnumber"></td>
                </tr> -->
										</tbody>
									</table>
								</div>

							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						</div>

					</div>
				</div>
			</div>
		</div>
		<!-- /End.View Home/Flat Notice -->



		<script type="text/javascript">
			function filterFunction() {
				var dtToday = new Date();
				var month = dtToday.getMonth() + 1; // getMonth() is zero-based
				var day = dtToday.getDate();
				var year = dtToday.getFullYear();
				if (month < 10)
					month = '0' + month.toString();
				if (day < 10)
					day = '0' + day.toString();

				var maxDate = year + '-' + month + '-' + day;
				$('#to_date').attr('max', maxDate);
				$('#form_date').attr('max', maxDate);


				/* taluka depend on city change */
				$(".city_filter").change(function() {
					var city_id = $(this).val();
					$.ajax({
						type: "get",
						url: "../taluka.php",
						data: {
							city_id: city_id
						},
						cache: false,
						success: function(result) {
							var taluka_decode = $.parseJSON(result);
							var taluka_list = taluka_decode.response;
							var taluka_len = taluka_list.length;
							$("#taluka_filter").empty();
							$("#taluka_filter").append('<option selected="true" disabled="disabled" value = "" >Please select taluka</option>');
							for (var i = 0; i < taluka_len; i++) {
								$("#taluka_filter").append("<option value='" + taluka_list[i]['taluka_id'] + "'>" + taluka_list[i]['taluka'] + "</option>");
							}
						}
					});
				});

				$('#filterModalCenter').modal('show');
				$("#filterNotice_Button").unbind('click');
				$('#filterNotice_Button').on('click', function(e) {
					search_notice();
					$('#filterModalCenter').modal('hide');
				});

			}

			function searchFunction() {
				// alert("priyanka");


				/* taluka depend on city change */
				$(".city_search").change(function() {
					var city_id = $(this).val();
					$.ajax({
						type: "get",
						url: "../taluka.php",
						data: {
							city_id: city_id
						},
						cache: false,
						success: function(result) {
							var taluka_decode = $.parseJSON(result);
							var taluka_list = taluka_decode.response;
							var taluka_len = taluka_list.length;
							$("#taluka_search").empty();
							$("#taluka_search").append('<option selected="true" disabled="disabled" value = "" >Please select taluka</option>');
							for (var i = 0; i < taluka_len; i++) {
								$("#taluka_search").append("<option value='" + taluka_list[i]['taluka_id'] + "'>" + taluka_list[i]['taluka'] + "</option>");
							}
						}
					});
				});
				/* village change on taluka */
				$("#taluka_search").change(function() {
					var taluka_id = $(this).val();
					$.ajax({
						type: "get",
						url: "../village.php",
						data: {
							taluka_id: taluka_id
						},
						cache: false,
						success: function(result_data) {
							var village_decode = $.parseJSON(result_data);
							var village_list = village_decode.response;
							var village_len = village_list.length;
							$("#village_search").empty();
							$("#village_search").append('<option  value = "" selected="true" disabled="disabled">Please select village</option>');
							for (var j = 0; j < village_len; j++) {
								$("#village_search").append("<option value='" + village_list[j]['village_id'] + "'>" + village_list[j]['village'] + "</option>");
							}
						}
					});
				});
				$('#exampleModalCenter').modal('show');
				$("#searchNotice_Button").unbind('click');
				$('#searchNotice_Button').on('click', function(e) {
					search_notice();
					$('#exampleModalCenter').modal('hide');
				});

			}

			function search_notice() {
				/** Search data */
				var city_search = $('#city_search option:selected').text();
				var taluka_search = $('#taluka_search option:selected').text();
				var village_search = $('#village_search option:selected').text();
				var publisher_name_search = $('#publisher_name_search').val();
				var property_type = $('#property_type_search').val();
				var publisher_contact_search = $('#publisher_contact_search').val();
				var survey_no_search = $('#survey_no_search').val();
				var tp_no_search = $('#tp_no_search').val();
				var cts_no_search = $('#cts_no_search').val();
				var block_no_search = $('#block_no_search').val();
				var fp_no_search = $('#fp_no_search').val();
				/** Filter Data */
				var city_filter = $('#city_filter option:selected').text();
				var taluka_filter = $('#taluka_filter option:selected').text();
				var sorting = $('#sorting').val();
				var to_date = $('#to_date').val();
				var form_date = $('#form_date').val();
				// var user_id =document.getElementById("user_id").value;
				$.ajax({
					type: "GET",
					// url: '../admin_all_notices_api.php',
					data: {
						// user_id:user_id,
						city_search: city_search,
						taluka_search: taluka_search,
						village_search: village_search,
						publisher_name_search: publisher_name_search,
						publisher_contact_search: publisher_contact_search,
						survey_no_search: survey_no_search,
						tp_no_search: tp_no_search,
						cts_no_search: cts_no_search,
						block_no_search: block_no_search,
						fp_no_search: fp_no_search,
						city_filter: city_filter,
						taluka_filter: taluka_filter,
						sorting: sorting,
						to_date: to_date,
						form_date: form_date,
						property_type: property_type
					},
					dataType: 'json',

					cache: false,
					success: function(response) {
						var count = response.Totalcount;
						var dynamic_data = response.data;
						var home_count = 0;
						var shop_count = 0;
						var plot_count = 0;
						var bungalow_count = 0;
						var industry_count = 0;

						$('#home').empty();
						// $('#shop').empty();
						// $('#plot').empty();
						//  $('#banglo').empty();
						// $('#industry').empty();
						for (var i = 0; i < count; i++) {
							// if(dynamic_data[i].property_type == 'Home/Flat'){
							home_count++;
							var home_element = '<div class="col-md-4" >' +
								'<div class="small-box bg-info" id="block" name="">' +
								'<div class="inner" style="background-color: white;color: black;">' +
								'<div class="form-group datastyle" style="margin-bottom: 0rem;">' +
								'<input type="hidden" id="id" name="id" value=:' + dynamic_data[i].notice_id + '>' +
								//'<label id="title" name="title" style="font-weight: 400;" ><b>Notice Title: </b> '+dynamic_data[i].title+'</label></br>'+						 
								'<label style="font-weight: 400;margin-right:10px;" id="city" name="city" ><b>City/District: </b>' + dynamic_data[i].city + '</label></br>' +
								'<label style="font-weight: 400;" id="taluka" name="taluka" ><b>Taluka: </b>' + dynamic_data[i].taluka + '</label></br>' +
								'<label style="font-weight: 400;" id="village" name="village" ><b>Village: </b>' + dynamic_data[i].village + '</label></br>' +
								// '</div>'+
								// '<hr>'+
								// '<div class="form-group">'+
								'<label style="font-weight: 400;" id="survey_number" name="survey_number"><b>Survey Number: </b>' + dynamic_data[i].survey_number + '</label></br>' +
								//'<label style="font-weight: 400;" id="publisher_name" name="publisher_name"><b>Publisher Name: </b>'+dynamic_data[i].publisher_name+'</label></br>'+
								// '<label style="font-weight: 400;" id="Publisher_contact" name="Publisher_contact"><b>Publisher Contact Number: </b>'+dynamic_data[i].publisher_contact+'</label></br>'+
								'</div>' +
								'</div>' +
								'<div class="small-box-footer" style="background-color: #007bff;">';
							home_element +=
								'<a href="#" class="col-md-2" style="color:white; float:left;margin-top:1%"  onclick ="viewModal(' + dynamic_data[i].notice_id + ')"><i class="fas fa-eye"></i> </a>' +
								//   '<a href="#" class="col-md-2" style="color:white;" onclick ="edit_popup('+dynamic_data[i].notice_id+')"><i class="fas fa-edit"></i></a>'+
								//   '<a href="#" class="col-md-2"  style="color:white;" onclick ="delete_data('+dynamic_data[i].notice_id+')"><i class="fas fa-trash-alt"></i></a>'+
								'<label style="font-weight: 400;" class="col-md-10" id="date" name="date" >Published Date: ' + dynamic_data[i].notice_date + '</label></br>' +
								'</div>' +
								'</div>' +
								'</div>';
							$('#home').append(home_element);

						}
						if (home_count == 0) {
							$('#home').append('<div  class="col-md-12" style="padding-left:45%;"><p>No Notices Found</p></div>');
						}


					}
				});

			}

			function viewModal(id) {
				$("#preivew_view").empty();
				$.ajax({
					type: "get",
					url: "../admin_notice_view_api.php",
					data: {
						id: id
					},
					cache: false,
					dataType: 'json',
					success: function(response) {
						var view_data = response.data;
						$("#preivew_view").append('<a href ="' + view_data.image + '" target="_blank"><img src="' + view_data.image + '" width="150px;" height="150px" class="center"><p style="margin-left:40%;">Notice Image</p></a>');
						$("#view_notice_type").html(view_data.type_notice);
						$("#view_published_date").html(view_data.notice_date);
						$("#view_state").html(view_data.state);
						$("#view_district").html(view_data.city);
						$("#view_taluka").html(view_data.taluka);
						$("#view_village").html(view_data.village);
						$("#view_property_type").html(view_data.property_type);
						$("#view_property_number").html(view_data.propertynumber);
						$("#view_publisher_name").html(view_data.publisher_name);
						$("#view_publisher_profile").html(view_data.publisher_profile);
						$("#view_publisher_number").html(view_data.publisher_contact);
						$("#view_survey_number").html(view_data.survey_number);
						if (view_data.owner_name != "") {
							$("#view_owner_name_td").show();
							$("#view_owner_name").html(view_data.owner_name);
						}
						if (view_data.newspaper != "") {
							$("#view_newspaper_td").show();
							$("#view_newspaper").html(view_data.newspaper);
						}
						if (view_data.newspaper_edition != "") {
							$("#view_newspaper_edition_td").show();
							$("#view_newspaper_edition").html(view_data.newspaper_edition);
						}
						if (view_data.block_number != "") {
							$("#view_block_number_td").show();
							$("#view_block_number").html(view_data.block_number);
						}
						if (view_data.tp_number != "") {
							$("#view_tp_number_td").show();
							$("#view_tp_number").html(view_data.tp_number);
						}
						if (view_data.cts_number != "") {
							$("#view_cts_number_td").show();
							$("#view_cts_number").html(view_data.cts_number);
						}
						if (view_data.fp_number != "") {
							$("#view_fp_number_td").show();
							$("#view_fp_number").html(view_data.fp_number);
						}
						if (view_data.zonenumber != "") {
							$("#view_zone_number_td").show();
							$("#view_zone_number").html(view_data.zonenumber);
						}
						if (view_data.area_name != "") {
							$("#view_area_name_td").show();
							$("#view_area_name").html(view_data.area_name);
						}
						if (view_data.hissa_number != "") {
							$("#view_hissa_number_td").show();
							$("#view_hissa_number").html(view_data.hissa_number);
						}
						if (view_data.society_name != "") {
							$("#view_society_name_td").show();
							$("#view_society_name").html(view_data.society_name);
						}
						if (view_data.home_number != "") {
							$("#view_home_number_td").show();
							$("#view_home_number").html(view_data.home_number);
						}
						if (view_data.flat_number != "") {
							$("#view_flat_number_td").show();
							$("#view_flat_number").html(view_data.flat_number);
						}
						if (view_data.bulding_name != "") {
							$("#view_building_name_td").show();
							$("#view_building_name").html(view_data.bulding_name);
						}
						if (view_data.bulding_number != "") {
							$("#view_building_number_td").show();
							$("#view_building_number").html(view_data.bulding_number);
						}
						if (view_data.wing_number != "") {
							$("#view_wing_number_td").show();
							$("#view_wing_number").html(view_data.wing_number);
						}
						if (view_data.plot_number != "") {
							$("#view_plot_number_td").show();
							$("#view_plot_number").html(view_data.plot_number);
						}
						if (view_data.office_number != "") {
							$("#view_office_number_td").show();
							$("#view_office_number").html(view_data.office_number);
						}
						if (view_data.gat_number != "") {
							$("#view_gat_number_td").show();
							$("#view_gat_number").html(view_data.gat_number);
						}
						if (view_data.apartment_no != "" && view_data.apartment_no != null) {
							$("#view_apartment_number_td").show();
							$("#view_apartment_number").html(view_data.apartment_no);
						}

						if (view_data.unit_no != "" && view_data.unit_no != null) {
							$("#view_unit_number_td").show();
							$("#view_unit_number").html(view_data.unit_no);
						}
						if (view_data.sector_no != "" && view_data.sector_no != null) {
							$("#view_sector_number_td").show();
							$("#view_sector_number").html(view_data.sector_no);
						}
						if (view_data.floor_no != "" && view_data.floor_no != null) {
							$("#view_floor_number_td").show();
							$("#view_floor_number").html(view_data.floor_no);
						}
						if (view_data.bungalow_no != "" && view_data.bungalow_no != null) {
							$("#view_bungalow_number_td").show();
							$("#view_bungalow_number").html(view_data.bungalow_no);
						}
						if (view_data.others != "" && view_data.others != null) {
							$("#view_others_td").show();
							$("#view_others").html(view_data.others);
						}
						if (view_data.row_house_no != "" && view_data.row_house_no != null) {
							$("#view_row_house_number_td").show();
							$("#view_row_house_number").html(view_data.row_house_no);
						}

					}
				});
				$('#viewNoticeModal').modal('show');
			}

			$(document).ready(function() {
				search_notice();
				$.ajax({
					type: "get",
					url: "../city.php",
					data: {
						state_id: '1'
					},
					cache: false,
					success: function(result) {
						var city_decode = $.parseJSON(result);
						var city_list = city_decode.response;
						var city_len = city_list.length;
						$("#city_search").empty();
						$("#city_search").append('<option selected="true" disabled="disabled" value = "" >Please select city</option>');
						for (var k = 0; k < city_len; k++) {
							$("#city_search").append("<option value='" + city_list[k]['city_id'] + "'>" + city_list[k]['city'] + "</option>");
						}
						$("#city_filter").empty();
						$("#city_filter").append('<option selected="true" disabled="disabled" value = "" >Please select city</option>');
						for (var k = 0; k < city_len; k++) {
							$("#city_filter").append("<option value='" + city_list[k]['city_id'] + "'>" + city_list[k]['city'] + "</option>");
						}
					}
				});
				$("#edit_state").change(function() {
					$.ajax({
						type: "get",
						url: "../city.php",
						data: {
							state_id: '1'
						},
						cache: false,
						success: function(result) {
							var city_decode = $.parseJSON(result);
							var city_list = city_decode.response;
							var city_len = city_list.length;
							$("#edit_city").empty();
							$("#edit_city").append('<option selected="true" name =""  disabled="disabled" value = "" >Please Select City</option>');
							for (var k = 0; k < city_len; k++) {
								$("#edit_city").append("<option name ='" + city_list[k]['city'] + "'  value='" + city_list[k]['city'] + "'>" + city_list[k]['city'] + "</option>");
							}
						}
					});
				});
				/**taluka depend on city change */
				$(".edit_city").change(function() {
					var city_id = $(this).val();
					$.ajax({
						type: "get",
						url: "../taluka.php",
						data: {
							city_id: city_id
						},
						cache: false,
						success: function(result) {
							var taluka_decode = $.parseJSON(result);
							var taluka_list = taluka_decode.response;
							var taluka_len = taluka_list.length;
							$("#edit_taluka").empty();
							$("#edit_taluka").append('<option selected="true" name ="" disabled="disabled" value = "" >Please Select Taluka</option>');
							for (var i = 0; i < taluka_len; i++) {
								$("#edit_taluka").append("<option  name ='" + taluka_list[i]['taluka'] + "' value='" + taluka_list[i]['taluka_id'] + "'>" + taluka_list[i]['taluka'] + "</option>");
							}
						}
					});
				});
				/** village change on taluka */
				$("#edit_taluka").change(function() {
					var taluka_id = $(this).val();
					$.ajax({
						type: "get",
						url: "../village.php",
						data: {
							taluka_id: taluka_id
						},
						cache: false,
						success: function(result_data) {
							var village_decode = $.parseJSON(result_data);
							var village_list = village_decode.response;
							var village_len = village_list.length;
							$("#edit_village").empty();
							$("#edit_village").append('<option name ="" value = "" selected="true" disabled="disabled">Please Select Village</option>');
							for (var j = 0; j < village_len; j++) {
								$("#edit_village").append("<option name ='" + village_list[j]['village'] + "' value='" + village_list[j]['village_id'] + "'>" + village_list[j]['village'] + "</option>");
							}
						}
					});
				});
			});
		</script>


		<?php
		include "footer.php";

		?>