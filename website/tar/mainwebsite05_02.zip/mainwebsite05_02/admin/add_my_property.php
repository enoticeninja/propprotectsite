<?php
include_once 'bootstrap.php';
include_once 'common.php';
$TITLE = 'My Profile';

if (isset($_GET['query'])) {
	$village = $_GET['query'];
	$sql = "SELECT * FROM village WHERE village LIKE '%$village%'";
	$query = mysqli_query($conn, $sql);
	$return = array();
	while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
		$return[$row['village_id']] = $row;
	}
	echo json_encode($return);
	exit();
}
$has_subscription = checkSubscription();


$form_config = getPropertyFormFields();
?>
<!DOCTYPE html>
<html>

<head>
	<?php include_once 'tpl/tplHead.php'; ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
	<style>
		.alert {
			display: none;
		}

		.alert-success {
			color: #1cb722;
			background: #c6e4a3;
			border-color: #23923d;
		}

		.twitter-typeahead {
			width: 100%;
		}

		.tt-menu {
			background: #d8d2d2;
			padding: 10px;
			width: 100%;
		}

		.tt-dataset {
			cursor: pointer;
		}
	</style>
	<div class="wrapper">
		<?php include_once 'tpl/tplHeader.php'; ?>
		<?php include_once 'tpl/tplSidebar.php'; ?>

		<body class="hold-transition sidebar-mini layout-fixed">
			<div class="wrapper">


				<!-- Content Wrapper. Contains page content -->
				<div class="content-wrapper">

					<!-- Main content -->
					<section class="content">
						<div class="container-fluid">
							<?php if (!$has_subscription) : ?>
								<div class="row p-3">
									<div class="col-md-10 m-auto">
										<h5><b>You are currently not subscribed to any offering. Please visit Our Offerings to subscribe.</b></h5>
										<a href="<?php echo ADMIN_SITE_PATH ?>select-plan.php" class="btn btn-secondary btn-block waves-effect waves-light p-3" style="font-size:20px;"><i class="fas fa-shopping-cart mr-1" style="font-size:20px"></i> Buy Subscription </a>
									</div>
								</div>
							<?php else : ?>
								<div class="row">
									<!-- right column -->
									<div class="col-md-12">
										<div class="card card-secondary">
											<div class="card-header">
												<h3 class="card-title">Add Property</h3>
											</div>
											<!-- /.card-header -->
											<div class="card-body">
												<form role="form" id='add_property_form' enctype="multipart/form-data">
													<div class="alert alert-success alert-dismissable">
														<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
														<strong id="success_message"></strong>
													</div>
													<div class="row" id="form-container">

													</div>

													<div class="card-footer" style="background-color:white;">
														<button type="submit" id="submit" value="submit" name="submit_notice" id="addnotice_button" class="btn btn-primary float-right submitBtn ">Add Property</button>
														<a href="<?php echo ADMIN_SITE_PATH ?>" class="btn btn-secondary  float-left" style="margin-right:5%;" id="cancel">Cancel</a>
													</div>
											</div>

											</form>
										</div>
										<!-- /.card-body -->
									</div>
									<!-- /.card -->
								</div>
							<?php endif; ?>
							<!--/.col (right) -->
						</div>
						<!-- /.row -->
				</div><!-- /.container-fluid -->
				</section>
				<!-- /.content -->
			</div>

			<!-- Control Sidebar -->
			<aside class="control-sidebar control-sidebar-dark">
				<!-- Control sidebar content goes here -->
			</aside>
			<!-- /.control-sidebar -->
	</div>
	<!-- ./wrapper -->
	<?php if ($has_subscription) : ?>
		<!-- jQuery -->
		<script>
			var city_id;
			var taluka_id;
			var toolsAll = {};
			var tools = {};
			var form_config = JSON.parse('<?php echo json_encode($form_config) ?>');
			var formFields = form_config['fields'];
			var required = form_config['required'];
			$(document).ready(function() {
				delete form_config['fields']['property_id'];
				var form_config_copy = $.extend(true, {}, form_config);
				form_config_copy['data'] = {};
				form_config_copy['data']['user_id'] = '<?php echo $user_id ?>';
				var formHtml = createForm(form_config_copy);
				$('#form-container').html(formHtml);
			});
		</script>
		<script type="text/javascript">
			$(document).ready(function() {

				$("#state").change(function() {
					$.ajax({
						type: "POST",
						url: "<?php echo API_ROUTE_PATH ?>city.php",
						data: JSON.stringify({
							state_id: '1'
						}),
						dataType: 'json',
						cache: false,
						success: function(result) {
							//var city_decode = $.parseJSON(result);
							var city_decode = result;
							var city_list = city_decode.response;
							var city_len = city_list.length;
							$("#city").empty();
							$("#city").append('<option name = "" selected="true" disabled="disabled" value = "" >Please select district</option>');
							for (var k = 0; k < city_len; k++) {
								$("#city").append("<option name ='" + city_list[k]['city_id'] + "' value='" + city_list[k]['city'] + "'>" + city_list[k]['city'] + "</option>");
							}
						}
					});
				});

				/** Retriving city here */

				/**taluka depend on city change */
				$("#city").change(function() {
					var city_id = $(this).find('option:selected').attr("name");
					$.ajax({
						type: "POST",
						url: "<?php echo API_ROUTE_PATH ?>taluka.php",
						data: JSON.stringify({
							city_id: city_id
						}),
						dataType: 'json',
						cache: false,
						success: function(result) {
							//var taluka_decode = $.parseJSON(result);
							var taluka_decode = result;
							var taluka_list = taluka_decode.response;
							var taluka_len = taluka_list.length;
							$("#taluka").empty();
							$("#taluka").append('<option name ="" selected="true" disabled="disabled" value = "" >Please select taluka</option>');
							for (var i = 0; i < taluka_len; i++) {
								$("#taluka").append("<option name ='" + taluka_list[i]['taluka_id'] + "' value='" + taluka_list[i]['taluka'] + "'>" + taluka_list[i]['taluka'] + "</option>");
							}
						}
					});
				});
				/** village change on taluka */
				$("#taluka").change(function() {
					var taluka_id = $(this).find('option:selected').attr("name");
					$.ajax({
						type: "POST",
						url: "<?php echo API_ROUTE_PATH ?>village.php",
						data: JSON.stringify({
							taluka_id: taluka_id
						}),
						dataType: 'json',
						cache: false,
						success: function(result_data) {
							//var village_decode = $.parseJSON(result_data);
							village_decode = result_data;
							var village_list = village_decode.response;
							var village_len = village_list.length;
							$("#village").empty();
							$("#village").append('<option  name = "" value = "" selected="true" disabled="disabled">Please select village</option>');
							for (var j = 0; j < village_len; j++) {
								$("#village").append("<option name ='" + village_list[j]['village_id'] + "' value='" + village_list[j]['village'] + "'>" + village_list[j]['village'] + "</option>");
							}
						}
					});
				});
				/** file upload image */
				var fileTag = document.getElementById("file"),
					preview = document.getElementById("preview");


				/* fileTag.addEventListener("change", function() {
					changeImage(this);
				}); */

				function changeImage(input) {
					var reader;

					if (input.files && input.files[0]) {
						reader = new FileReader();

						reader.onload = function(e) {
							preview.setAttribute('src', e.target.result);
						}

						reader.readAsDataURL(input.files[0]);
					}

				}
				// Submit form data via Ajax
				$("#add_property_form").on('submit', function(e) {
					e.preventDefault();
					var isOk = true;
					$.each(form_config['fields'], function(field, fieldConfig) {

						if (fieldConfig['required']) {
							console.log(field);
							if ($.trim($('#' + field + '').val()) == '') {
								isOk = false;
								showErrorOnElement(field, 'Required');
							} else {
								resetElementState(field, '');
							}
						}
					});
					var formData = new FormData(document.getElementById('add_property_form'));
					var fd = new FormData(this);
					var user_id = '<?php echo $user_id ?>';
					var city_name = $('#city').val();
					var taluka_name = $('#taluka').val();
					var village_name = $('#village').val();
					formData.append('city_name', city_name);
					formData.append('taluka_name', taluka_name);
					formData.append('village_name', village_name);
					formData.append('user_id', user_id);
					formData.append('email', '');
					formData.append('date', '');
					formData.append('owner_name', '');
					if (isOk) {
						$.ajax({
							type: 'POST',
							url: '<?php echo API_ROUTE_PATH ?>add_property.php',
							data: formData,
							dataType: 'json',
							contentType: false,
							cache: false,
							processData: false,
							beforeSend: function() {
								//  $('.submitBtn').attr("disabled","disabled");
								//$('#add_notice_form').css("opacity",".5");
							},
							success: function(responseJson) { //console.log(response);
								//var responseObj = JSON.parse(responseJson);
								if (responseJson.status == "true") {
									alert(responseJson.message);
									window.location.href = "<?php echo ADMIN_SITE_PATH ?>my-properties.php";
								} else {
									alert(responseJson.message);
								}
							}
						});
					}

				});

			});
		</script>

		<script>
			$(document).ready(function() {
				initVillageTypeAhead()
			});

			function initVillageTypeAhead() {
				var countries = new Bloodhound({
					datumTokenizer: Bloodhound.tokenizers.obj.whitespace('village_name'),
					queryTokenizer: Bloodhound.tokenizers.whitespace,
					//prefetch: '<?php echo $site_path ?>countries2.json',
					//local:dattum,
					//cache: false //NEW!
					remote: {
						url: '<?php echo API_ROUTE_PATH ?>village-typeahead.php?query=%QUERY',
						wildcard: '%QUERY',
						rateLimitWait: 500,
						transform: function(response) {
							//console.log(response);
							//eval(response.jsFunction);
							//return response.rows;
							return response;
						},
						cache: false //NEW!
					},
					limit: 20
					//local:dattum,

				});
				countries.clearPrefetchCache();
				countries.initialize();
				$('#village').typeahead({
					minLength: 2,
					hint: true,
					highlight: true,

				}, {
					name: 'village',
					display: 'village',
					limit: 20,
					source: countries.ttAdapter(),
				});
			}
		</script>
	<?php endif; ?>
	<?php include_once "tpl/tplFooter.php"; ?>
	<script src="custom_js/create_form.js" type="text/javascript"></script>
	<script src="dist/plugins/typeahead/typeahead.bundle.min.js" type="text/javascript"></script>
</body>

</html>