<?php
include_once 'bootstrap.php';
$TITLE = 'Activate Account';
session_start();
if ((isset($_SESSION['user_id'])) && isset($_SESSION['user_name']) && (!empty($_SESSION['user_id'])) && $_SESSION['is_login'] == 'true') {
	$user_id = $_SESSION['user_id'];
	$user_name  = $_SESSION['user_name'];
	$firstname = $_SESSION['firstname'];
	$lastname = $_SESSION['lastname'];
	$mobile_no = $_SESSION['mobile_no'];
	$verify_email = $_SESSION['verify_email'];
	$verify_otp = $_SESSION['verify_otp'];
} else {
	header('location:login.php');
	exit();
}
/* print_r($_SESSION); */
if ($verify_email && $verify_otp) {
	header('location:home.php');
	exit();
}
$plan = '';
$hasPlan = false;
if (isset($_GET['plan']) && !empty($_GET['plan'])) {
	$hasPlan = true;
	$plan = $_GET['plan'];
	$_SESSION['cart'] = $plan;
	$package = getPackages($plan);
}

if (isset($_POST['action'])) {
	if ($_POST['action'] == 'send-otp') {
		$mobile_no = $_POST['mobile_no'];
		//sendOtp($mobile_no);
		$mobile_no = strtolower($_POST['mobile_no']);
		$key = $mcrypt->encrypt($_POST['mobile_no']);
		unset($_POST['action']);
		$_POST['email'] = $user_name;
		$_POST['device_id'] = 'browser';
		$_POST['country_code'] = '91';
		$response = callApiJson($_POST, 'verify_email_mobile.php');
		//$message = $response['message'];
		echo json_encode($response);
		/* if ($response['status'] == 'true') {
			header('location: ' . SITE_PATH . 'verify-otp.php?key=' . $key . '');
		} else {
			header('location: ' . SITE_PATH . 'login-mobile.php?status=false&msg=' . $response['message'] . '');
		} */
		exit();
	}
	if ($_POST['action'] == 'verify-otp') {
		$mobile_no = $_POST['mobile_no'];
		$otp = $_POST['otp'];
		unset($_POST['action']);
		$_POST['mobile_no'] = $mobile_no;
		$response = callApiJson($_POST, 'verify_mobile.php');
		//$message = $response['message'];
		if ($response['status'] == 'true') {
			//header('location: ' . SITE_PATH . 'login.php');
			$_SESSION['verify_otp'] = true;;
			/* $data = $response['response'];
			$_SESSION['user_id'] = $data['user_id'];
			$_SESSION['firstname'] = $data['firstname'];
			$_SESSION['lastname'] = $data['lastname'];
			$_SESSION['mobile_no'] = $data['mobile_no'];
			$_SESSION['user_name'] = $data['email'];
			$_SESSION['verify_email'] = $data['verify_email'];
			$_SESSION['verify_otp'] = true;
			$_SESSION['is_login'] = 'true'; */

			/* if ($hasPlan) {
				header('location: ' . ADMIN_SITE_PATH . 'select-plan.php?plan=' . $plan . '');
				exit();
			}
			header('location: ' . ADMIN_SITE_PATH . 'home.php'); */
		} else {
			//header('location: ' . SITE_PATH . 'login-mobile.php?status=false');
		}
		echo json_encode($response);
		exit();
	}
	if ($_POST['action'] == 'send-email') {
		$email = $_POST['email'];
		sendEmail($email);
		exit();
	}
}
//include "header.php";	
?>
<html>

<head>
	<?php include_once 'tpl/tplHead.php'; ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
	<style>



	</style>
	<div class="container-fluid">




		<div class="">
			<!--Section: Live preview-->
			<section class="p-1">
				<hr class="my-5">
				<div class="row justify-content-center">
					<div class="col-lg-6 col-md-6 mb-12">

						<!-- Card -->
						<div class="card card-cascade wider">

							<!-- Card image -->
							<div class="view view-cascade gradient-card-header blue-gradient">

								<!-- Title -->
								<h2 class="card-header-title mb-3">Please Activate Your Account</h2>

							</div>

							<!-- Card content -->
							<div class="card-body card-body-cascade text-center">

								<!-- Text -->
								<p class="card-text" style="font-size: 1.2rem;">
									Welcome <?php echo "$firstname $lastname" ?>,</br>
									You account has been created. </br>
									<?php if (!$verify_otp) : ?>
										Please verify your Mobile Number </br>
									<?php endif ?>
									<?php if (!$verify_email) : ?>
										Please verify your Email Address </br>
									<?php endif ?>
								</p>
								<div class="modal-dialog modal-md cascading-modal modal-avatar d-none" role="document" id="otpForm">
									<!--Content-->
									<div class="modal-content">

										<!--Header-->
										<div class="modal-header">
											<img src="dist/img/phone.png" alt="avatar" class="rounded-circle img-responsive">
										</div>
										<!--Body-->
										<div class="modal-body text-center mb-1">

											<h5 class="mt-1 mb-2">Please Enter the OTP sent to your phone</h5>

											<div class="md-form ml-0 mr-0">
												<input type="text" class="form-control form-control-sm  ml-0" id="otpInput">
												<label data-error="Pleae Enter the OTP" data-success="right" for="form18" class="ml-0">Enter OTP</label>
											</div>

											<div class="text-center mt-4">
												<button class="btn btn-cyan mt-1 waves-effect waves-light" id="otpVerifyButton" onClick="verifyOtp()" style="font-size:20px">Verify <i class="fas fa-sign-in ml-1"></i></button>
											</div>
										</div>

									</div>
									<!--/.Content-->
								</div>
								<!-- Link -->
								<section class="section-preview">
									<?php
									if (!$verify_email) echo '<button type="button" class="btn btn-outline-secondary waves-effect" id="sendEmail" onClick="sendEmail()">Verify My Email</button>';
									?>
									<?php
									if (!$verify_otp) echo '<button type="button" class="btn btn-outline-success waves-effect"  id="sendOtp" onClick="sendOtp()" style="font-size:20px">Verify My Phone</button>';
									?>




								</section>

							</div>
							<!-- Card content -->

						</div>
						<!-- Card -->

					</div>
				</div>

			</section>


			<!--Section: Live preview-->
		</div>
		<!--Modal: Login with Avatar Form-->
		<div class="modal fade" id="emailSentModal" tabindex="-1" role="document" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog cascading-modal modal-avatar modal-md" role="document">
				<!--Content-->
				<div class="modal-content">

					<!--Header-->
					<div class="modal-header">
						<img src="dist/img/email.png" alt="avatar" class="rounded-circle img-responsive">
					</div>
					<!--Body-->
					<div class="modal-body text-center mb-1">

						<h5 class="mt-1 mb-2">An Email Has been sent to your registered Email Address, Please check your inbox and click on the link to verify your email. This Link is valid for 24 Hrs.</h5>



						<div class="text-center mt-4">
							<button class="btn btn-cyan mt-1" data-dismiss="modal">OK <i class="fas fa-sign-in ml-1"></i></button>
						</div>
					</div>

				</div>
				<!--/.Content-->
			</div>
		</div>

		<!--Modal: modalConfirmDelete-->
		<div class="modal fade" id="modalShowError" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-sm modal-notify modal-danger" role="document">
				<!--Content-->
				<div class="modal-content text-center">
					<!--Header-->
					<div class="modal-header d-flex justify-content-center">
						<p class="heading" id="headerModalShowError"></p>
					</div>

					<!--Body-->
					<div class="modal-body">

						<i class="fas fa-times fa-4x animated rotateIn"></i>

					</div>

					<!--Footer-->
					<div class="modal-footer flex-center">
						<button class="btn  btn-outline-danger" data-dismiss="modal">OK</button>
					</div>
				</div>
				<!--/.Content-->
			</div>
		</div>
		<!--Modal: modalConfirmDelete-->
		<div class="modal fade" id="modalShowSuccess" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-sm modal-notify modal-success" role="document">
				<!--Content-->
				<div class="modal-content text-center">
					<!--Header-->
					<div class="modal-header d-flex justify-content-center">
						<p class="heading" id="headerModalShowSuccess"></p>
					</div>

					<!--Body-->
					<div class="modal-body">

						<i class="fas fa-check fa-4x animated rotateIn"></i>

					</div>

					<!--Footer-->
					<div class="modal-footer flex-center">
						<button class="btn  btn-outline-success" data-dismiss="modal" onClick="location.reload()">OK</button>
					</div>
				</div>
				<!--/.Content-->
			</div>
		</div>
		<!--Modal: modalConfirmDelete-->
		<!--Modal: Login with Avatar Form-->
		<!-- /.End Edit Home/Flat Notice -->

		<script type="text/javascript">
			function sendOtp() {
				$.ajax({
					type: "POST",
					url: "",
					data: {
						mobile_no: '<?php echo $mobile_no ?>',
						action: 'send-otp',
					},
					success: function(response) {
						var responseObj = JSON.parse(response);
						if (responseObj.status == 'true') {
							$('#otpForm').removeClass('d-none');
							$('#sendOtp').text('RESEND OTP');
						} else {
							$('#headerModalShowError').html(responseObj.message);
							$('#modalShowError').modal('show');
						}

					}
				});
			}

			function verifyOtp() {
				$('#otpInput').removeClass('invalid');
				var otp = $('#otpInput').val();
				otp = $.trim(otp);
				if (!otp) {
					$('#otpInput').addClass('invalid');
					return;
				}
				$.ajax({
					type: "POST",
					url: "",
					data: {
						mobile_no: '<?php echo $mobile_no ?>',
						action: 'verify-otp',
						otp: otp,
					},
					success: function(response) {
						var responseObj = JSON.parse(response);
						if (responseObj.status == 'true') {
							$('#otpForm').addClass('d-none');
							$('#sendOtp').addClass('d-none');
							$('#headerModalShowSuccess').html('Mobile verified Succesfully');
							$('#modalShowSuccess').modal('show');
						} else {
							$('#headerModalShowError').html(responseObj.message);
							$('#modalShowError').modal('show');
						}

					}
				});
			}

			function sendEmail() {
				$.ajax({
					type: "POST",
					url: "",
					data: {
						email: '<?php echo $user_name ?>',
						action: 'send-email'
					},
					success: function(response) {
						var responseObj = JSON.parse(response);
						if (responseObj.status == 'true') {
							$('#sendEmail').addClass('d-none');
							$('#emailSentModal').modal('show');
						} else {

							$('#headerModalShowError').html(responseObj.message);
							$('#modalShowError').modal('show');
						}

					}
				});
			}

			/* $(document).on('click', '#sendOtp', function() {
				$('#otpForm').removeClass('d-none');
			}); */
		</script>


		<?php include "tpl/tplFooter.php"; ?>
</body>

</html>