<?php
include_once 'bootstrap.php';
include_once 'db.php';
$TITLE = 'Login';
session_start();
require_once('../decryption.php');
$mcrypt = new MCrypt();
if (isset($_GET['status'])) {
	$id = $_GET['status'];
	$message = $mcrypt->decrypt($id);
}

//var_export($_POST);

$response = array('mihpayid' => '403993715521849000', 'mode' => 'CC', 'status' => 'success', 'unmappedstatus' => 'captured', 'key' => 'jRmPEJ', 'txnid' => '5d4502d338637cbe01b8', 'amount' => '500.00', 'cardCategory' => 'domestic', 'discount' => '0.00', 'net_amount_debit' => '500', 'addedon' => '2020-10-18 08:57:15', 'productinfo' => 'eNoticeNinja Subscription Priyanshu Dubey ', 'firstname' => 'Priyanshu', 'lastname' => '', 'address1' => '', 'address2' => '', 'city' => '', 'state' => '', 'country' => '', 'zipcode' => '', 'email' => 'dubey.priyanshu2@gmail.com', 'phone' => '8826612435', 'udf1' => 'SP_Y01', 'udf2' => '', 'udf3' => '', 'udf4' => '', 'udf5' => '', 'udf6' => '', 'udf7' => '', 'udf8' => '', 'udf9' => '', 'udf10' => '', 'hash' => '56b6ef017b9fdfaf539fdca4c520f19d54ec6653f8aa39148794edcc92bdbb0e1725a0685e11be2d910d0150cbfa96d4c6bb6bbee8e7fb0ad28c7b3a0f0ca03e', 'field1' => '835689', 'field2' => '825387', 'field3' => '2048', 'field4' => '0', 'field5' => '91512346256', 'field6' => '00', 'field7' => 'AUTHPOSITIVE', 'field8' => 'Approved or completed successfully', 'field9' => 'No Error', 'payment_source' => 'payu', 'PG_TYPE' => 'AXISPG', 'bank_ref_num' => '835689', 'bankcode' => 'CC', 'error' => 'E000', 'error_Message' => 'No Error', 'name_on_card' => 'Test', 'cardnum' => '401200XXXXXX1112', 'cardhash' => 'This field is no longer supported in postback params.',);



//$_POST = $response;
$jsonData = $_POST;
//var_export($jsonData);
$response = array(
	'mihpayid' => '403993715521849000',
	'mode' => 'CC',
	'status' => 'success',
	'unmappedstatus' => 'captured',
	'key' => 'jRmPEJ',
	'txnid' => '5d4502d338637cbe01b8',
	'amount' => '500.00',
	'cardCategory' => 'domestic',
	'discount' => '0.00',
	'net_amount_debit' => '500',
	'addedon' => '2020-10-18 08:57:15',
	'productinfo' => 'eNoticeNinja Subscription Priyanshu Dubey ',
	'firstname' => 'Priyanshu',
	'lastname' => '',
	'address1' => '',
	'address2' => '',
	'city' => '',
	'state' => '',
	'country' => '',
	'zipcode' => '',
	'email' => 'dubey.priyanshu2@gmail.com',
	'phone' => '8826612435',
	'udf1' => '',
	'udf2' => '',
	'udf3' => '',
	'udf4' => '',
	'udf5' => '',
	'udf6' => '',
	'udf7' => '',
	'udf8' => '',
	'udf9' => '',
	'udf10' => '',
	'hash' => '56b6ef017b9fdfaf539fdca4c520f19d54ec6653f8aa39148794edcc92bdbb0e1725a0685e11be2d910d0150cbfa96d4c6bb6bbee8e7fb0ad28c7b3a0f0ca03e',
	'field1' => '835689',
	'field2' => '825387',
	'field3' => '2048',
	'field4' => '0',
	'field5' => '91512346256',
	'field6' => '00',
	'field7' => 'AUTHPOSITIVE',
	'field8' => 'Approved or completed successfully',
	'field9' => 'No Error',
	'payment_source' => 'payu',
	'PG_TYPE' => 'AXISPG',
	'bank_ref_num' => '835689',
	'bankcode' => 'CC',
	'error' => 'E000',
	'error_Message' => 'No Error',
	'name_on_card' => 'Test',
	'cardnum' => '401200XXXXXX1112',
	'cardhash' => 'This field is no longer supported in postback params.',
);
$amount =  $jsonData['amount'];
$user_id = $jsonData['udf2'];
$transaction_date = date('Y/m/d');
//$transaction_date=$jsonData['transaction_date'];	
$package_id = $jsonData['udf1'];
$package_name = $jsonData['udf1'];
$merchant_id = $jsonData['key'];
$order_id = $jsonData['mihpayid'];
$transaction_id = $jsonData['txnid'];
$order_status = $jsonData['status'];
$bank_ref_no = $jsonData['bank_ref_num'];
$payu_id = $jsonData['mihpayid'];
$payment_mode = $jsonData['mode'];
$payment_from = $jsonData['payment_source'];
//$expire_date =null;

$packages['SP_Y01']['name'] = '';
$packages['SP_Y01']['time'] = '';

$packages = getPackages();
$success = false;


	$dbData['amount'] =  $jsonData['amount'];
	//$dbData['package_name'] = $jsonData['udf2'];
	$dbData['transaction_date'] = date('Y/m/d');
	//$transaction_date=$jsonData['transaction_date'];	
	$dbData['package_id'] = $jsonData['udf1'];
	$dbData['user_id'] = $jsonData['udf2'];
	$dbData['merchant_id'] = $jsonData['key'];
	$dbData['order_id'] = $jsonData['mihpayid'];
	$dbData['transaction_id'] = $jsonData['txnid'];
	$dbData['order_status'] = $jsonData['status'];
	$dbData['bank_ref_no'] = $jsonData['bank_ref_num'];
	$dbData['payu_id'] = $jsonData['mihpayid'];
	$dbData['payment_mode'] = $jsonData['mode'];
	$dbData['payment_from'] = $jsonData['payment_source'];
	$dbData['package_name'] = $packages[$jsonData['udf1']]['name'];
	$dbData['property_quantity'] = $jsonData['udf3'];


	//print_r($response);
	$responseArr = callApiJson($dbData, 'paymentapi.php');
	if ($responseArr['status'] == true) {
		$success = true;
	}
	else {

	}

?>
<!DOCTYPE html>
<html>

<head>
	<?php include_once 'tpl/tplHead.php'; ?>
</head>

<body class="hold-transition login-page">
	<section class="p-1">

		<?php if ($success) { ?>
		<div class="modal-dialog modal-notify modal-success" role="document" style="margin:60px">
			<!--Content-->
			<div class="modal-content text-center">
				<!--Header-->
				<div class="modal-header d-flex justify-content-center">
					<p class="heading">Payment Succesful</p>
				</div>

				<!--Body-->
				<div class="modal-body">
					<i class="fas fa-check fa-4x animated rotateIn mb-4 "></i>
					<p>Congratulations! Your membership is active, Please Log in.</p>
				</div>

				<!--Footer-->
				<div class="modal-footer flex-center">
					<a href="<?php echo SITE_PATH ?>login.php" class="btn btn-success btn-block waves-effect waves-light">LOGIN</a>

				</div>
			</div>
			<!--/.Content-->
		</div>
	<?php } else { ?>
		<div class="modal-dialog modal-notify modal-danger" role="document" style="margin:60px">
			<!--Content-->
			<div class="modal-content text-center">
				<!--Header-->
				<div class="modal-header d-flex justify-content-center">
					<p class="heading">Payment Succesful</p>
				</div>

				<!--Body-->
				<div class="modal-body">

					<i class="fas fa-times  fa-4x animated rotateIn mb-4 "></i>
					<p>Sorry! Unfortunately Your Payment failed. Please log in and try again.</p>

				</div>

				<!--Footer-->
				<div class="modal-footer flex-center">
					<a href="<?php echo SITE_PATH ?>login.php" class="btn btn-danger btn-block waves-effect waves-light">LOGIN</a>

				</div>
			</div>
			<!--/.Content-->
		</div>
	<?php }  ?>

	</section>

	<!-- jQuery -->
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap 4 -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="dist/mdb/js/mdb.min.js"></script>
	<script src="dist/mdb/js/mdb.min.js"></script>

</body>

</html>