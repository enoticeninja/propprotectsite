<?php
include_once 'bootstrap.php';
session_start();
session_destroy();
$_SESSION['user_name'] = '';
$_SESSION['is_login'] = 'false';
header('location: ' . SITE_PATH . 'login.php');
?>