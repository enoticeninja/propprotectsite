<?php
include_once 'bootstrap.php';
include_once 'common.php';
$TITLE = 'Reset Password';

?>
<!DOCTYPE html>
<html>

<head>
	<?php include_once 'tpl/tplHead.php'; ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
	<style>
		.center {
			display: block;
			margin-left: auto;
			margin-right: auto;
		}

		.modal-dialog {
			overflow-y: initial !important
		}

		.modal-body {
			height: 377px;
			overflow-y: auto;
		}

		.alert {
			display: none;
		}

		.alert-success {
			color: #1cb722;
			background: #c6e4a3;
			border-color: #23923d;
		}
	</style>
	<div class="wrapper">
		<?php include_once 'tpl/tplHeader.php'; ?>
		<?php include_once 'tpl/tplSidebar.php'; ?>

		<body class="hold-transition sidebar-mini layout-fixed">
			<div class="wrapper">


				<!-- Content Wrapper. Contains page content -->
				<div class="content-wrapper">

					<!-- Main content -->
					<section class="content">
						<div class="container-fluid">
							<div class="row">
								<div class="col-sm-12 text-center">
									<div class="mx-auto" style="width:400px;margin:50px">


										<div class="card card-cascade wider">
											<div class="view view-cascade gradient-card-header blue-gradient">

												<!-- Title -->
												<h2 class="card-header-title mb-3">Reset Password</h2>

											</div>
											<div class="card-body register-card-body card-body-cascade text-center">
												<form role="form" onsubmit="return false;" id='reset_pssword'>
													<input type="hidden" id="user_id" name="user_id" value="<?php echo $user_id ?>">
													<div class="alert alert-success alert-dismissable" id="success_alert">
														<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
														<strong id="success_message"></strong>
													</div>
													<div class="alert alert-danger alert-dismissable" id="error">
														<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
														<p id="error_message"></p>
													</div>
													<div class="row">
														<div class="col-sm-12">
															<div class="form-group">
																<label>Email<span aria-hidden="true" class="required" style="color: red;">*</span></label>
																<input type="email" id="email" name="email" value="<?php echo $user_name ?>" class="form-control" placeholder="Enter email" disabled required>
															</div>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-12">
															<div class="form-group">
																<label>Current Password<span aria-hidden="true" class="required" style="color: red;">*</span></label>

																<div class="input-group mb-3">
																	<input type="password" id="current_password" name="current_password" class="form-control" placeholder="Enter current password" required>
																	<div class="input-group-append">
																		<div class="input-group-text" style="background-color: white;">
																			<span toggle="#current_password" class="fa fa-fw fa-eye toggle-password"></span>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-12">
															<!-- <div class="form-group"> -->
															<label>New Password<span aria-hidden="true" class="required" style="color: red;">*</span></label>
															<div class="input-group mb-3">
																<input type="password" id="new_password" name="new_password" class="form-control" placeholder="Enter new password" required>
																<div class="input-group-append">
																	<div class="input-group-text" style="background-color: white;">
																		<span toggle="#new_password" class="fa fa-fw fa-eye toggle-password"></span>
																	</div>
																</div>
															</div>
															<!-- </div> -->
														</div>
													</div>
													<div class="row">
														<div class="col-sm-12">
															<div class="form-group">
																<label>Confirm New Password<span aria-hidden="true" class="required" style="color: red;">*</span></label>
																<!-- <input type="password" id="confirm_new_password" name="confirm_new_password" class="form-control" placeholder="Confirm new password" required> -->
																<div class="input-group mb-3">
																	<input type="password" id="confirm_new_password" name="confirm_new_password" class="form-control" placeholder="Confirm new password" required>
																	<div class="input-group-append">
																		<div class="input-group-text" style="background-color: white;">
																			<span toggle="#confirm_new_password" class="fa fa-fw fa-eye toggle-password"></span>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div class="col-12">
														<button type="button" class="btn btn-secondary d-none">Close</button>
														<a class="btn btn-primary" id="modal_btnSubmit1" onClick="reset_password()">UPDATE</a>
													</div>
											</div>

											</form>
										</div>
									</div>
									<!-- right column -->

									<!--/.col (right) -->
								</div>
								<!-- /.row -->
							</div>
					</section>
					<!-- /.content -->
				</div>

				<aside class="control-sidebar control-sidebar-dark">
					<!-- Control sidebar content goes here -->
				</aside>
				<!-- /.control-sidebar -->
			</div>
			<!-- ./wrapper -->
			<!-- start search modal -->
			<div class="modal fade" id="profileModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
				<div class="modal-dialog modal-dialog-centered" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="exampleModalLongTitle">Reset Password</h5>
							<button type="button" class="close" aria-label="Close">
								<a href="<?php echo ADMIN_SITE_PATH ?>home.php"><span aria-hidden="true" style="color: black;">&times;</span></a>
							</button>
						</div>
						<div class="modal-body">

						</div>
					</div>
				</div>
				<!-- end search modal here -->

				<script type="text/javascript">
					$(document).ready(function() {
						//$('#profileModal').modal('show');

					});
					$(".toggle-password").click(function() {

						$(this).toggleClass("fa-eye fa-eye-slash");
						var input = $($(this).attr("toggle"));
						if (input.attr("type") == "password") {
							input.attr("type", "text");
						} else {
							input.attr("type", "password");
						}
					});

					$("#reset_pssword").on('submit', function(e) {
						e.preventDefault();
						var current_password = document.getElementById("current_password").value;
						var password = document.getElementById("new_password").value;
						var confirm_password = document.getElementById("confirm_new_password").value;
						var n = password.localeCompare(confirm_password);
						if (password != confirm_password) {
							alert("New password doesn't match with confirm password.");
						} else {

							var fd = new FormData(that);
							fd.append('email', "<?php echo $user_name ?>");
							fd.append('password ', password);
							fd.append('current_pass ', current_password);
							$.ajax({
								type: "POST",
								url: "<?php echo API_SITE_PATH ?>password_changed_cryp.php",
								data: fd,
								success: function(result) {
									var responseObj = JSON.parse(result);
									if (responseObj.status == "true") {
										alert("Your password is updated successfuly! Please Login again.");
										window.location = "<?php echo ADMIN_SITE_PATH ?>logout.php";
										// $('#success_message').html(result.message);
										//   $("#success_alert").show();
										//   $("#success_alert").fadeTo(2000, 500).slideUp(500, function(){

										//   $("#success_alert").slideUp(500);
										// });
										// var timer = setTimeout(function() {
										//   window.location="http://www.nanostuffs.com/lawyer/admin/logout.php";
										// }, 3600);


									} else {
										alert(responseObj.message);
									}

								}
							});
						}
					});


					function reset_password() {
						var password = document.getElementById("new_password").value;
						var confirm_password = document.getElementById("confirm_new_password").value;
						var n = password.localeCompare(confirm_password);
						if (password != confirm_password) {
							alert("New password doesn't match with confirm password.");
						} else {
							var formData = new FormData(document.getElementById('reset_pssword'));
							//var formData = new FormData(that);
							formData.append('email', "<?php echo $user_name ?>");
							formData.append('password ', password);
							$.ajax({
								type: "POST",
								url: "<?php echo API_SITE_PATH ?>admin_reset_password_api.php",
								data: formData,
								contentType: false,
								cache: false,
								processData: false,
								success: function(result) {
									var responseObj = JSON.parse(result);
									if (responseObj.status == "true") {
										alert("Your password is updated successfuly! Please Login again.");
										window.location = "<?php echo ADMIN_SITE_PATH ?>logout.php";
										// $('#success_message').html(result.message);
										//   $("#success_alert").show();
										//   $("#success_alert").fadeTo(2000, 500).slideUp(500, function(){

										//   $("#success_alert").slideUp(500);
										// });
										// var timer = setTimeout(function() {
										//   window.location="http://www.nanostuffs.com/lawyer/admin/logout.php";
										// }, 3600);


									} else {
										alert(responseObj.message);
									}

								}
							});
						}

					}
				</script>
				<?php include_once "tpl/tplFooter.php"; ?>
		</body>

</html>