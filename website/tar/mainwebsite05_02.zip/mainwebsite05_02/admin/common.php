<?php
session_start();

//$_SESSION['verify_otp'] = false;
if ((isset($_SESSION['user_id'])) && isset($_SESSION['user_name']) && (!empty($_SESSION['user_id'])) && $_SESSION['is_login'] == 'true') {
	$user_id = $_SESSION['user_id'];
	$user_name  = $_SESSION['user_name'];
	$firstname = $_SESSION['firstname'];
	$lastname = $_SESSION['lastname'];
	$mobile_no = $_SESSION['mobile_no'];
	$verify_email = $_SESSION['verify_email'];
	$verify_otp = $_SESSION['verify_otp'];

	if(!$verify_email || !$verify_otp){
		header('location:activate_account.php');
		exit();
	}
} else {
	header('location:login.php');
	exit();
}
?>
