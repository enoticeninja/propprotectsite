<?php
include_once 'bootstrap.php';
include_once 'db.php';
$TITLE = 'Login';
session_start();
require_once('../decryption.php');
$mcrypt = new MCrypt();

$plan = '';
$hasPlan = false;
if (isset($_GET['plan']) && !empty($_GET['plan'])) {
	$hasPlan = true;
	$plan = $_GET['plan'];
	$_SESSION['cart'] = $plan;
	$package = getPackages($plan);
}

if ((isset($_SESSION['user_id'])) && isset($_SESSION['user_name']) && (!empty($_SESSION['user_id'])) && $_SESSION['is_login'] == 'true') {
	if ($hasPlan) {
		header('location: ' . ADMIN_SITE_PATH . 'select-plan.php?plan=' . $plan . '');
		exit();
	}
	header('location: home.php');
} else {
	if (isset($_POST["submit_mobile_no"])) {

		$mobile_no = strtolower($_POST['mobile_no']);
		$key = $mcrypt->encrypt($_POST['mobile_no']);
		// $password = $_POST['password'];

		$sqlQ = "SELECT * from tbl_user where mobile_no='" . $mobile_no . "'";
		$sqlQuery = mysqli_query($conn, $sqlQ);
		$row = $sqlQuery->fetch_array();
		$count = mysqli_num_rows($sqlQuery);

		if ($count > 0) {
			$sqlQ = "SELECT * from otp where mobile_no='" . $mobile_no . "'";
			$sqlQuery = mysqli_query($conn, $sqlQ);
			$row = $sqlQuery->fetch_array();
			$count = mysqli_num_rows($sqlQuery);
			if ($count > 0) {
				date_default_timezone_set('Asia/Kolkata');
				$date = date("Y-m-d H:i:s");
				$otp = rand(100000, 999999);
				$apiKey = 'g8EudPMPskU-wRdvR1IFmpz9XIEWK6DGRiSKxISWqW';
				$message = "" . $otp . " is the OTP for eNoticeNinja Application. Please do not share with anyone for security reasons - eNoticeNinja";
				//$numbers = $mobile_no; 
				//$numbers = $mobile_no ; 
				$sender = urlencode('ENOTIC');
				$message = rawurlencode($message);
				//$numbers = implode(',', $numbers);
				$data = array('apikey' => $apiKey, 'numbers' => $mobile_no, "sender" => $sender, "message" => $message);
				$ch = curl_init('https://api.textlocal.in/send/');
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$response = curl_exec($ch);
				curl_close($ch);
				//echo $response;
				//die();


				$is_expired = "0";

				$sql = "UPDATE otp SET otp='" . $otp . "',mobile_no='" . $mobile_no . "',is_expired='" . $is_expired . "',create_at='" . $date . "' where mobile_no='$mobile_no'";
			} else {
				date_default_timezone_set('Asia/Kolkata');
				$date = date("Y-m-d H:i:s");
				$otp = rand(100000, 999999);
				$apiKey = 'g8EudPMPskU-wRdvR1IFmpz9XIEWK6DGRiSKxISWqW';
				$message = " Your eNoticeNinja Application OTP for login is  " . $otp . ".This OTP will be valid for 10 minutes.";
				//$numbers = $mobile_no; 
				//$numbers = $mobile_no; 
				$sender = urlencode('eNoticeNinja');
				$message = rawurlencode($message);
				//$numbers = implode(',', $numbers);
				$data = array('apikey' => $apiKey, 'numbers' => $mobile_no, "sender" => $sender, "message" => $message);
				$ch = curl_init('https://api.textlocal.in/send/');
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$response = curl_exec($ch);
				curl_close($ch);
				//echo $response;
				//die();		
				$is_expired = "0";

				$sql = "INSERT INTO otp(otp,mobile_no,is_expired,create_at) VALUES ('" . $otp . "','" . $mobile_no . "','" . $is_expired . "','" . $date . "')";
			}

			$result = mysqli_query($conn, $sql);
			if ($result) {
				header('location: verifyotp.php?key=' . $key . '');
			} else {
				header('location: login_mob.php?status=false');
			}
		} else {
			$queryLogin = "UPDATE login set is_login='false' WHERE user_name = '$user_name'";
			//$mysqli->query($queryLogin);
			$sqlQueryL = mysqli_query($conn, $queryLogin);
			/*  $_SESSION['user_name'] = '';
            $_SESSION['is_login'] = 'false'; */

			header('location: login_mob.php?status=false');
		}
	}
}
?>
	<!DOCTYPE html>
	<html>

	<head>
		<?php include_once 'tpl/tplHead.php'; ?>
	</head>

	<body class="hold-transition login-page">
		<div class="login-box">

			<!-- /.login-logo -->
			<div class="card card-cascade wider">
				<div class="view view-cascade gradient-card-header blue-gradient">

					<!-- Title -->
					<h2 class="card-header-title mb-3">Login</h2>

				</div>
				<div class="card-body register-card-body card-body-cascade text-center">
					<img src="dist/img/logoimage.png" alt="AdminLTE Logo" class="brand-image d-none" style="width: 100%;height: 25%;margin-bottom: 0%;">

					<form id='login-form' method="post" action="<?php echo ADMIN_SITE_PATH ?>login_mob.php?plan=<?php echo $plan ?>">
						<p style="text-align: center; color:Black;">Search You Can Trust</p>

						<div class="col-8">
							<div class="icheck-primary">
								<p class="mb-1">
									<?php if (@$_GET['status'] == 'false') {
										echo "<font color='red'>Invalid mobile number </font>";
									} ?>
								</p>
							</div>
						</div>
						<div>
							<div class="input-group mb-3">
								<input type="text" class="form-control" id="mobile_no" name="mobile_no" onkeypress="return isNumber1(event)" onfocus="myFunction('mobile_error')" maxlength="10" onblur="validatephone(this.value);" placeholder="Mobile Number" required>
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-mobile"></span>
									</div>
								</div>

							</div>
							<div id="mobile_error" style="color:red;"></div>
						</div>
						<!-- <div class="input-group mb-3">
						<input id="password-field" type="password" class="form-control" name="password" placeholder="Password">
						<div class="input-group-append">
							<div class="input-group-text">
							<span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
							</div>
						</div>
						</div>-->
						<div class="row">
							<div class="col-8">

							</div>
							<!-- /.col -->
							<div class="col-12">
								<button type="submit" name="submit_mobile_no" id="login_button" class="btn btn-primary btn-block float-right">Continue</button>
							</div>
							<!-- /.col -->
						</div>
						</br>
					</form>

					<div class="row">

						<!-- /.col -->
						<div class="col-12">
							<p class="mb-1">
								<a href="<?php echo ADMIN_SITE_PATH ?>register.php?plan=<?php echo $plan ?>" class="btn btn-secondary btn-block float-right">Sign up</a>
							</p>
						</div>
						<div class="col-12">

							<p class="mb-1">
								<a href="<?php echo ADMIN_SITE_PATH ?>login.php?plan=<?php echo $plan ?>" class="btn btn-deep-purple btn-block float-right">Login with Email/Username</a>
							</p>

						</div>
						<div class="col-12">

							<p class="mb-1">
								<a href="<?php echo ADMIN_SITE_PATH ?>forgot-password.php" class="btn btn-danger btn-block float-right">Forgot Password</a>
							</p>

						</div>
						<div class="col-4 d-none">


						</div>
						<div class="col-2">


						</div>
						<!-- /.col -->
					</div>


					<div class="row">
						<!-- /.col -->
						<div class="col-4">
							<p class="mb-12">

							</p>
						</div>

						<!-- /.col -->
					</div>

				</div>
				<!-- /.login-card-body -->
			</div>
		</div>
		<!-- /.login-box -->

		<!-- jQuery -->
		<script src="plugins/jquery/jquery.min.js"></script>
		<!-- Bootstrap 4 -->
		<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
		<!-- AdminLTE App -->
		<script src="dist/js/adminlte.min.js"></script>
		<script>
			var hasPlan = <?php echo json_encode($hasPlan) ?>;

			function myFunction(val) {
				document.getElementById(val).style.display = 'none';
				document.getElementById(val).innerHTML = '';
			}

			function isNumber1(evt) {
				evt = (evt) ? evt : window.event;
				var charCode = (evt.which) ? evt.which : evt.keyCode;
				if (charCode >= 48 && charCode <= 57) {
					return true;
				}
				return false;
			}

			function validatephone(val) {
				if (/^\d{10}$/.test(val)) {
					// value is ok, use it
				} else {
					document.getElementById('mobile_error').style.display = '';
					document.getElementById("mobile_error").innerHTML = 'Kindly Enter 10 digit Mobile Number';
					return false;
				}
			}

			$(".toggle-password").click(function() {

				$(this).toggleClass("fa-eye fa-eye-slash");
				var input = $($(this).attr("toggle"));
				if (input.attr("type") == "password") {
					input.attr("type", "text");
				} else {
					input.attr("type", "password");
				}
			});
		</script>
	</body>

	</html>
