		function createForm(form_config) {
			var formFields = form_config['fields'];
			if (!form_config['data']) form_config['data'] = {};
			toolsAll['property'] = {};
			toolsAll['property']['required'] = {};
			var formHtml = '';
			$.each(formFields, function(field, fieldData) {
				var fieldHtml = '';
				fieldData['name'] = field;
				fieldData['id'] = field;
				if (form_config['data'][field]) {
					fieldData['value'] = form_config['data'][field];
				}
				if (fieldData['required']) {
					toolsAll['property']['required'][field] = true;
					fieldData['label'] += '<span class="text-danger">(*)</span>';
					//fieldData['extra'] = ' required';
				}

				if (fieldData['type'] == 'select') {
					fieldHtml += getSelectFromArray(fieldData);
				}
				if (fieldData['type'] == 'input') {
					fieldHtml += getInputFromArray(fieldData);
				}
				var width = '4';
				if (fieldData['width']) width = fieldData['width'];
				if (fieldData['inputType'] == 'hidden') {
					formHtml += '<div class="col-' + width + ' d-none">' + fieldHtml + '</div>';
				} else {
					formHtml += '<div class="col-' + width + ' mb-4">' + fieldHtml + '</div>';
				}
			});
			
			return formHtml;
		}

		function getSelectFromArray($dataArray) {
			var $disabled = '';
			//if($this->isDisabled == 'readonly') $disabled = 'disabled';	
			var $name = ($dataArray['name']) ? $dataArray['name'] : $dataArray['id'];
			var $id = ($dataArray['id']) ? $dataArray['id'] : '';
			var $type = ($dataArray['form_group_type']) ? $dataArray['form_group_type'] : ' floating-12-12';
			var $class = ($dataArray['class']) ? $dataArray['class'] : '';
			var $placeholder = ($dataArray['placeholder']) ? $dataArray['placeholder'] : '';
			var $label = ($dataArray['label']) ? $dataArray['label'] : '';
			var $help = ($dataArray['help']) ? $dataArray['help'] : '';
			var $selected = ($dataArray['value']) ? $dataArray['value'] : false;
			var $extraCode = ($dataArray['extra']) ? $dataArray['extra'] : '';
			var $options = ($dataArray['options']) ? $dataArray['options'] : false;
			var $hidden = (($dataArray['hidden']) && $dataArray['hidden'] == true) ? 'hidden' : '';
			var $onClick = ($dataArray['onClick']) ? $dataArray['onClick'] : '';
			var $onChange = ($dataArray['onChange']) ? $dataArray['onChange'] : '';
			var $onFocus = ($dataArray['onFocus']) ? $dataArray['onFocus'] : '';
			var $onblur = ($dataArray['onblur']) ? $dataArray['onblur'] : '';
			var $otherClasses = '';
			var $form_group_class = '';
			var $input = '',$return1 = '';
			var $icon = ($dataArray['icon']) ? $dataArray['icon'] : '';
			$form_group_class = 'form-group';
			if ($icon) {
				$form_group_class = 'input-group';
				$icon = '<div class="input-group-prepend">\
				<span class = "input-group-text" id = "basic-addon1">\
				<span class = "' + $icon + '"> </span>\
				</span>\
				</div>';
			}
			labelHtml = '<label class="col-md-12 control-label text-left">' + $label + '</label>';

			if ($dataArray['placeholder_only']) {
				labelHtml = '';
				if (!$placeholder) $placeholder = $dataArray['placeholder_only'];
			}

			$extraCode += (($dataArray['live_search']) && $dataArray['live_search']) ? ' data-live-search="true"' : '';

			if ($selected && $selected != '') $otherClasses += ' edited';
			var $cols = {};
			$cols = $type.split('-');
			$cols[0] = $.trim($cols[0]);

			var $options1 = '<option></option>';
			if (typeof $options == 'object') {
					$.each($options, function ($key, $value) {
						$isSelected = '';
						if ($selected && ($key == $selected || $value == $selected)) $isSelected = 'selected';

						$options1 += '<option value="' + $value + '" ' + $isSelected + '>' + $value + '</option>';
					});
			} else {
				$options1 = $options;
			}

			$input = '<select name="' + $name + '" class=" form-control ' + $class + ' ' + $otherClasses + '" id="' + $id + '" ' + $disabled + ' ' + $extraCode + ' data-live-search="true" onClick="' + $onClick + '" onChange="' + $onChange + '" onFocus="' + $onFocus + '" onblur="' + $onblur + '">' + $options1 + '</select>';
			if ($dataArray['element_only']) {
				$return1 = $input;
				return $return1;
			}


			$return1 =
				'<div class="' + $form_group_class + ' input-group">\
					'+labelHtml+'\
					' + $input + '\
					<span class = "help-block" > ' + $help + ' </span>\
					'+$icon+'\
				</div>';

			return $return1;
		}


		function getInputFromArray($dataArray) {
			var $inputType = (($dataArray['inputType']) && $dataArray['inputType'] != '') ? $dataArray['inputType'] : 'text';

			var $name = ($dataArray['name']) ? $dataArray['name'] : $dataArray['id'];
			var $id = ($dataArray['id']) ? $dataArray['id'] : '';
			var $type = ($dataArray['form_group_type']) ? $dataArray['form_group_type'] : ' floating-12-12';
			var $class = ($dataArray['class']) ? $dataArray['class'] : '';
			var $placeholder = ($dataArray['placeholder']) ? $dataArray['placeholder'] : '';
			var $label = ($dataArray['label']) ? $dataArray['label'] : '';
			if ($dataArray['hide_label']) $label = '';
			var $help = ($dataArray['help']) ? $dataArray['help'] : '';
			var $hidden = (($dataArray['hidden']) && $dataArray['hidden'] == true) ? 'hidden' : '';
			var $onClick = ($dataArray['onClick']) ? $dataArray['onClick'] : '';
			var $onChange = ($dataArray['onChange']) ? $dataArray['onChange'] : '';
			var $onFocus = ($dataArray['onFocus']) ? $dataArray['onFocus'] : '';
			var $onblur = ($dataArray['onblur']) ? $dataArray['onblur'] : '';

			var $value = (($dataArray['value']) && $dataArray['value'] != '') ? 'value="' + $dataArray['value'] + '"' : '';
			var $isDoubleColumn = (($dataArray['isDoubleColumn']) && $dataArray['isDoubleColumn'] != '') ? $dataArray['isDoubleColumn'] : false;
			var $extraCode = ($dataArray['extra']) ? $dataArray['extra'] : '';
			var $autoComplete = $dataArray['autoComplete'] ? $dataArray['autoComplete'] : 'off';
			var $readOnly = $dataArray['readOnly'] ? 'readonly' : '';
			var $return = '',$return1 = '',$return2 = '';
			var $form_group_class = '';
			var $otherClasses = '';
			var $icon = ($dataArray['icon']) ? $dataArray['icon'] : '';
			$form_group_class = 'form-group';
			if ($icon) {
				$form_group_class = 'input-group';
				$icon = '<div class="input-group-prepend">\
				<span class = "input-group-text" id = "basic-addon1">\
				<span class = "' + $icon + '"> </span>\
				</span>\
				</div>';
			}
			labelHtml = '<label class="col-md-12 control-label text-left">' + $label + '</label>';

			if ($dataArray['placeholder_only']) {
				labelHtml = '';
				if (!$placeholder) $placeholder = $dataArray['placeholder_only'];
			}
			//$icon = (($dataArray['icon']) && $dataArray['icon'] != '') ? '<i class="' + $dataArray['icon'] + '"></i>' : '';

			$input = '<input type="' + $inputType + '" class="form-control ' + $class + ' ' + $otherClasses + '" name="' + $name + '" id="' + $id + '" placeholder="' + $placeholder + '" ' + $value + ' ' + $extraCode + ' autocomplete="' + $autoComplete + '" ' + $readOnly + ' onClick="' + $onClick + '" onChange="' + $onChange + '" onFocus="' + $onFocus + '" onblur="' + $onblur + '">\
			';

			if ($dataArray['element_only']) {
				$return1 = $input;
				return $return1;
			}

			$return1 =
			'\
			<div class="'+$form_group_class+' ' + $hidden + '"> \
				'+labelHtml+'\
				' + $input + '\
				'+$icon+'\
				<div class="form-text text-muted"> ' + $help + ' </div>\
			</div>\
			';


			return $return1;
		}

		var __FORM_WRAPPER__ = '.form-group';
		var __FORM_ELEMENT_ADDON__ = '.input-group-addon';
		var __FORM_ELEMENT_HELP__ = '.form-text';
		var __ERROR_STATE__ = 'text-danger';
		var __WARNING_STATE__ = 'text-warning';
		var __SUCCESS_STATE__ = 'text-success';
		var __INFO_STATE__ = 'text-info';
		var __ERROR_ICON__ = 'fa fa-error';

		function showErrorOnElement(elem, msg) {
			resetElementState(elem);
			$('#' + elem + '').addClass('edited');
			//$('#' + elem + '').addClass(__ERROR_STATE__);
			if ($('#' + elem + '').closest(__FORM_WRAPPER__).length) {
				//$('#' + elem + '').closest(__FORM_WRAPPER__).addClass(__ERROR_STATE__);
				$('#' + elem + '').closest(__FORM_WRAPPER__).find('.form-label').addClass(__ERROR_STATE__);
				$('#' + elem + '').closest(__FORM_WRAPPER__).find('.control-label').addClass(__ERROR_STATE__);
				/* $('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_ADDON__).html('<i class="' + __ERROR_ICON__ + '"></i>');
				$('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_HELP__).css('opacity', '1');
				$('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_HELP__).html(msg);
				$('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_HELP__).addClass('highlight-element'); */
			} else {
				showErrorPopoversOnElements(elem, msg);
			}
			//console.log($('#'+elem+'').attr('data-showpopovererror'));
			//console.log($('#'+elem+'').attr('id'));
			if ($('#' + elem + '').attr('data-showpopovererror')) {
				showErrorPopoversOnElements(elem, msg);
			}
			//showErrorPopoversOnElements(elem,msg);

		}

		function showSuccessOnElement(elem, msg) {
			resetElementState(elem);
			var iconn = '';
			if (tools.hasOwnProperty('icons') && tools['icons'].hasOwnProperty(elem)) {
				iconn = tools['icons'][elem];
			}
			var helpp = '';
			if (tools.hasOwnProperty('help') && tools['help'].hasOwnProperty(elem)) {
				helpp = tools['help'][elem];
			}
			if (msg == '' || typeof msg === 'undefined') msg = helpp;
			$('#' + elem + '').closest(__FORM_WRAPPER__).addClass(__SUCCESS_STATE__);
			/*$('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_ADDON__).html('<i class="' + iconn + ' ' + __SUCCESS_ICON_FONT__ + ' "></i><i class="' + __SUCCESS_ICON__ + ' ' + __SUCCESS_ICON_FONT__ + '"></i>');
			 $('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_HELP__).css('opacity', '1');
			$('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_HELP__).html(msg);
			$('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_HELP__).addClass('highlight-element'); */
			$('#' + elem + '').addClass('edited');
			try {
				$('#' + elem + '-holder').popover('dispose');
			} catch (ex) {}
			try {
				$('#' + elem + '').popover('dispose');
			} catch (ex) {}
		}


		function resetElementState(elem) {
			var iconn = '';
			if (tools.hasOwnProperty('icons') && tools['icons'].hasOwnProperty(elem)) {
				iconn = tools['icons'][elem];
			}

			var titt = '';
			if (tools.hasOwnProperty('titles') && tools['titles'].hasOwnProperty(elem)) {
				titt = tools['titles'][elem];
			}
			var helpp = '';
			if (tools.hasOwnProperty('help') && tools['help'].hasOwnProperty(elem)) {
				helpp = tools['help'][elem];
			}
			$('#' + elem + '').closest(__FORM_WRAPPER__).removeClass('' + __SUCCESS_STATE__ + ' ' + __ERROR_STATE__ + ' ' + __WARNING_STATE__ + ' ' + __INFO_STATE__ + '');
			$('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_ADDON__).html('<i class="' + iconn + '"></i>');
			$('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_HELP__).css('opacity', '1');
			$('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_HELP__).html(helpp);
			$('#' + elem + '').closest(__FORM_WRAPPER__).find(__FORM_ELEMENT_HELP__).removeClass('highlight-element');
			//$('#'+elem+'').removeClass('edited');

			try {
				$('#' + elem + '-holder').popover('dispose');
			} catch (ex) {}
			try {
				$('#' + elem + '').popover('dispose');
			} catch (ex) {}

		}