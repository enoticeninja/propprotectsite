<?php
include_once 'bootstrap.php';
include_once 'common.php';
$TITLE = 'My Profile';

?>
<!DOCTYPE html>
<html>

<head>
	<?php include_once 'tpl/tplHead.php'; ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
	<style>
		.center {
			display: block;
			margin-left: auto;
			margin-right: auto;
		}

		.modal-dialog {
			overflow-y: initial !important
		}

		.modal-body {
			height: 580px;
			overflow-y: auto;
		}

		.alert {
			display: none;
		}

		.alert-success {
			color: #1cb722;
			background: #c6e4a3;
			border-color: #23923d;
		}
	</style>
	<div class="wrapper">
		<?php include_once 'tpl/tplHeader.php'; ?>
		<?php include_once 'tpl/tplSidebar.php'; ?>

		<body class="hold-transition sidebar-mini layout-fixed">
			<div class="wrapper">


				<!-- Content Wrapper. Contains page content -->
				<div class="content-wrapper">

					<!-- Main content -->
					<section class="content">
						<div class="container-fluid">
							<div class="row">
								<div class="col-sm-12 text-center">
									<div class="mx-auto" style="width:500px;margin:50px">


										<div class="card card-cascade wider">
											<div class="view view-cascade gradient-card-header blue-gradient">

												<!-- Title -->
												<h2 class="card-header-title mb-3">Your Profile</h2>

											</div>
											<div class="card-body register-card-body card-body-cascade text-center">
												<form role="form" onsubmit="update_profile(this);  return false;" id='update_profile_picture'>
													<input type="hidden" id="user_id" name="id" value="<?php echo $user_id ?>">
													<!-- <div class="alert alert-success alert-dismissable">
													<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
													<strong id ="success_message"></strong>
														</div> -->
													<div class="row">

														<div class="col-sm-12">
															<div class="form-group">
																<img src="dist/img/admin_avtar.png" id="profile_picture" class="img-circle center" alt="User Image" style="width: 150px;height: 150px;" />
																<label for="edit_profile_file" style="margin-left: 40%;">Profile Picture</label>
																<input type="file" id="edit_profile_file" name="file" accept="image/*" style="visibility:hidden;" />
															</div>
														</div>
													</div>
													<div class="row" style="margin-top: -9%;">
														<div class="col-sm-12">
															<div class="form-group">
																<label>First Name<span aria-hidden="true" class="required" style="color: red;">*</span></label>
																<input type="text" id="first_name" name="first_name" class="form-control" placeholder="Enter first name" required>
															</div>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-12">
															<div class="form-group">
																<label>Last Name<span aria-hidden="true" class="required" style="color: red;">*</span></label>
																<input type="text" id="last_name" name="last_name" class="form-control" placeholder="Enter last name" required>
															</div>
														</div>
													</div>
													<!-- <div class="row">
														<div class="col-sm-12">
															<div class="form-group">
																<label>Email<span aria-hidden="true" class="required" style="color: red;">*</span></label>
																<input type="email" id="email" name="email" class="form-control" placeholder="Enter email" disabled required>
															</div>
														</div>
													</div> -->
													<div class="row">
														<div class="col-sm-12">
															<div class="form-group">
																<label>Mobile Number<span aria-hidden="true" class="required" style="color: red;">*</span></label>
																<input type="text" id="mobile_number" name="mobile_number" class="form-control" placeholder="Enter mobile number" required>
															</div>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-12">
															<div class="form-group">
																<label>City<span aria-hidden="true" class="required" style="color: red;">*</span></label>
																<input type="text" id="city" name="city" class="form-control" placeholder="Enter city" required>
																</select>
															</div>
														</div>
													</div>
													<div class="col-12">
														<button type="button" class="btn btn-secondary d-none">Close</button>
														<input class="btn btn-primary" value="Update" type="submit" id="modal_btnSubmit1" />
													</div>
											</div>


										</div>
										<!-- right column -->

										<!--/.col (right) -->
									</div>
								</div>
								<!-- /.row -->
							</div>
					</section>
					<!-- /.content -->
				</div>

				<aside class="control-sidebar control-sidebar-dark">
					<!-- Control sidebar content goes here -->
				</aside>
				<!-- /.control-sidebar -->
			</div>
			<!-- ./wrapper -->
			<!-- start search modal -->
			<div class="modal fade" id="profileModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
				<div class="modal-dialog modal-dialog-centered" role="document">
					<div class="modal-content">
						<!-- <div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">Profile</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
								</button>
							</div> -->
						<div class="modal-body">
						</div>
						<div class="modal-footer">

						</div>
						</form>
					</div>
				</div>
			</div>
			<!-- end search modal here -->

			<script type="text/javascript">
				$(document).ready(function() {
					var user_id = document.getElementById("user_id").value;
					$.ajax({
						type: "get",
						url: "<?php echo API_SITE_PATH ?>admin_profile_api.php",
						data: {
							user_id: user_id
						},
						cache: false,
						success: function(result) {
							var profile_data = $.parseJSON(result);
							var final_data = profile_data.response;
							$('#first_name').val(final_data.firstname);
							$('#last_name').val(final_data.lastname);
							$('#email').val(final_data.user_name);
							$('#mobile_number').val(final_data.mobile_no);
							$('#city').val(final_data.city);
						}
					});
					//$('#profileModal').modal('show');
					var fileTag = document.getElementById("edit_profile_file"),
						preview = document.getElementById("profile_picture");


					fileTag.addEventListener("change", function() {
						changeImage(this);
					});

					function changeImage(input) {
						var reader;

						if (input.files && input.files[0]) {
							reader = new FileReader();

							reader.onload = function(e) {
								preview.setAttribute('src', e.target.result);
								// $('#edit_image_link').attr('href','');
							}

							reader.readAsDataURL(input.files[0]);
						}

					}
				});

				function update_profile(that) {
					var fd = new FormData(that);
					var update_user_id = document.getElementById("user_id").value;
					$.ajax({
						type: "post",
						url: "<?php echo API_SITE_PATH ?>admin_profile_update_api.php",
						data: fd,
						dataType: 'json',
						contentType: false,
						processData: false,
						cache: false,
						success: function(result) {
							if (result.status == "true") {
								alert(result.message);
								window.location = "<?php echo ADMIN_SITE_PATH ?>home.php";
							} else {
								alert(result.message);
							}
						}
					});
				}
			</script>
			<?php include_once "tpl/tplFooter.php"; ?>
		</body>

</html>