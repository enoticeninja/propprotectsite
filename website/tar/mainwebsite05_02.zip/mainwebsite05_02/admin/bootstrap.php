<?php
//include_once '../../common_bootstrap.php';
include_once '../config.php';
include_once '../common_bootstrap.php';
include_once 'config.php';
include_once DIR_INCLUDES . 'decryption.php';
require_once DIR_INCLUDES . 'user-functions.php';
include_once DIR_INCLUDES . 'common-functions.php';
?>