<?php 

  require_once('db.php');
  require_once('../decryption.php');
  $mcrypt = new MCrypt();

$id=$_GET['id'];
$email = $mcrypt->decrypt($id);
 $date=date("Y-m-d H:i:s");

 if(!empty($email) && $email!=='')
	{
		
			$sqlQ = "SELECT * from tbl_user where user_name='".$email."'";
		
				$sqlQuery = mysqli_query($conn,$sqlQ);
				$row = $sqlQuery->fetch_array();
				$count = mysqli_num_rows($sqlQuery);
				if($count > 0)
				{
					$verify_email=$row["verify_email"];
					$firstname=$row["firstname"];
					//echo $verify_email;
					
					if(empty($verify_email) && $verify_email =='' or $verify_email == null && $verify_email == 'null' or $verify_email== false && $verify_email=='false')
					{
						date_default_timezone_set('Asia/Kolkata');
						
						$base_url='http://www.nanostuffs.com/lawyer/verify_email.php';
						$activation=md5($email.round(microtime(true) * 1000));
						$time = round(microtime(true) * 1000);
				
						$cu_time = date( 'Y-m-d h:i:s A', time () );
						$new_date =$mcrypt->encrypt($cu_time);
						$id =$mcrypt->encrypt($email);
						/* 
						echo  $cu_time;
						die(); */
					
						$body = '<b>Verify your e-mail to finish signing up for eNoticeNinja</b>'.$blank.'<br/> <br/>  Hi, '.$firstname.'<br/> <br/> Thank you for choosing eNoticeNinja'.$blank.'<br/> <br/>  Please confirm that '.$email.' is your e-mail address by use this link '.$blank.'<br/> <br/> <a href="'.$base_url.'?key='.$new_date.'&id='.$id.'">'.$base_url.'activation/'.$activation.'key='.$new_date.'</a> within 24 hours.';									
						$from ='Lawyerapp@gmail.com';
						$subject = "Confirm your email address ".$email."";
						$server=$_SERVER['HTTP_HOST'];
						$headers = "From: eNoticeNinja<".$from. ">\r\nContent-type: text/html; charset=iso-8859-1\r\nMIME-Version: 1.0\r\n";
						$to = $email;
						$send_email = mail($to, $subject, $body, $headers);
						$email_send= " Thank You Kindly check your email to verify your email id ";
						$new =$mcrypt->encrypt($email_send);
						header('location: http://www.nanostuffs.com/lawyer/admin/thank_you.php?status='.$new.'');
						//echo $email_send;
						//echo json_encode(array('status'=>'true','message'=>$email_send));									
						
					}		
				}
				else
				{
						$email_send= "Sorry,This email id is not registered with us!";
						$new =$mcrypt->encrypt($email_send);
						header('location: http://www.nanostuffs.com/lawyer/admin/thank_you.php?status='.$new.'');
					//echo json_encode(array('status'=>'false','message'=>'Sorry,This email id is not registered with us!'));
				}
		}
?>
