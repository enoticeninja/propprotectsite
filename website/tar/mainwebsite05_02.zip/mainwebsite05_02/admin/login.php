<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
include_once 'bootstrap.php';

$TITLE = 'Login';
session_start();
$mcrypt = new MCrypt();
if (isset($_GET['status'])) {
	$id = $_GET['status'];
	$message = $mcrypt->decrypt($id);
}

$plan = '';
$hasPlan = false;
if (isset($_GET['plan']) && !empty($_GET['plan'])) {
	$hasPlan = true;
	$plan = $_GET['plan'];
	$_SESSION['cart'] = $plan;
	$package = getPackages($plan);
}
print_r($_POST);
print_r($_SESSION);
if ((isset($_SESSION['user_id'])) && isset($_SESSION['user_name']) && (!empty($_SESSION['user_id'])) && $_SESSION['is_login'] == 'true') {
	if ($hasPlan) {
		header('location: ' . ADMIN_SITE_PATH . 'select-plan.php?plan=' . $plan . '');
		exit();
	}
	header('location: home.php');
} else {

	if (isset($_POST['action'])) {
		if ($_POST['action'] == 'login') {
			
			unset($_POST['action']);
			$_POST['device_id'] = 'browser';
			$_POST['device_type'] = 'browser';
			$_POST['mobile_no'] = '';
			$response = callApiJson($_POST, 'user_login_cryp.php');
			$message = $response['message'];
			if ($response['status'] == true) {
				$data = $response['response'];
				$_SESSION['user_id'] = $data['user_id'];
				$_SESSION['firstname'] = $data['firstname'];
				$_SESSION['lastname'] = $data['lastname'];
				$_SESSION['user_name'] = $data['email'];
				$_SESSION['is_login'] = 'true';
				$message = '';
				if ($hasPlan) {
					header('location: ' . ADMIN_SITE_PATH . 'select-plan.php?plan=' . $plan . '');
					exit();
				}
				header('location: ' . ADMIN_SITE_PATH . 'home.php');
			} else {
				/* $_SESSION['user_name'] = '';
				$_SESSION['is_login'] = 'false';
				header('location: login.php?status=false');
				exit(); */
			}
			//echo json_encode($response);

		}
	}
}
?>
<!DOCTYPE html>
<html>

<head>
	<?php include_once 'tpl/tplHead.php'; ?>
</head>

<body class="hold-transition login-page">
	<div class="login-box">

		<!-- /.login-logo -->
		<div class="card card-cascade wider">
			<div class="view view-cascade gradient-card-header blue-gradient">

				<!-- Title -->
				<h2 class="card-header-title mb-3">Login</h2>

			</div>
			<div class="card-body register-card-body card-body-cascade text-center">


				<img src="dist/img/Logo_Final.png" class="brand-image " style="width: 100px;height: 25%;margin-bottom: 0%;">
				<p style="text-align: center; color:Black;">Search You Can Trust</p>
				<p class="mb-1">
					<?php if (@$_GET['status'] == 'false') {
						echo "<font color='red'>Invalid Username / Password</font>";
					} ?>
				</p>
				<form id='login-form' method="POST" action="<?php echo ADMIN_SITE_PATH ?>login.php?plan=<?php echo $plan ?>">
					<input type="hidden" class="form-control " id="action" name="action" value="login">
					<div class="input-group mb-3">
						<input type="email" class="form-control" name="email" placeholder="Email">
						<div class="input-group-append">
							<div class="input-group-text">
								<span class="fas fa-envelope"></span>
							</div>
						</div>
					</div>
					<div class="input-group mb-3">
						<input id="password-field" type="password" class="form-control" name="password" placeholder="Password">
						<div class="input-group-append">
							<div class="input-group-text">
								<span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-8">

						</div>
						<!-- /.col -->
						<div class="col-12">
							<button type="submit" name="submit_email" id="login_button" class="btn btn-primary btn-block float-right">Sign In</button>
						</div>
						<!-- /.col -->
					</div>
					</br>
				</form>

				<div class="row">

					<!-- /.col -->
					<div class="col-12 ">
						<p class="mb-1">
							<a href="<?php echo ADMIN_SITE_PATH ?>register.php?plan=<?php echo $plan ?>" class="btn btn-secondary btn-block float-right">Sign up</a>
						</p>
					</div>
					<div class="col-12">

						<p class="mb-1">
							<a href="<?php echo ADMIN_SITE_PATH ?>login_mob.php?plan=<?php echo $plan ?>" class="btn btn-deep-purple btn-block float-right">Login with Mobile</a>
						</p>

					</div>
					<div class="col-12">

						<p class="mb-1">
							<a href="<?php echo ADMIN_SITE_PATH ?>forgot-password.php" class="btn btn-danger btn-block float-right">Forgot Password</a>
						</p>

					</div>
					<div class="col-4 d-none">


					</div>
					<div class="col-2">


					</div>
					<!-- /.col -->
				</div>


				<div class="row">
					<!-- /.col -->
					<div class="col-4">
						<p class="mb-12">

						</p>
					</div>
					<div class="col-12">
						<div class="icheck-primary">
							<p class="mb-1">
								<?php if (@$_GET['status'] == 'false') {
									echo "<font color='red'>Invalid Username / Password</font>";
								} ?>
							</p>
						</div>
					</div>
					<!-- /.col -->
				</div>

			</div>
			<!-- /.login-card-body -->
		</div>
	</div>
	<!-- /.login-box -->

	<!-- jQuery -->
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap 4 -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- AdminLTE App -->
	<script src="dist/js/adminlte.min.js"></script>
	<script>
		var hasPlan = <?php echo json_encode($hasPlan) ?>;
		$(".toggle-password").click(function() {
			$(this).toggleClass("fa-eye fa-eye-slash");
			var input = $($(this).attr("toggle"));
			if (input.attr("type") == "password") {
				input.attr("type", "text");
			} else {
				input.attr("type", "password");
			}
		});
	</script>
</body>

</html>