<?php
include_once 'bootstrap.php';
include_once 'db.php';
$TITLE = 'Login';
session_start();
require_once('../decryption.php');
$mcrypt = new MCrypt();
if (isset($_GET['status'])) {
	$id = $_GET['status'];
	$message = $mcrypt->decrypt($id);
}
$pay_data = $_POST;
print_r($pay_data);
?>
<!DOCTYPE html>
<html>

<head>
	<?php include_once 'tpl/tplHead.php'; ?>
</head>

<body class="hold-transition login-page">
	<section class="p-1">


		<div class="modal-dialog modal-notify modal-danger" role="document" style="margin:60px">
			<!--Content-->
			<div class="modal-content text-center">
				<!--Header-->
				<div class="modal-header d-flex justify-content-center">
					<p class="heading">Payment Succesful</p>
				</div>

				<!--Body-->
				<div class="modal-body">

					<i class="fas fa-times  fa-4x animated rotateIn mb-4 "></i>
					<p>Sorry! Unfortunately Your Payment failed. Please log in and try again.</p>

				</div>

				<!--Footer-->
				<div class="modal-footer flex-center">
					<a href="<?php echo ADMIN_SITE_PATH ?>login.php" class="btn btn-danger btn-block waves-effect waves-light">LOGIN</a>

				</div>
			</div>
			<!--/.Content-->
		</div>

	</section>

	<!-- jQuery -->
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap 4 -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="dist/mdb/js/mdb.min.js"></script>
	<script src="dist/mdb/js/mdb.min.js"></script>

</body>

</html>