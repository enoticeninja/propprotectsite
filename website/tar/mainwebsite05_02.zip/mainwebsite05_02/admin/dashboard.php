<?php
include_once 'bootstrap.php';
include_once 'db.php';
$TITLE = 'Login';
session_start();
require_once('../decryption.php');
$mcrypt = new MCrypt();
if (isset($_GET['status'])) {
	$id = $_GET['status'];
	$message = $mcrypt->decrypt($id);
}

$plan = '';
$hasPlan = false;
if (isset($_GET['plan']) && !empty($_GET['plan'])) {
	$hasPlan = true;
	$plan = $_GET['plan'];
	$_SESSION['cart'] = $plan;
	$package = getPackages($plan);
}

if ((isset($_SESSION['user_id'])) && isset($_SESSION['user_name']) && (!empty($_SESSION['user_id'])) && $_SESSION['is_login'] == 'true') {
	if ($hasPlan) {
		header('location: ' . ADMIN_SITE_PATH . 'select-plan.php?plan=' . $plan . '');
		exit();
	}
	header('location: home.php');
} else {

	if (isset($_POST["submit_email"])) {

		$user_name = strtolower($_POST['username']);
		$password = $mcrypt->encrypt($_POST['password']);
		// $password = $_POST['password'];

		$query = "SELECT * FROM tbl_user WHERE user_name = '$user_name' AND user_password = '$password'";
		$sqlQuery = mysqli_query($conn, $query);
		$row = $sqlQuery->fetch_array();
		$total = mysqli_num_rows($sqlQuery);
		if ($total > 0) {
			$queryLogin = "UPDATE login set is_login='true' WHERE user_name = '$user_name'";
			$sqlQueryL = mysqli_query($conn, $queryLogin);

			$_SESSION['user_id'] = $row['user_id'];
			$_SESSION['firstname'] = $row['firstname'];
			$_SESSION['lastname'] = $row['lastname'];
			$_SESSION['user_name'] = $user_name;
			$_SESSION['is_login'] = 'true';
			if ($hasPlan) {
				header('location: ' . ADMIN_SITE_PATH . 'select-plan.php?plan=' . $plan . '');
				exit();
			}
			header('location: home.php');
		} else {
			$queryLogin = "UPDATE login set is_login='false' WHERE user_name = '$user_name'";
			//$mysqli->query($queryLogin);
			$sqlQueryL = mysqli_query($conn, $queryLogin);
			$_SESSION['user_name'] = '';
			$_SESSION['is_login'] = 'false';

			header('location: login.php?status=false');
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<?php include_once 'tpl/tplTiHead.php' ?>

</head>

<body class="">
	<div class="wrapper ">
		<?php include_once 'tpl/tplTiSidebar.php' ?>
		<div class="main-panel">
			<!-- Navbar -->
			<?php include_once 'tpl/tplTiHeader.php' ?>
			<!-- End Navbar -->
			<div class="content">
				<div class="content">
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-12">
								<div class="login-box">

									<!-- /.login-logo -->
									<div class="card card-cascade wider">
										<div class="view view-cascade gradient-card-header blue-gradient">

											<!-- Title -->
											<h2 class="card-header-title mb-3">Login</h2>

										</div>
										<div class="card-body register-card-body card-body-cascade text-center">


											<img src="dist/img/Logo_Final.png" class="brand-image " style="width: 100px;height: 25%;margin-bottom: 0%;">
											<p style="text-align: center; color:Black;">Search You Can Trust</p>
											<p class="mb-1">
												<?php if (@$_GET['status'] == 'false') {
													echo "<font color='red'>Invalid Username / Password</font>";
												} ?>
											</p>
											<form id='login-form' method="POST" action="<?php echo ADMIN_SITE_PATH ?>login.php?plan=<?php echo $plan ?>">
												<div class="input-group mb-3">
													<input type="email" class="form-control" name="username" placeholder="Email">
													<div class="input-group-append">
														<div class="input-group-text">
															<span class="fas fa-envelope"></span>
														</div>
													</div>
												</div>
												<div class="input-group mb-3">
													<input id="password-field" type="password" class="form-control" name="password" placeholder="Password">
													<div class="input-group-append">
														<div class="input-group-text">
															<span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-8">

													</div>
													<!-- /.col -->
													<div class="col-12">
														<button type="submit" name="submit_email" id="login_button" class="btn btn-primary btn-block float-right">Sign In</button>
													</div>
													<!-- /.col -->
												</div>
												</br>
											</form>

											<div class="row">

												<!-- /.col -->
												<div class="col-12 ">
													<p class="mb-1">
														<a href="<?php echo ADMIN_SITE_PATH ?>register.php?plan=<?php echo $plan ?>" class="btn btn-secondary btn-block float-right">Sign up</a>
													</p>
												</div>
												<div class="col-12">

													<p class="mb-1">
														<a href="<?php echo ADMIN_SITE_PATH ?>login_mob.php?plan=<?php echo $plan ?>" class="btn btn-deep-purple btn-block float-right">Login with Mobile</a>
													</p>

												</div>
												<div class="col-12">

													<p class="mb-1">
														<a href="<?php echo ADMIN_SITE_PATH ?>forgot-password.php" class="btn btn-danger btn-block float-right">Forgot Password</a>
													</p>

												</div>
												<div class="col-4 d-none">


												</div>
												<div class="col-2">


												</div>
												<!-- /.col -->
											</div>


											<div class="row">
												<!-- /.col -->
												<div class="col-4">
													<p class="mb-12">

													</p>
												</div>
												<div class="col-12">
													<div class="icheck-primary">
														<p class="mb-1">
															<?php if (@$_GET['status'] == 'false') {
																echo "<font color='red'>Invalid Username / Password</font>";
															} ?>
														</p>
													</div>
												</div>
												<!-- /.col -->
											</div>

										</div>
										<!-- /.login-card-body -->
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
			<?php include_once 'tpl/tplTiFooter.php' ?>
		</div>
	</div>
	<div class="fixed-plugin">
		<div class="dropdown show-dropdown">
			<a href="#" data-toggle="dropdown">
				<i class="fa fa-cog fa-2x"> </i>
			</a>
			<ul class="dropdown-menu">
				<li class="header-title"> Sidebar Filters</li>
				<li class="adjustments-line">
					<a href="javascript:void(0)" class="switch-trigger active-color">
						<div class="badge-colors ml-auto mr-auto">
							<span class="badge filter badge-purple" data-color="purple"></span>
							<span class="badge filter badge-azure" data-color="azure"></span>
							<span class="badge filter badge-green" data-color="green"></span>
							<span class="badge filter badge-warning" data-color="orange"></span>
							<span class="badge filter badge-danger" data-color="danger"></span>
							<span class="badge filter badge-rose active" data-color="rose"></span>
						</div>
						<div class="clearfix"></div>
					</a>
				</li>
				<li class="header-title">Sidebar Background</li>
				<li class="adjustments-line">
					<a href="javascript:void(0)" class="switch-trigger background-color">
						<div class="ml-auto mr-auto">
							<span class="badge filter badge-black active" data-background-color="black"></span>
							<span class="badge filter badge-white" data-background-color="white"></span>
							<span class="badge filter badge-red" data-background-color="red"></span>
						</div>
						<div class="clearfix"></div>
					</a>
				</li>
				<li class="adjustments-line">
					<a href="javascript:void(0)" class="switch-trigger">
						<p>Sidebar Mini</p>
						<label class="ml-auto">
							<div class="togglebutton switch-sidebar-mini">
								<label>
									<input type="checkbox">
									<span class="toggle"></span>
								</label>
							</div>
						</label>
						<div class="clearfix"></div>
					</a>
				</li>
				<li class="adjustments-line">
					<a href="javascript:void(0)" class="switch-trigger">
						<p>Sidebar Images</p>
						<label class="switch-mini ml-auto">
							<div class="togglebutton switch-sidebar-image">
								<label>
									<input type="checkbox" checked="">
									<span class="toggle"></span>
								</label>
							</div>
						</label>
						<div class="clearfix"></div>
					</a>
				</li>
				<li class="header-title">Images</li>
				<li class="active">
					<a class="img-holder switch-trigger" href="javascript:void(0)">
						<img src="dist/cati/img/sidebar-1.jpg" alt="">
					</a>
				</li>
				<li>
					<a class="img-holder switch-trigger" href="javascript:void(0)">
						<img src="dist/cati/img/sidebar-2.jpg" alt="">
					</a>
				</li>
				<li>
					<a class="img-holder switch-trigger" href="javascript:void(0)">
						<img src="dist/cati/img/sidebar-3.jpg" alt="">
					</a>
				</li>
				<li>
					<a class="img-holder switch-trigger" href="javascript:void(0)">
						<img src="dist/cati/img/sidebar-4.jpg" alt="">
					</a>
				</li>
				<li class="button-container">
					<a href="https://www.creative-tim.com/product/material-dashboard-pro" target="_blank" class="btn btn-rose btn-block btn-fill">Buy Now</a>
					<a href="https://demos.creative-tim.com/material-dashboard-pro/docs/2.1/getting-started/introduction.html" target="_blank" class="btn btn-default btn-block">
						Documentation
					</a>
					<a href="https://www.creative-tim.com/product/material-dashboard" target="_blank" class="btn btn-info btn-block">
						Get Free Demo!
					</a>
				</li>
				<li class="button-container github-star">
					<a class="github-button" href="https://github.com/creativetimofficial/ct-material-dashboard-pro" data-icon="octicon-star" data-size="large" data-show-count="true" aria-label="Star ntkme/github-buttons on GitHub">Star</a>
				</li>
				<li class="header-title">Thank you for 95 shares!</li>
				<li class="button-container text-center">
					<button id="twitter" class="btn btn-round btn-twitter"><i class="fa fa-twitter"></i> &middot; 45</button>
					<button id="facebook" class="btn btn-round btn-facebook"><i class="fa fa-facebook-f"></i> &middot; 50</button>
					<br>
					<br>
				</li>
			</ul>
		</div>
	</div>
	<?php include_once 'tpl/tplTiFooterJs.php' ?>
</body>


</html>